# मार्गON: Accessible Indoor Navigation for GL BAJAJ, Greater Noida

मार्गON guides wheelchair users from the Help Desk at the main gate to any room in the two
academic blocks, shown as a 3D campus model. The Help Desk fits a sensor strap to the wheelchair
and issues a token. The visitor enters the token and follows map-style, turn-by-turn guidance in
English or Hindi, with voice. When the Admin closes a lift, ramp, stair or corridor, every
visitor's route is recalculated immediately.

## Problem statement coverage (Faculty Hackathon, 4 Nov 2026)

| Requirement | मार्गON |
|---|---|
| Campus as a graph | 480 nodes, 543 edges, adjacency lists (`src/data/routeData.js`) |
| Costs per segment type | Corridor = length; ramp ×1.15; lift boarding +9, travel ×0.6; stairs excluded (wheelchair) or ×6 |
| Routes by accessibility need | Ramp + Lift (step-free) or Steps + Lift |
| Reroute on failures | Lifts, ramps, stairs, corridors; re-planned from the current position |
| Report and verify barriers | Visitor reports (with photo) and strap sensor flags; confidence 1 − Π(1 − cᵢ); Help Desk Verify / Dismiss (Reports tab) |
| Demonstration with failures | Facilities tab, strap sensor event simulation, SOS |
| Priority queue, Dijkstra, A* | Binary min-heap; A* with admissible heuristic; Routing lab compares both |
| Data validation | Plausibility checks on every strap reading; differential barometry |
| Testing | `npm test`: 27 automated tests; `npm run bench`: Dijkstra vs A* on 500 pairs |

Benchmark (500 random room pairs): identical optimal cost in 500 of 500; A* expands 31.5% fewer
nodes (286.6 → 196.4 on average); about 0.15 ms per route. See `docs/benchmark.json` and `docs/API.md`.

## Campus model

| Item | Detail |
|---|---|
| Blocks | AI & ML Block (west) and CSDS Block (east), identical layout, 2 m apart |
| Levels | Ground + 10 floors; in use: Ground, 2, 3, 4, 5, 6, 10 (1, 7, 8, 9 shown grey, not routable) |
| Vertical access | 2 lifts in the left core (L1, L2), 2 in the right core (L3, L4), stairs in both cores |
| Entrance | Front steps with a 1:12 ramp on each side |
| Ground floor | Seminar Hall 1 and 2, Admission Cell, Server Room, Waiting Lounge, Accessible Washroom |
| Floors 2 to 6 | Rooms X01 to X10; X05 is a double-width Faculty Cabin on floors 2 to 5 |
| AI & ML Block | 2nd and 3rd floor AI, 4th to 6th and 10th floor AI & ML; HOD AI in 310, HOD AI & ML in 410 |
| CSDS Block | All floors CSDS; HOD CSDS in 310, Department Office in 410 |
| 5th floor | Examination Cell 510 in both blocks |
| 10th floor | Labs L1 to L6 |
| Campus | Main gate with GL BAJAJ banner, Help Desk beside the gate, banner on both rooftops |

## Start page

The first page is split into two halves: **Visitor** (left) and **Help Desk / Admin** (right).
Clicking a half opens its sign-in: strap number and token for a visitor, username and password for
the Help Desk.

## Roles

| Role | Sign in | Functions |
|---|---|---|
| Help Desk / Admin | `admin` / `margon123` | Reports (verify queue); Routing lab (Dijkstra vs A*, engine choice); Issue strap (name, mobile, strap number; token valid 9:00 am to 6:00 pm on the day of issue); Live map of all straps with current stop; SOS alerts with alarm, Locate, Acknowledge, Resolved; Facilities per block (lifts, ramps, steps, stairs, corridors, notice) |
| Visitor | Strap number + token | Chooses one or more stops, route preference (Ramp + Lift, or Steps + Lift), shortest order, optional return to the Help Desk; map-style guidance with voice in English or Hindi; pace 1×, 2×, 4×; SOS button |

## Multi-stop trips

The visitor adds stops from a searchable list (room number, name or type, filter by block).
"Shortest order" computes the quickest order (exact for up to 7 stops). At each stop the visitor
presses "Continue to next stop". Stops can be added or removed during the trip from the Trip tab.

## SOS

- **Manual:** the red SOS button sends Accident, Medical help or Need assistance.
- **Automatic:** when the strap's motion sensor reports an impact, a 10-second countdown starts;
  unless the visitor presses "I am OK", the SOS is sent. In the prototype the impact is simulated
  from the Strap readings section.
- The Help Desk sees a red banner with name, mobile, type and location, plus an alarm tone until
  acknowledged. The visitor then sees "Help is on the way". Guidance pauses during an SOS.

## Service hours

Tokens are valid from 9:00 am to 6:00 pm on the day of issue. Outside these hours the Help Desk can
tick "Allow issuing for a demonstration", which issues a token valid for 4 hours.

## Voice guidance

Voice uses the browser's built-in speech synthesis (`hi-IN` for Hindi, `en-IN` for English).
Messages are queued, never cut off. Guidance moves at a real wheelchair pace (about 1 m/s), says
"In 8 metres, turn left" before each turn, and waits at lifts, ramps and doors until the message
has been spoken. "Test voice" shows which voice is in use.

If Hindi is silent, the device has no Hindi voice installed:
- Windows: Settings > Time & language > Language > Add Hindi, tick Speech, then restart the browser.
- Android: Settings > Text-to-speech > Google > install Hindi.
- Chrome on a laptop also offers "Google हिन्दी" when online.

## Strap readings

Each strap has an ESP32 (position and Wi-Fi uplink), an MPU inertial unit (heading and motion) and
a barometric sensor (height, converted to a floor at 4 m per floor). The Help Desk is the command
centre that receives the readings. Record format:

```json
{ "x": -38.6, "z": 0.0, "relHeight": 16.0, "level": 4, "pressure": 987.68,
  "heading": 270, "speed": 1.0, "ts": 1793630381000 }
```

A real strap can write the same record to `tokens/<TOKEN>.telemetry`.

## Run or host

```bash
npm install            # also applies scripts/patch-drei.mjs
npm run dev            # http://localhost:5173
npm run build          # website in dist/ (relative paths, host anywhere)
npm run serve          # live server: build + shared data for all devices, http://localhost:8080
npx vite build -c vite.single.config.js   # one self-contained HTML file in dist-single/
```

Live server (Help Desk and visitor phones share data): `npm run serve`, or deploy to Render, a college
Linux server or Docker as described in `docs/DEPLOY.md`.

Static hosting (`dist/` on Netlify Drop, GitHub Pages, Vercel or Cloudflare Pages) also works, but then
Admin and Visitor stay in sync only between tabs of the same browser.

## Routing

The navigation graph follows corridor centre-lines, doors, lift landings and cars, stair landings,
entrance ramps and campus paths. Dijkstra's algorithm computes the route; in wheelchair mode stairs
are never used. Each step records the turn (left, right, straight) relative to the direction of
travel, which drives the arrow, the text and the voice prompt.

## Structure

```
src/
  admin/       AdminDashboard, LiveMonitor, IssueStrap, Facilities
  visitor/     VisitorNavigator (guidance card, trip bar, language, voice)
  components/  LoginPage, SceneView, Brand, SyncBadge, SceneFallback
  three/       BuildingScene, BuildingModel, FloorModel, RoomModel, ElevatorModel, RampModel,
               CorridorModel, RoutePath, NavigationMarkers, CameraControls, geometry, theme
  data/        buildingData, roomData, routeData, straps, store, voice
  assets/      glbajaj-banner.png
```
