import { useEffect, useState } from 'react'
import { getFacility, getMode, getReports, getTokens, initStore, subscribe } from '../data/store'

const getters = { facility: getFacility, tokens: getTokens, reports: getReports, mode: getMode }

export default function useStore(key) {
  const [v, setV] = useState(() => getters[key]())
  useEffect(() => {
    initStore()
    return subscribe(key, setV)
  }, [key])
  return v
}
