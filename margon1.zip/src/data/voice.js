// Voice guidance with the browser's built-in speech synthesis.
// Hindi uses a hi-IN voice, English an en-IN voice where available.
// Messages are queued (never cut off); speak() resolves when the message has been spoken.

const supported = () => typeof window !== 'undefined' && 'speechSynthesis' in window

let voices = []
let ready = null
function refresh() {
  if (!supported()) return []
  voices = window.speechSynthesis.getVoices() || []
  return voices
}

// Chrome fills the voice list asynchronously; wait for it (max 2 s).
export function voicesReady() {
  if (!supported()) return Promise.resolve([])
  if (refresh().length) return Promise.resolve(voices)
  if (!ready)
    ready = new Promise((resolve) => {
      const done = () => resolve(refresh())
      window.speechSynthesis.addEventListener?.('voiceschanged', done, { once: true })
      setTimeout(done, 2000)
    })
  return ready
}
if (supported()) {
  refresh()
  window.speechSynthesis.addEventListener?.('voiceschanged', refresh)
}

export const voiceSupported = supported

const norm = (l) => (l || '').toLowerCase().replace('_', '-')

export function pickVoice(lang) {
  refresh()
  if (lang === 'hi') {
    const hi = voices.filter((v) => norm(v.lang).startsWith('hi'))
    // Prefer named, natural voices (Google हिन्दी, Microsoft Swara/Madhur, Kalpana, Hemant)
    return (
      hi.find((v) => /google/i.test(v.name)) ||
      hi.find((v) => /swara|madhur|natural|online/i.test(v.name)) ||
      hi.find((v) => /kalpana|hemant/i.test(v.name)) ||
      hi[0] ||
      null
    )
  }
  const order = ['en-in', 'en-gb', 'en-us', 'en']
  for (const o of order) {
    const v = voices.find((x) => norm(x.lang).startsWith(o))
    if (v) return v
  }
  return null
}

export function hasVoice(lang) {
  return !!pickVoice(lang)
}

let queue = Promise.resolve()
let generation = 0

export function speak(text, lang = 'en', { interrupt = false } = {}) {
  if (!supported() || !text) return Promise.resolve()
  if (interrupt) stopSpeaking()
  const gen = generation
  queue = queue.then(
    () =>
      new Promise((resolve) => {
        if (gen !== generation) return resolve()
        voicesReady().then(() => {
          if (gen !== generation) return resolve()
          const synth = window.speechSynthesis
          const u = new SpeechSynthesisUtterance(text)
          const v = pickVoice(lang)
          if (v) u.voice = v
          u.lang = v?.lang ?? (lang === 'hi' ? 'hi-IN' : 'en-IN')
          u.rate = lang === 'hi' ? 0.92 : 0.98
          let finished = false
          const end = () => {
            if (finished) return
            finished = true
            clearTimeout(guard)
            resolve()
          }
          u.onend = end
          u.onerror = end
          // Safety net if the engine never reports the end (about 90 ms per character).
          const guard = setTimeout(end, Math.max(2500, text.length * 90))
          if (synth.paused) synth.resume()
          synth.speak(u)
        })
      }),
  )
  return queue
}

export function stopSpeaking() {
  generation++
  queue = Promise.resolve()
  if (supported()) window.speechSynthesis.cancel()
}

export function voiceInfo(lang) {
  const v = pickVoice(lang)
  return v ? `${v.name} (${v.lang})` : null
}
