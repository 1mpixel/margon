// Room schedule for both GL BAJAJ blocks (identical layouts).
// side 'F' = front wing (z 2..10, towards the gate), 'R' = rear wing (z -10..-2).
// x0/x1/doorX are local to the block; gx is the global x of the door.
import { BUILDINGS, OPERATIONAL } from './buildingData'

export const ROOM_TYPES = {
  lobby: { label: 'Entrance lobby', labelHi: 'प्रवेश लॉबी', color: '#0f766e' },
  seminar: { label: 'Seminar hall', labelHi: 'सेमिनार हॉल', color: '#7c3aed' },
  admission: { label: 'Admission cell', labelHi: 'प्रवेश प्रकोष्ठ', color: '#0891b2' },
  exam: { label: 'Examination cell', labelHi: 'परीक्षा प्रकोष्ठ', color: '#c2410c' },
  server: { label: 'Server room', labelHi: 'सर्वर रूम', color: '#475569' },
  waiting: { label: 'Waiting lounge', labelHi: 'प्रतीक्षा कक्ष', color: '#0d9488' },
  washroom: { label: 'Accessible washroom', labelHi: 'सुलभ शौचालय', color: '#16a34a' },
  classroom: { label: 'Classroom', labelHi: 'कक्षा', color: '#2563eb' },
  faculty: { label: 'Faculty cabin', labelHi: 'संकाय केबिन', color: '#4f46e5' },
  hod: { label: 'HOD office', labelHi: 'विभागाध्यक्ष कार्यालय', color: '#be185d' },
  office: { label: 'Department office', labelHi: 'विभाग कार्यालय', color: '#9333ea' },
  lab: { label: 'Laboratory', labelHi: 'प्रयोगशाला', color: '#0e7490' },
}

const deptFor = (bid, level) => {
  if (level === 0) return bid === 'B1' ? 'AI & ML Block' : 'CSDS Block'
  if (bid === 'B2') return 'CSDS'
  return level <= 3 ? 'Artificial Intelligence' : 'AI & ML'
}
const DEPT_HI = { 'Artificial Intelligence': 'कृत्रिम बुद्धिमत्ता', 'AI & ML': 'एआई एवं एमएल', CSDS: 'सीएसडीएस', 'AI & ML Block': 'एआई एवं एमएल ब्लॉक', 'CSDS Block': 'सीएसडीएस ब्लॉक' }

function room(b, level, side, x0, x1, id, type, name, nameHi, extra = {}) {
  const doorX = extra.doorX ?? (x0 + x1) / 2
  const dept = deptFor(b.id, level)
  return {
    id: `${b.id}-${id}`,
    building: b.id,
    buildingName: b.name,
    level,
    side,
    x0,
    x1,
    z0: side === 'F' ? 2 : -10,
    z1: side === 'F' ? 10 : -2,
    type,
    name,
    nameHi,
    dept,
    deptHi: DEPT_HI[dept] ?? dept,
    doorX,
    gx: b.ox + doorX,
    ...extra,
  }
}

function buildRooms() {
  const out = []
  for (const b of BUILDINGS) {
    // Ground floor
    out.push(
      room(b, 0, 'F', -15, -3, 'G-SH1', 'seminar', 'Seminar Hall 1', 'सेमिनार हॉल 1'),
      room(b, 0, 'F', -3, 3, 'LOBBY', 'lobby', 'Entrance Lobby', 'प्रवेश लॉबी', { doorX: 0 }),
      room(b, 0, 'F', 3, 9, 'G-ADM', 'admission', 'Admission Cell', 'प्रवेश प्रकोष्ठ'),
      room(b, 0, 'F', 9, 15, 'G-WC', 'washroom', 'Accessible Washroom', 'सुलभ शौचालय'),
      room(b, 0, 'R', -15, 3, 'G-SH2', 'seminar', 'Seminar Hall 2', 'सेमिनार हॉल 2', { doorX: -6 }),
      room(b, 0, 'R', 3, 9, 'G-SRV', 'server', 'Server Room', 'सर्वर रूम'),
      room(b, 0, 'R', 9, 15, 'G-WAIT', 'waiting', 'Waiting Lounge', 'प्रतीक्षा कक्ष'),
    )
    // Teaching floors 2 to 6: rooms X01 to X10, X05 is a double-width faculty cabin on 2 to 5
    for (const level of [2, 3, 4, 5, 6]) {
      const n = (k) => `${level}${String(k).padStart(2, '0')}`
      const front = [
        [-15, -10, 1],
        [-10, -5, 2],
        [-5, 0, 3],
        [0, 5, 4],
      ]
      front.forEach(([a, c, k]) => out.push(room(b, level, 'F', a, c, n(k), 'classroom', `Classroom ${n(k)}`, `कक्षा ${n(k)}`, { number: n(k) })))
      if (level <= 5) out.push(room(b, level, 'F', 5, 15, n(5), 'faculty', `Faculty Cabin ${n(5)}`, `संकाय केबिन ${n(5)}`, { number: n(5) }))
      else out.push(room(b, level, 'F', 5, 15, n(5), 'classroom', `Classroom ${n(5)}`, `कक्षा ${n(5)}`, { number: n(5) }))
      const rear = [
        [-15, -10, 6],
        [-10, -5, 7],
        [-5, 0, 8],
        [0, 5, 9],
        [5, 10, 10],
      ]
      rear.forEach(([a, c, k]) => {
        let type = 'classroom'
        let name = `Classroom ${n(k)}`
        let nameHi = `कक्षा ${n(k)}`
        if (k === 10 && level === 3) {
          type = 'hod'
          name = b.id === 'B1' ? `HOD Office (AI) ${n(k)}` : `HOD Office (CSDS) ${n(k)}`
          nameHi = b.id === 'B1' ? `विभागाध्यक्ष कार्यालय (एआई) ${n(k)}` : `विभागाध्यक्ष कार्यालय (सीएसडीएस) ${n(k)}`
        } else if (k === 10 && level === 4) {
          type = b.id === 'B1' ? 'hod' : 'office'
          name = b.id === 'B1' ? `HOD Office (AI & ML) ${n(k)}` : `Department Office (CSDS) ${n(k)}`
          nameHi = b.id === 'B1' ? `विभागाध्यक्ष कार्यालय (एआई एवं एमएल) ${n(k)}` : `विभाग कार्यालय (सीएसडीएस) ${n(k)}`
        } else if (k === 10 && level === 5) {
          type = 'exam'
          name = `Examination Cell ${n(k)}`
          nameHi = `परीक्षा प्रकोष्ठ ${n(k)}`
        }
        out.push(room(b, level, 'R', a, c, n(k), type, name, nameHi, { number: n(k) }))
      })
      out.push(room(b, level, 'R', 10, 15, `${level}-WC`, 'washroom', 'Accessible Washroom', 'सुलभ शौचालय'))
    }
    // 10th floor laboratories
    const labs = [
      ['F', -15, -5, 1],
      ['F', -5, 5, 2],
      ['F', 5, 15, 3],
      ['R', -15, -5, 4],
      ['R', -5, 5, 5],
      ['R', 5, 10, 6],
    ]
    labs.forEach(([side, a, c, k]) => out.push(room(b, 10, side, a, c, `10-L${k}`, 'lab', `Lab L${k}`, `प्रयोगशाला L${k}`)))
    out.push(room(b, 10, 'R', 10, 15, '10-WC', 'washroom', 'Accessible Washroom', 'सुलभ शौचालय'))
  }
  return out
}

export const ROOMS = buildRooms()
export const roomById = Object.fromEntries(ROOMS.map((r) => [r.id, r]))
export const roomsOn = (bid, level) => ROOMS.filter((r) => r.building === bid && r.level === level)
export const DESTINATIONS = ROOMS.filter((r) => r.type !== 'lobby' && r.type !== 'server' && OPERATIONAL.includes(r.level))
