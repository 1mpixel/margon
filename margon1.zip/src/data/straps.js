// MARGON wheelchair strap: ESP32 (positioning + Wi-Fi uplink), MPU (IMU: heading, motion)
// and a barometric sensor (relative height → floor). In this prototype the readings are
// simulated along the visitor's route and reported to the Help Desk command centre.
import { BUILDING, floorName } from './buildingData'
import { GRAPH } from './routeData'

export const STRAPS = Array.from({ length: 10 }, (_, i) => `ST-${String(i + 1).padStart(2, '0')}`)

const FLOOR_H = BUILDING.realFloorHeight
const P0 = 989.6 // hPa at Ground-floor level (illustrative site value)
const HPA_PER_M = 0.12 // near-surface pressure gradient

export const levelFromHeight = (h) => Math.max(0, Math.min(10, Math.round(h / FLOOR_H)))
export const pressureFromHeight = (h) => +(P0 - h * HPA_PER_M).toFixed(2)

export function telemetryAtNode(nodeId) {
  const n = GRAPH.nodes[nodeId]
  if (!n) return null
  const relHeight = n.level * FLOOR_H + n.dy
  return {
    x: +n.x.toFixed(2),
    z: +n.z.toFixed(2),
    relHeight: +relHeight.toFixed(2),
    level: levelFromHeight(relHeight),
    pressure: pressureFromHeight(relHeight),
    heading: 0,
    speed: 0,
    ts: Date.now(),
  }
}

// Convert a rendered scene position (with visual floor gap) to strap readings.
export function telemetryFromScene(pos, gap, prev, dtSec) {
  const relHeight = ((pos.y - 0.35) / gap) * FLOOR_H
  const x = pos.x
  const z = pos.z
  let heading = prev?.heading ?? 0
  let speed = 0
  if (prev && dtSec > 0) {
    const dx = x - prev.x
    const dz = z - prev.z
    const d = Math.hypot(dx, dz, relHeight - prev.relHeight)
    speed = d / dtSec
    if (Math.hypot(dx, dz) > 0.05) heading = ((Math.atan2(dx, -dz) * 180) / Math.PI + 360) % 360
  }
  return {
    x: +x.toFixed(2),
    z: +z.toFixed(2),
    relHeight: +relHeight.toFixed(2),
    level: levelFromHeight(relHeight),
    pressure: pressureFromHeight(relHeight),
    heading: Math.round(heading),
    speed: +speed.toFixed(2),
    ts: Date.now(),
  }
}

export const compass = (deg) => ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round((deg % 360) / 45) % 8]
export const floorLabel = (level) => floorName(level)

export const NAV_LABEL = {
  idle: 'Ready',
  running: 'Moving',
  paused: 'Paused',
  arrived: 'Arrived',
}

export const timeAgo = (ts) => {
  if (!ts) return '-'
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000))
  if (s < 5) return 'just now'
  if (s < 60) return `${s}s ago`
  const m = Math.round(s / 60)
  return m < 60 ? `${m} min ago` : `${Math.round(m / 60)} h ago`
}

// Reference barometer at the Help Desk kiosk (exterior grade, 0.75 m below the Ground floor).
export const DESK_GROUND_OFFSET_M = 0.75
export const P_REF_DESK = +(989.6 + DESK_GROUND_OFFSET_M * 0.12).toFixed(2)
