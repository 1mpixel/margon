// MARGON campus model: GL BAJAJ, two identical academic blocks (Ground + 10 floors).
// Units are metres. Global origin: centre of the forecourt line between the two blocks,
// at Ground-floor level. +x = East, +z = Front (towards the main gate).
// Each block uses local coordinates x -21..21, z -10..10 and is placed at offset `ox`.

export const INSTITUTE = 'GL BAJAJ'
export const CAMPUS = 'Greater Noida'

export const BUILDING = {
  realFloorHeight: 4,
  slabThickness: 0.3,
  wallHeight: 2.6,
  facadeLowHeight: 1.05,
  gradeLevel: -0.75, // plinth: exterior ground relative to Ground floor
  halfWidth: 21,
  halfDepth: 10,
}

export const BUILDINGS = [
  { id: 'B1', name: 'AI & ML Block', short: 'AI & ML', nameHi: 'एआई एवं एमएल ब्लॉक', ox: -22 },
  { id: 'B2', name: 'CSDS Block', short: 'CSDS', nameHi: 'सीएसडीएस ब्लॉक', ox: 22 },
]
export const buildingById = Object.fromEntries(BUILDINGS.map((b) => [b.id, b]))

const ORD = ['Ground', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th']
const ORD_HI = ['भूतल', 'पहली मंज़िल', 'दूसरी मंज़िल', 'तीसरी मंज़िल', 'चौथी मंज़िल', 'पाँचवीं मंज़िल', 'छठी मंज़िल', 'सातवीं मंज़िल', 'आठवीं मंज़िल', 'नौवीं मंज़िल', 'दसवीं मंज़िल']
export const OPERATIONAL = [0, 2, 3, 4, 5, 6, 10]

export const FLOORS = ORD.map((o, level) => ({
  level,
  short: level === 0 ? 'G' : String(level),
  name: level === 0 ? 'Ground floor' : `${o} floor`,
  nameHi: ORD_HI[level],
  operational: OPERATIONAL.includes(level),
}))
export const MIN_LEVEL = 0
export const MAX_LEVEL = 10

export const floorName = (level) => FLOORS[level]?.name ?? `Level ${level}`
export const floorNameHi = (level) => FLOORS[level]?.nameHi ?? `स्तर ${level}`
export const floorShort = (level) => FLOORS[level]?.short ?? `${level}`

export const CORRIDOR = { x0: -21, x1: 21, z0: -2, z1: 2 }

// Two lifts in the left (west) core and two in the right (east) core of every block.
const LIFT_LOCAL = [
  { n: 1, x: -19.4, side: 'left' },
  { n: 2, x: -16.6, side: 'left' },
  { n: 3, x: 16.6, side: 'right' },
  { n: 4, x: 19.4, side: 'right' },
]
export const LIFTS = BUILDINGS.flatMap((b) =>
  LIFT_LOCAL.map((l) => ({
    id: `${b.id}-L${l.n}`,
    building: b.id,
    label: `L${l.n}`,
    name: `Lift L${l.n}`,
    side: l.side,
    lx: l.x,
    x: b.ox + l.x,
    doorZ: 2.6,
    carZ: 4.6,
    width: 2.4,
    serves: OPERATIONAL,
    spec: '1.1 m door · 1.4 × 2.0 m car · Braille buttons · voice announcement',
  })),
)

// Stair cores at the rear of each end core.
export const STAIRS = BUILDINGS.flatMap((b) => [
  { id: `${b.id}-SW`, building: b.id, name: 'West stairs', lx: -18, x: b.ox - 18, nodeZ: -4.5, box: { x0: -21, x1: -15 } },
  { id: `${b.id}-SE`, building: b.id, name: 'East stairs', lx: 18, x: b.ox + 18, nodeZ: -4.5, box: { x0: 15, x1: 21 } },
])

// Entrance: front steps in the middle with a 1:12 ramp on each side.
export const RAMPS = BUILDINGS.flatMap((b) => [
  {
    id: `${b.id}-RW`,
    building: b.id,
    name: 'West entrance ramp',
    from: { lx: -12, z: 12.2, dy: -0.75 },
    to: { lx: -3, z: 12.2, dy: 0 },
    width: 1.8,
    length: 9,
    rise: 0.75,
    gradient: '1:12',
    steep: false,
    location: 'Beside the front steps, west side',
    info: '1:12 gradient · 1.8 m wide · handrails on both sides',
  },
  {
    id: `${b.id}-RE`,
    building: b.id,
    name: 'East entrance ramp',
    from: { lx: 12, z: 12.2, dy: -0.75 },
    to: { lx: 3, z: 12.2, dy: 0 },
    width: 1.8,
    length: 9,
    rise: 0.75,
    gradient: '1:12',
    steep: false,
    location: 'Beside the front steps, east side',
    info: '1:12 gradient · 1.8 m wide · handrails on both sides',
  },
])
export const FRONT_STEPS = BUILDINGS.map((b) => ({ id: `${b.id}-ST`, building: b.id, name: 'Front steps' }))

export const SEGMENT_RANGES = [
  { key: 'W', name: 'West', x0: -21, x1: -5 },
  { key: 'C', name: 'Centre', x0: -5, x1: 5 },
  { key: 'E', name: 'East', x0: 5, x1: 21 },
]
export const CORRIDOR_SEGMENTS = BUILDINGS.flatMap((b) =>
  OPERATIONAL.flatMap((level) =>
    SEGMENT_RANGES.map((s) => ({
      id: `${b.id}-${level}-${s.key}`,
      building: b.id,
      level,
      key: s.key,
      name: `${b.short} · ${floorName(level)} · ${s.name} corridor`,
      shortName: s.name,
      x0: s.x0,
      x1: s.x1,
    })),
  ),
)
export const segmentFor = (bid, level, localMidX) => {
  const s = SEGMENT_RANGES.find((r) => localMidX >= r.x0 && localMidX <= r.x1) ?? SEGMENT_RANGES[1]
  return `${bid}-${level}-${s.key}`
}

export const SITE = {
  gate: { x: 0, z: 38 },
  helpDesk: { x: 7, z: 31 },
}

export const EXITS = BUILDINGS.flatMap((b) => [
  { id: `${b.id}-IN`, building: b.id, name: `${b.short} entrance`, kind: 'entrance', level: 0, x: b.ox, z: 10.4 },
  { id: `${b.id}-EXW`, building: b.id, name: 'Emergency exit', kind: 'exit', level: 0, x: b.ox - 21.4, z: 0 },
  { id: `${b.id}-EXE`, building: b.id, name: 'Emergency exit', kind: 'exit', level: 0, x: b.ox + 21.4, z: 0 },
])

export const yOf = (level, gap) => level * gap
