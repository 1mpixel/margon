// Barrier reports: categories, locating the facility nearest to a strap, and closing it.
import { BUILDINGS, CORRIDOR_SEGMENTS, FRONT_STEPS, LIFTS, OPERATIONAL, RAMPS, STAIRS, buildingById, floorName, floorNameHi } from './buildingData'
import { SOURCE_CONFIDENCE } from './sensors'

export const CATEGORIES = [
  { id: 'lift', en: 'Lift not working', hi: 'लिफ्ट काम नहीं कर रही' },
  { id: 'ramp', en: 'Ramp blocked or damaged', hi: 'रैम्प बंद या टूटा है' },
  { id: 'corridor', en: 'Corridor blocked', hi: 'गलियारा बंद है' },
  { id: 'steps', en: 'Entrance steps blocked', hi: 'प्रवेश की सीढ़ियाँ बंद हैं' },
  { id: 'stairs', en: 'Staircase blocked', hi: 'सीढ़ियाँ बंद हैं' },
]
export const categoryLabel = (id, lang = 'en') => CATEGORIES.find((c) => c.id === id)?.[lang] ?? id

const blockAt = (x) => BUILDINGS.reduce((b, c) => (Math.abs(x - c.ox) < Math.abs(x - b.ox) ? c : b))

/** Facility of the given category nearest to a strap reading { x, z, level }. */
export function nearestTarget(category, tm) {
  if (!tm) return null
  const b = blockAt(tm.x)
  const lx = tm.x - b.ox
  if (category === 'lift') {
    return LIFTS.filter((l) => l.building === b.id).reduce((best, l) => (Math.abs(l.lx - lx) < Math.abs(best.lx - lx) ? l : best)).id
  }
  if (category === 'ramp') {
    const rs = RAMPS.filter((r) => r.building === b.id)
    const mid = (r) => (r.from.lx + r.to.lx) / 2
    return rs.reduce((best, r) => (Math.abs(mid(r) - lx) < Math.abs(mid(best) - lx) ? r : best)).id
  }
  if (category === 'stairs') {
    return STAIRS.filter((s) => s.building === b.id).reduce((best, s) => (Math.abs(s.lx - lx) < Math.abs(best.lx - lx) ? s : best)).id
  }
  if (category === 'steps') return FRONT_STEPS.find((s) => s.building === b.id).id
  if (category === 'corridor') {
    const level = OPERATIONAL.includes(tm.level) ? tm.level : 0
    const segs = CORRIDOR_SEGMENTS.filter((s) => s.building === b.id && s.level === level)
    return (segs.find((s) => lx >= s.x0 && lx <= s.x1) ?? segs[1]).id
  }
  return null
}

export function targetLabel(category, target, lang = 'en') {
  const hi = lang === 'hi'
  if (!target) return '-'
  if (category === 'lift') {
    const l = LIFTS.find((x) => x.id === target)
    const b = buildingById[l.building]
    return hi ? `लिफ्ट ${l.label}, ${b.nameHi}` : `Lift ${l.label}, ${b.short} Block`
  }
  if (category === 'ramp') {
    const r = RAMPS.find((x) => x.id === target)
    const b = buildingById[r.building]
    return hi ? `${target.endsWith('RW') ? 'पश्चिमी' : 'पूर्वी'} रैम्प, ${b.nameHi}` : `${r.name}, ${b.short} Block`
  }
  if (category === 'stairs') {
    const s = STAIRS.find((x) => x.id === target)
    const b = buildingById[s.building]
    return hi ? `सीढ़ियाँ, ${b.nameHi}` : `${s.name}, ${b.short} Block`
  }
  if (category === 'steps') {
    const b = buildingById[target.split('-')[0]]
    return hi ? `सामने की सीढ़ियाँ, ${b.nameHi}` : `Front steps, ${b.short} Block`
  }
  if (category === 'corridor') {
    const s = CORRIDOR_SEGMENTS.find((x) => x.id === target)
    const b = buildingById[s.building]
    return hi ? `${floorNameHi(s.level)} का गलियारा, ${b.nameHi}` : `${s.shortName} corridor, ${floorName(s.level)}, ${b.short} Block`
  }
  return target
}

/** Facility state with the reported item closed. */
export function closeInFacility(fac, category, target) {
  if (category === 'lift') return { ...fac, elevators: { ...fac.elevators, [target]: false } }
  if (category === 'ramp') return { ...fac, ramps: { ...fac.ramps, [target]: false } }
  if (category === 'stairs' || category === 'steps') return { ...fac, stairs: { ...fac.stairs, [target]: false } }
  if (category === 'corridor') return fac.blocked.includes(target) ? fac : { ...fac, blocked: [...fac.blocked, target] }
  return fac
}

export function isClosed(fac, category, target) {
  if (category === 'lift') return fac.elevators[target] === false
  if (category === 'ramp') return fac.ramps[target] === false
  if (category === 'stairs' || category === 'steps') return fac.stairs[target] === false
  if (category === 'corridor') return fac.blocked.includes(target)
  return false
}

export const visitorConfidence = (hasPhoto) => (hasPhoto ? SOURCE_CONFIDENCE.visitorPhoto : SOURCE_CONFIDENCE.visitor)
