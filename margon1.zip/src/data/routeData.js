// Navigation graph, step-free routing and turn-by-turn instructions (English and Hindi)
// for the two GL BAJAJ blocks. The graph follows corridor centre-lines, door openings,
// lift landings and cars, stair landings, entrance ramps and the campus paths.

import {
  BUILDING,
  BUILDINGS,
  CORRIDOR_SEGMENTS,
  FRONT_STEPS,
  LIFTS,
  OPERATIONAL,
  RAMPS,
  SITE,
  STAIRS,
  buildingById,
  floorName,
  floorNameHi,
  segmentFor,
} from './buildingData'
import { ROOMS, roomById } from './roomData'

const H = BUILDING.realFloorHeight
const G = BUILDING.gradeLevel

// ───────────────────────── Graph ─────────────────────────
function buildGraph() {
  const nodes = {}
  const edges = []
  const adj = {}
  const addNode = (id, level, x, z, extra = {}) => {
    nodes[id] = { id, level, x, z, dy: 0, kind: 'point', label: '', labelHi: '', ...extra }
    adj[id] = []
  }
  const addEdge = (a, b, type, extra = {}) => {
    const A = nodes[a]
    const B = nodes[b]
    const horiz = Math.hypot(A.x - B.x, A.z - B.z)
    const vert = type === 'elevator' || type === 'stairs' ? 0 : Math.abs(A.dy - B.dy)
    const e = { id: `${a}|${b}`, a, b, type, len: extra.len ?? Math.hypot(horiz, vert), horiz: extra.horiz ?? horiz, ...extra }
    edges.push(e)
    adj[a].push(e)
    adj[b].push(e)
  }

  for (const b of BUILDINGS) {
    const lifts = LIFTS.filter((l) => l.building === b.id)
    const stairs = STAIRS.filter((s) => s.building === b.id)
    for (const level of OPERATIONAL) {
      const xs = new Set([...lifts.map((l) => l.lx), ...stairs.map((s) => s.lx)])
      ROOMS.filter((r) => r.building === b.id && r.level === level).forEach((r) => xs.add(r.doorX))
      if (level === 0) {
        xs.add(-21)
        xs.add(21)
      }
      const sorted = [...xs].sort((p, q) => p - q)
      sorted.forEach((x) =>
        addNode(`${b.id}:C${level}:${x}`, level, b.ox + x, 0, { building: b.id, kind: 'corridor', label: `${floorName(level)} corridor`, labelHi: `${floorNameHi(level)} का गलियारा` }),
      )
      for (let i = 0; i < sorted.length - 1; i++)
        addEdge(`${b.id}:C${level}:${sorted[i]}`, `${b.id}:C${level}:${sorted[i + 1]}`, 'corridor', {
          level,
          building: b.id,
          segment: segmentFor(b.id, level, (sorted[i] + sorted[i + 1]) / 2),
        })
      if (level === 0) {
        nodes[`${b.id}:C0:-21`].label = 'Emergency exit'
        nodes[`${b.id}:C0:21`].label = 'Emergency exit'
      }
    }
    for (const r of ROOMS.filter((rm) => rm.building === b.id && OPERATIONAL.includes(rm.level))) {
      addNode(r.id, r.level, r.gx, r.side === 'F' ? 3.5 : -3.5, { building: b.id, kind: 'room', label: r.name, labelHi: r.nameHi, room: r.id })
      addEdge(`${b.id}:C${r.level}:${r.doorX}`, r.id, 'door', { level: r.level, building: b.id })
    }
    for (const l of lifts) {
      l.serves.forEach((level) => {
        addNode(`${l.id}:d${level}`, level, l.x, l.doorZ, { building: b.id, kind: 'liftDoor', label: `Lift ${l.label} lobby`, labelHi: `लिफ्ट ${l.label}`, elev: l.id })
        addNode(`${l.id}:${level}`, level, l.x, l.carZ, { building: b.id, kind: 'liftCar', label: `Lift ${l.label}`, labelHi: `लिफ्ट ${l.label}`, elev: l.id })
        addEdge(`${b.id}:C${level}:${l.lx}`, `${l.id}:d${level}`, 'link', { elev: l.id, level, building: b.id })
        addEdge(`${l.id}:d${level}`, `${l.id}:${level}`, 'board', { elev: l.id, level, building: b.id, wait: 20 })
      })
      for (let i = 0; i < l.serves.length - 1; i++) {
        const d = l.serves[i + 1] - l.serves[i]
        addEdge(`${l.id}:${l.serves[i]}`, `${l.id}:${l.serves[i + 1]}`, 'elevator', { elev: l.id, building: b.id, len: H * d, horiz: 0, floors: d })
      }
    }
    for (const s of stairs) {
      OPERATIONAL.forEach((level) => {
        addNode(`${s.id}:${level}`, level, s.x, s.nodeZ, { building: b.id, kind: 'stair', label: s.name, labelHi: 'सीढ़ियाँ', stair: s.id })
        addEdge(`${b.id}:C${level}:${s.lx}`, `${s.id}:${level}`, 'link', { stair: s.id, level, building: b.id })
      })
      for (let i = 0; i < OPERATIONAL.length - 1; i++) {
        const d = OPERATIONAL[i + 1] - OPERATIONAL[i]
        addEdge(`${s.id}:${OPERATIONAL[i]}`, `${s.id}:${OPERATIONAL[i + 1]}`, 'stairs', { stair: s.id, building: b.id, len: 7 * d, horiz: 0 })
      }
    }

    // Entrance: steps in the middle, a 1:12 ramp on each side
    const o = b.ox
    const ent = { building: b.id, kind: 'door', label: `${b.name} entrance`, labelHi: `${b.nameHi} का प्रवेश द्वार` }
    addNode(`${b.id}:ENT`, 0, o, 10, ent)
    addNode(`${b.id}:PLAT`, 0, o, 12, { building: b.id, kind: 'exterior', label: 'entrance platform', labelHi: 'प्रवेश मंच' })
    addNode(`${b.id}:RWT`, 0, o - 3, 12.2, { building: b.id, kind: 'exterior', label: 'west ramp', labelHi: 'पश्चिमी रैम्प' })
    addNode(`${b.id}:RWB`, 0, o - 12, 12.2, { building: b.id, kind: 'exterior', label: 'west ramp', labelHi: 'पश्चिमी रैम्प', dy: G })
    addNode(`${b.id}:RET`, 0, o + 3, 12.2, { building: b.id, kind: 'exterior', label: 'east ramp', labelHi: 'पूर्वी रैम्प' })
    addNode(`${b.id}:REB`, 0, o + 12, 12.2, { building: b.id, kind: 'exterior', label: 'east ramp', labelHi: 'पूर्वी रैम्प', dy: G })
    addNode(`${b.id}:SB`, 0, o, 15.8, { building: b.id, kind: 'exterior', label: 'front steps', labelHi: 'सामने की सीढ़ियाँ', dy: G })
    addNode(`${b.id}:JW`, 0, o - 12, 18, { building: b.id, kind: 'exterior', label: `${b.short} west ramp`, labelHi: `${b.nameHi} के पश्चिमी रैम्प`, dy: G })
    addNode(`${b.id}:JS`, 0, o, 18, { building: b.id, kind: 'exterior', label: `${b.short} entrance`, labelHi: `${b.nameHi} के प्रवेश`, dy: G })
    addNode(`${b.id}:JE`, 0, o + 12, 18, { building: b.id, kind: 'exterior', label: `${b.short} east ramp`, labelHi: `${b.nameHi} के पूर्वी रैम्प`, dy: G })
    addEdge(`${b.id}-LOBBY`, `${b.id}:ENT`, 'door', { level: 0, building: b.id })
    addEdge(`${b.id}:ENT`, `${b.id}:PLAT`, 'door', { level: 0, building: b.id })
    addEdge(`${b.id}:PLAT`, `${b.id}:RWT`, 'path', { level: 0 })
    addEdge(`${b.id}:RWT`, `${b.id}:RWB`, 'ramp', { ramp: `${b.id}-RW`, level: 0 })
    addEdge(`${b.id}:PLAT`, `${b.id}:RET`, 'path', { level: 0 })
    addEdge(`${b.id}:RET`, `${b.id}:REB`, 'ramp', { ramp: `${b.id}-RE`, level: 0 })
    addEdge(`${b.id}:PLAT`, `${b.id}:SB`, 'stairs', { stair: `${b.id}-ST`, len: 4, horiz: 3.8 })
    addEdge(`${b.id}:RWB`, `${b.id}:JW`, 'path', { level: 0 })
    addEdge(`${b.id}:REB`, `${b.id}:JE`, 'path', { level: 0 })
    addEdge(`${b.id}:SB`, `${b.id}:JS`, 'path', { level: 0 })
    addEdge(`${b.id}:JW`, `${b.id}:JS`, 'path', { level: 0 })
    addEdge(`${b.id}:JS`, `${b.id}:JE`, 'path', { level: 0 })
  }

  // Campus: forecourt path, Help Desk at the main gate
  const ext = { kind: 'exterior', dy: G }
  addNode('J0', 0, 0, 18, { ...ext, label: 'forecourt', labelHi: 'प्रांगण' })
  addNode('HDJ', 0, 0, SITE.helpDesk.z, { ...ext, label: 'main walkway', labelHi: 'मुख्य पथ' })
  addNode('HD', 0, SITE.helpDesk.x, SITE.helpDesk.z, { ...ext, kind: 'helpdesk', label: 'Help Desk', labelHi: 'सहायता डेस्क' })
  addNode('GATE', 0, SITE.gate.x, SITE.gate.z, { ...ext, kind: 'gate', label: 'Main Gate', labelHi: 'मुख्य द्वार' })
  addEdge('B1:JE', 'J0', 'path', { level: 0 })
  addEdge('J0', 'B2:JW', 'path', { level: 0 })
  addEdge('J0', 'HDJ', 'path', { level: 0 })
  addEdge('HDJ', 'HD', 'path', { level: 0 })
  addEdge('HDJ', 'GATE', 'path', { level: 0 })
  return { nodes, edges, adj }
}

export const GRAPH = buildGraph()
export const nodePosition = (node, gap, lift = 0) => [node.x, node.level * gap + node.dy + lift, node.z]

// ───────────────────────── Start points ─────────────────────────
export const START_POINTS = [
  { id: 'HD', name: 'Help Desk (Main Gate)', nameHi: 'सहायता डेस्क (मुख्य द्वार)' },
  { id: 'GATE', name: 'Main Gate', nameHi: 'मुख्य द्वार' },
  { id: 'B1-LOBBY', name: 'AI & ML Block lobby', nameHi: 'एआई एवं एमएल ब्लॉक लॉबी' },
  { id: 'B2-LOBBY', name: 'CSDS Block lobby', nameHi: 'सीएसडीएस ब्लॉक लॉबी' },
]
const startById = Object.fromEntries(START_POINTS.map((s) => [s.id, s]))

export const nodeLabel = (id, lang = 'en') => {
  const s = startById[id]
  if (s) return lang === 'hi' ? s.nameHi : s.name
  const r = roomById[id]
  if (r) return lang === 'hi' ? r.nameHi : r.name
  const n = GRAPH.nodes[id]
  return (lang === 'hi' ? n?.labelHi : n?.label) || n?.label || id
}

// ───────────────────────── Facilities ─────────────────────────
const all = (list) => Object.fromEntries(list.map((x) => [x.id, true]))
export const NORMAL_FACILITIES = {
  elevators: all(LIFTS),
  ramps: all(RAMPS),
  stairs: { ...all(STAIRS), ...all(FRONT_STEPS) },
  blocked: [],
}
export const withDefaults = (f = {}) => ({
  elevators: { ...NORMAL_FACILITIES.elevators, ...(f.elevators ?? {}) },
  ramps: { ...NORMAL_FACILITIES.ramps, ...(f.ramps ?? {}) },
  stairs: { ...NORMAL_FACILITIES.stairs, ...(f.stairs ?? {}) },
  blocked: Array.isArray(f.blocked) ? f.blocked : [],
})

export const DEFAULT_PROFILE = { wheelchair: true, avoidStairs: true, preferElevators: true, avoidSteepRamps: true, mode: 'ramp' }

// Visitor route preference.
//  ramp  : ramp + lift, completely step-free (wheelchair)
//  steps : front steps allowed at the entrance, lifts between floors (can manage a few steps)
export const PREFERENCES = [
  { id: 'ramp', en: 'Ramp + Lift', enSub: 'Completely step-free', hi: 'रैम्प + लिफ्ट', hiSub: 'पूरी तरह बिना सीढ़ी' },
  { id: 'steps', en: 'Steps + Lift', enSub: 'A few entrance steps are fine', hi: 'सीढ़ी + लिफ्ट', hiSub: 'प्रवेश की कुछ सीढ़ियाँ ठीक हैं' },
]
export const profileFor = (mode) =>
  mode === 'steps'
    ? { wheelchair: false, avoidStairs: false, preferElevators: true, avoidSteepRamps: true, mode: 'steps' }
    : { ...DEFAULT_PROFILE, mode: 'ramp' }

function edgeWeight(e, f, profile) {
  if (e.type === 'stairs') {
    if (f.stairs[e.stair] === false) return Infinity
    if (profile.wheelchair || profile.avoidStairs) return Infinity
    if (e.stair?.endsWith('-ST')) return e.len * 0.9 // short flight at the entrance
    return e.len * (profile.preferElevators ? 6 : 1.1)
  }
  if (e.elev && f.elevators[e.elev] === false && (e.type === 'board' || e.type === 'elevator')) return Infinity
  if (e.type === 'corridor' && f.blocked.includes(e.segment)) return Infinity
  if (e.type === 'ramp') return f.ramps[e.ramp] === false ? Infinity : e.len * 1.15
  if (e.type === 'board') return e.len + 9
  if (e.type === 'elevator') return e.len * 0.6
  return e.len
}

// Binary min-heap used as the priority queue for Dijkstra and A*.
export class MinHeap {
  constructor() {
    this.a = []
  }
  get size() {
    return this.a.length
  }
  push(key, value) {
    const a = this.a
    a.push([key, value])
    let i = a.length - 1
    while (i > 0) {
      const p = (i - 1) >> 1
      if (a[p][0] <= a[i][0]) break
      ;[a[p], a[i]] = [a[i], a[p]]
      i = p
    }
  }
  pop() {
    const a = this.a
    const top = a[0]
    const last = a.pop()
    if (a.length) {
      a[0] = last
      let i = 0
      for (;;) {
        const l = 2 * i + 1
        const r = l + 1
        let m = i
        if (l < a.length && a[l][0] < a[m][0]) m = l
        if (r < a.length && a[r][0] < a[m][0]) m = r
        if (m === i) break
        ;[a[m], a[i]] = [a[i], a[m]]
        i = m
      }
    }
    return top
  }
}

// Admissible A* heuristic: no edge costs less than 0.9 × its horizontal length
// (front steps) or 0.6 × its vertical rise (lift), so this never overestimates.
const realY = (n) => n.level * H + n.dy
export function heuristic(a, b) {
  return 0.9 * Math.hypot(a.x - b.x, a.z - b.z) + 0.6 * Math.abs(realY(a) - realY(b))
}

let ENGINE = 'astar'
export const setEngine = (e) => {
  ENGINE = e === 'dijkstra' ? 'dijkstra' : 'astar'
}
export const getEngine = () => ENGINE

/** Shortest accessible path. algo: 'dijkstra' | 'astar'. Returns path, cost and search statistics. */
export function search(start, goal, f, profile, algo = ENGINE) {
  const { nodes, adj } = GRAPH
  if (!nodes[start] || !nodes[goal]) return null
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now()
  const G = nodes[goal]
  const h = algo === 'astar' ? (id) => heuristic(nodes[id], G) : () => 0
  const dist = new Map([[start, 0]])
  const prev = new Map()
  const closed = new Set()
  const pq = new MinHeap()
  pq.push(h(start), start)
  let expanded = 0
  let pushes = 1
  while (pq.size) {
    const [, u] = pq.pop()
    if (closed.has(u)) continue // stale queue entry (lazy deletion)
    closed.add(u)
    expanded++
    if (u === goal) break
    const du = dist.get(u)
    for (const e of adj[u]) {
      const v = e.a === u ? e.b : e.a
      if (closed.has(v)) continue
      const w = edgeWeight(e, f, profile)
      if (!Number.isFinite(w)) continue
      const nd = du + w
      if (nd < (dist.get(v) ?? Infinity)) {
        dist.set(v, nd)
        prev.set(v, { node: u, edge: e })
        pq.push(nd + h(v), v)
        pushes++
      }
    }
  }
  const ms = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0
  if (!dist.has(goal) || !closed.has(goal)) return { found: false, expanded, pushes, ms, algo }
  const nodeIds = [goal]
  const pathEdges = []
  let cur = goal
  while (cur !== start) {
    const p = prev.get(cur)
    pathEdges.unshift(p.edge)
    nodeIds.unshift(p.node)
    cur = p.node
  }
  return { found: true, nodeIds, edges: pathEdges, cost: dist.get(goal), expanded, pushes, ms, algo }
}

function dijkstra(start, goal, f, profile, algo = ENGINE) {
  const r = search(start, goal, f, profile, algo)
  return r?.found ? r : null
}

// ───────────────────────── Turn-by-turn steps ─────────────────────────
const cls = (e) => {
  if (e.elev) return 'lift'
  if (e.stair) return 'stairs'
  if (e.type === 'ramp') return 'ramp'
  if (e.type === 'corridor' || e.type === 'path') return 'walk'
  return 'door'
}
const heading = (a, b) => {
  const dx = b.x - a.x
  const dz = b.z - a.z
  const l = Math.hypot(dx, dz)
  return l < 1e-6 ? null : { x: dx / l, z: dz / l }
}
// Facing +x, right-hand side is +z, so a positive cross product is a right turn.
const turnOf = (h0, h1) => {
  if (!h0 || !h1) return null
  const dot = h0.x * h1.x + h0.z * h1.z
  const cross = h0.x * h1.z - h0.z * h1.x
  if (dot > 0.93) return 'straight'
  if (dot < -0.8) return 'back'
  return cross > 0 ? 'right' : 'left'
}

function buildSteps(nodeIds, edges, destId) {
  const { nodes } = GRAPH
  const steps = []
  let last = null // last horizontal heading
  let i = 0
  while (i < edges.length) {
    const c = cls(edges[i])
    let j = i
    const h0 = heading(nodes[nodeIds[i]], nodes[nodeIds[i + 1]])
    while (j + 1 < edges.length && cls(edges[j + 1]) === c) {
      if (c === 'door') break
      if (c === 'lift' && edges[j + 1].elev !== edges[i].elev) break
      if (c === 'walk') {
        const hn = heading(nodes[nodeIds[j + 1]], nodes[nodeIds[j + 2]])
        if (!hn || !h0 || h0.x * hn.x + h0.z * hn.z < 0.93) break
        if (edges[j + 1].type !== edges[i].type) break
      }
      j++
    }
    const from = nodes[nodeIds[i]]
    const to = nodes[nodeIds[j + 1]]
    const dist = Math.max(1, Math.round(edges.slice(i, j + 1).reduce((s, e) => s + e.horiz, 0)))
    const base = { i0: i, i1: j, level: from.level, building: from.building ?? to.building, dist }
    const e0 = edges[i]
    if (c === 'walk') {
      steps.push({ ...base, kind: 'walk', where: e0.type === 'corridor' ? 'corridor' : 'path', turn: turnOf(last, h0), toward: to.kind === 'corridor' ? null : to.id })
      last = heading(nodes[nodeIds[j]], to) ?? h0
    } else if (c === 'lift') {
      const levels = nodeIds.slice(i, j + 2).map((id) => nodes[id].level)
      const l0 = levels[0]
      const l1 = levels[levels.length - 1]
      const lift = LIFTS.find((l) => l.id === e0.elev)
      steps.push({ ...base, kind: 'lift', lift: lift.label, liftId: lift.id, fromLevel: l0, toLevel: l1, dir: l1 > l0 ? 'up' : 'down', dist: 0 })
      last = { x: 0, z: -1 } // leaving the car towards the corridor
    } else if (c === 'stairs') {
      steps.push({ ...base, kind: 'stairs', warn: true, front: e0.stair.endsWith('-ST'), fromLevel: from.level, toLevel: to.level })
      last = null
    } else if (c === 'ramp') {
      const ramp = RAMPS.find((r) => r.id === e0.ramp)
      steps.push({ ...base, kind: 'ramp', turn: turnOf(last, h0), ramp: ramp.id, rampName: ramp.name, gradient: ramp.gradient, length: ramp.length, up: to.dy > from.dy })
      last = h0
    } else {
      const mode = to.kind === 'room' ? 'enter' : from.kind === 'room' ? 'exit' : to.kind === 'door' ? 'entrance-in' : 'entrance-out'
      steps.push({ ...base, kind: 'door', mode, turn: mode === 'exit' ? null : turnOf(last, h0), room: to.kind === 'room' ? to.id : from.kind === 'room' ? from.id : null })
      last = h0
    }
    i = j + 1
  }
  // Passing through a building lobby is one instruction, not three.
  for (let k = 0; k < steps.length; k++) {
    const s = steps[k]
    if (s.kind === 'door' && s.mode === 'entrance-in') {
      s.turn = 'straight'
      const a = steps[k + 1]
      const b = steps[k + 2]
      if (a?.kind === 'door' && a.mode === 'enter' && roomById[a.room]?.type === 'lobby' && a.room !== destId && b?.kind === 'door' && b.mode === 'exit') {
        s.i1 = b.i1
        steps.splice(k + 1, 2)
      }
    }
  }
  const dest = nodes[destId]
  steps.push({ kind: 'arrive', i0: edges.length - 1, i1: edges.length - 1, level: dest.level, building: dest.building, room: destId, dist: 0 })
  steps.forEach((s) => (s.text = formatStep(s, 'en')))
  return steps
}

const TURN_EN = { left: 'Turn left', right: 'Turn right', back: 'Turn around', straight: 'Go straight' }
const TURN_HI = { left: 'बाएँ मुड़ें', right: 'दाएँ मुड़ें', back: 'पीछे मुड़ें', straight: 'सीधे चलें' }
const TURN_HI_PART = { left: 'बाएँ मुड़कर', right: 'दाएँ मुड़कर', back: 'पीछे मुड़कर', straight: 'सीधे' }

export function formatStep(s, lang = 'en') {
  const hi = lang === 'hi'
  const fl = (l) => (hi ? floorNameHi(l) : `the ${floorName(l)}`)
  const blk = (bid) => (hi ? buildingById[bid]?.nameHi : buildingById[bid]?.name) ?? ''
  const room = (id) => nodeLabel(id, lang)
  switch (s.kind) {
    case 'walk': {
      const toward = s.toward ? (hi ? `, ${nodeLabel(s.toward, 'hi')} की ओर` : ` towards the ${nodeLabel(s.toward)}`) : ''
      if (s.where === 'corridor') {
        if (hi) return s.turn && s.turn !== 'straight' ? `${TURN_HI[s.turn]} और ${fl(s.level)} के गलियारे में ${s.dist} मीटर चलें` : `${fl(s.level)} के गलियारे में सीधे ${s.dist} मीटर चलें`
        return s.turn && s.turn !== 'straight' ? `${TURN_EN[s.turn]} and go ${s.dist} m along ${fl(s.level)} corridor` : `Go straight ${s.dist} m along ${fl(s.level)} corridor`
      }
      if (hi) return s.turn && s.turn !== 'straight' ? `${TURN_HI[s.turn]} और पथ पर ${s.dist} मीटर चलें${toward}` : `पथ पर सीधे ${s.dist} मीटर चलें${toward}`
      return s.turn && s.turn !== 'straight' ? `${TURN_EN[s.turn]} and follow the path for ${s.dist} m${toward}` : `Follow the path straight for ${s.dist} m${toward}`
    }
    case 'lift':
      return hi
        ? `लिफ्ट ${s.lift} से ${fl(s.toLevel)} पर ${s.dir === 'up' ? 'ऊपर' : 'नीचे'} जाएँ`
        : `Take Lift ${s.lift} ${s.dir} to ${fl(s.toLevel)}`
    case 'stairs':
      return hi
        ? s.front
          ? 'सामने की सीढ़ियों से प्रवेश मंच पर जाएँ (सीढ़ियाँ हैं)'
          : `सीढ़ियों से ${fl(s.toLevel)} पर जाएँ (सीढ़ियाँ हैं)`
        : s.front
          ? 'Use the front steps to the entrance platform (not step-free)'
          : `Take the stairs to ${fl(s.toLevel)} (not step-free)`
    case 'ramp': {
      const name = hi ? (s.ramp.endsWith('RW') ? 'पश्चिमी प्रवेश रैम्प' : 'पूर्वी प्रवेश रैम्प') : `the ${s.rampName.toLowerCase()}`
      if (hi) return `${s.turn && s.turn !== 'straight' ? TURN_HI_PART[s.turn] + ' ' : ''}${name} से ${s.up ? 'ऊपर' : 'नीचे'} जाएँ (ढलान ${s.gradient}, ${s.length} मीटर)`
      return `${s.turn && s.turn !== 'straight' ? TURN_EN[s.turn] + ' and go' : 'Go'} ${s.up ? 'up' : 'down'} ${name} (${s.gradient}, ${s.length} m)`
    }
    case 'door':
      if (s.mode === 'enter') {
        if (hi) return `${s.turn && s.turn !== 'straight' ? TURN_HI_PART[s.turn] + ' ' : ''}${room(s.room)} में प्रवेश करें`
        return `${s.turn && s.turn !== 'straight' ? TURN_EN[s.turn] + ' into' : 'Enter'} ${room(s.room)}`
      }
      if (s.mode === 'exit') return hi ? `${room(s.room)} से निकलकर गलियारे में आएँ` : `Leave ${room(s.room)} into the corridor`
      if (s.mode === 'entrance-in') return hi ? `प्रवेश द्वार से ${blk(s.building)} में जाएँ` : `Go through the entrance doors into the ${blk(s.building)}`
      return hi ? 'प्रवेश द्वार से बाहर निकलें' : 'Go out through the entrance doors'
    case 'arrive': {
      const r = roomById[s.room]
      return hi
        ? `आप ${room(s.room)}${r ? `, ${fl(s.level)}, ${blk(r.building)}` : ''} पहुँच गए हैं`
        : `You have arrived at ${room(s.room)}${r ? `, ${floorName(s.level)}, ${blk(r.building)}` : ''}`
    }
    default:
      return ''
  }
}

// Arrow shown in the guidance card for a step.
export function maneuverOf(s) {
  if (!s) return 'straight'
  if (s.kind === 'arrive') return 'arrive'
  if (s.kind === 'lift') return s.dir === 'up' ? 'lift-up' : 'lift-down'
  if (s.kind === 'stairs') return 'stairs'
  if (s.kind === 'ramp' && (!s.turn || s.turn === 'straight')) return s.up ? 'ramp-up' : 'ramp-down'
  if (s.kind === 'door' && s.mode === 'exit') return 'exit'
  if (s.turn === 'left') return 'left'
  if (s.turn === 'right') return 'right'
  if (s.turn === 'back') return 'uturn'
  return 'straight'
}

function estimateTime(edges, profile) {
  const v = profile.wheelchair ? 1.0 : 1.3
  let t = 0
  let boarded = null
  for (const e of edges) {
    if (e.type === 'elevator') t += 2.5 * (e.floors ?? 1)
    else if (e.type === 'board') {
      if (boarded !== e.elev) t += e.wait ?? 20 // wait once per lift trip
      boarded = e.elev
      continue
    } else if (e.type === 'stairs') t += 9
    else if (e.type === 'ramp') t += e.len / (v * 0.65)
    else t += e.len / v
    if (e.type !== 'elevator' && e.type !== 'link') boarded = null
  }
  return Math.round(t)
}

const liftName = (id) => {
  const l = LIFTS.find((x) => x.id === id)
  return { en: `Lift ${l.label} (${buildingById[l.building].short}) closed`, hi: `लिफ्ट ${l.label} (${buildingById[l.building].nameHi}) बंद` }
}
const rampName = (id) => {
  const r = RAMPS.find((x) => x.id === id)
  return { en: `${buildingById[r.building].short} ${r.name.toLowerCase()} closed`, hi: `${buildingById[r.building].nameHi} का ${id.endsWith('RW') ? 'पश्चिमी' : 'पूर्वी'} रैम्प बंद` }
}
const segName = (id) => {
  const s = CORRIDOR_SEGMENTS.find((x) => x.id === id)
  return { en: `${s.name} closed`, hi: `${buildingById[s.building].nameHi}, ${floorNameHi(s.level)} का गलियारा बंद` }
}

function disruptionsOn(edges, f) {
  const reasons = []
  const seen = new Set()
  const blockedEdges = []
  const push = (key, r) => {
    if (!seen.has(key)) {
      seen.add(key)
      reasons.push(r)
    }
  }
  for (const e of edges) {
    if (e.elev && f.elevators[e.elev] === false && (e.type === 'board' || e.type === 'elevator')) {
      blockedEdges.push(e)
      push(e.elev, liftName(e.elev))
    }
    if (e.type === 'ramp' && f.ramps[e.ramp] === false) {
      blockedEdges.push(e)
      push(e.ramp, rampName(e.ramp))
    }
    if (e.type === 'corridor' && f.blocked.includes(e.segment)) {
      blockedEdges.push(e)
      push(e.segment, segName(e.segment))
    }
  }
  return { reasons, blockedEdges }
}

export function closureList(f) {
  const out = []
  Object.entries(f.elevators).forEach(([k, v]) => v === false && out.push(liftName(k)))
  Object.entries(f.ramps).forEach(([k, v]) => v === false && out.push(rampName(k)))
  Object.entries(f.stairs).forEach(([k, v]) => {
    if (v !== false) return
    const s = STAIRS.find((x) => x.id === k)
    const b = buildingById[k.split('-')[0]]
    out.push(s ? { en: `${b.short} ${s.name.toLowerCase()} closed`, hi: `${b.nameHi} की सीढ़ियाँ बंद` } : { en: `${b.short} front steps closed`, hi: `${b.nameHi} की सामने की सीढ़ियाँ बंद` })
  })
  f.blocked.forEach((id) => out.push(segName(id)))
  return out
}

export function computeRoute(startId, destId, facIn, profile = DEFAULT_PROFILE) {
  if (!startId || !destId) return null
  const f = withDefaults(facIn)
  if (startId === destId) return { ok: false, kind: 'none', reasons: [], message: 'You are already at the destination.', messageHi: 'आप पहले से गंतव्य पर हैं।' }
  const baseline = dijkstra(startId, destId, NORMAL_FACILITIES, profile)
  const current = dijkstra(startId, destId, f, profile)
  const affected = baseline ? disruptionsOn(baseline.edges, f) : { reasons: [], blockedEdges: [] }
  if (!current) {
    return {
      ok: false,
      kind: 'none',
      startId,
      destId,
      reasons: closureList(f),
      baselineBlockedEdges: affected.blockedEdges,
      message: 'No step-free route is available right now. Please contact the Help Desk at the main gate.',
      messageHi: 'अभी कोई सुलभ मार्ग उपलब्ध नहीं है। कृपया मुख्य द्वार पर सहायता डेस्क से संपर्क करें।',
    }
  }
  const same = baseline && baseline.edges.map((e) => e.id).join() === current.edges.map((e) => e.id).join()
  const stats = { algo: current.algo, expanded: current.expanded, pushes: current.pushes, ms: current.ms, cost: current.cost }
  const levels = current.nodeIds.map((id) => GRAPH.nodes[id].level)
  return {
    ok: true,
    kind: same ? 'primary' : 'alternative',
    startId,
    destId,
    nodeIds: current.nodeIds,
    edges: current.edges,
    distance: Math.round(current.edges.reduce((s, e) => s + e.horiz, 0)),
    startLevel: levels[0],
    endLevel: levels[levels.length - 1],
    floorChanges: Math.abs(levels[levels.length - 1] - levels[0]),
    timeSec: estimateTime(current.edges, profile),
    elevatorsUsed: [...new Set(current.edges.filter((e) => e.type === 'elevator').map((e) => e.elev))],
    liftLabels: [...new Set(current.edges.filter((e) => e.type === 'elevator').map((e) => LIFTS.find((l) => l.id === e.elev).label))],
    usesStairs: current.edges.some((e) => e.type === 'stairs'),
    hasWarning: false,
    reasons: same ? [] : affected.reasons,
    baselineBlockedEdges: same ? [] : affected.blockedEdges,
    stats,
    instructions: buildSteps(current.nodeIds, current.edges, destId),
  }
}

export const formatTime = (s, lang = 'en') => {
  if (s == null) return '-'
  const m = Math.floor(s / 60)
  const r = s % 60
  if (lang === 'hi') return m ? `${m} मिनट ${r} सेकंड` : `${r} सेकंड`
  return m ? `${m} min ${String(r).padStart(2, '0')} s` : `${r} s`
}

// ───────────────────────── Multi-stop trips ─────────────────────────
// Orders the visitor's stops for the shortest total travel time (exact for up to 7 stops).
export function orderStops(origin, stops, facIn, profile, endAt = null) {
  const f = withDefaults(facIn)
  const pts = [origin, ...stops, ...(endAt ? [endAt] : [])]
  const n = pts.length
  const cost = Array.from({ length: n }, () => Array(n).fill(Infinity))
  for (let i = 0; i < n; i++)
    for (let j = 0; j < n; j++) {
      if (i === j) continue
      const r = dijkstra(pts[i], pts[j], f, profile)
      if (r) cost[i][j] = estimateTime(r.edges, profile)
    }
  const idx = stops.map((_, k) => k + 1)
  const endIdx = endAt ? n - 1 : null
  const total = (perm) => {
    let t = 0
    let prev = 0
    for (const k of perm) {
      t += cost[prev][k]
      prev = k
    }
    if (endIdx !== null) t += cost[prev][endIdx]
    return t
  }
  let best = idx
  if (idx.length <= 7) {
    let bestT = Infinity
    const permute = (arr, l) => {
      if (l === arr.length) {
        const t = total(arr)
        if (t < bestT) {
          bestT = t
          best = [...arr]
        }
        return
      }
      for (let i = l; i < arr.length; i++) {
        ;[arr[l], arr[i]] = [arr[i], arr[l]]
        permute(arr, l + 1)
        ;[arr[l], arr[i]] = [arr[i], arr[l]]
      }
    }
    permute([...idx], 0)
  } else {
    const left = new Set(idx)
    best = []
    let cur = 0
    while (left.size) {
      let nb = null
      for (const k of left) if (nb === null || cost[cur][k] < cost[cur][nb]) nb = k
      best.push(nb)
      left.delete(nb)
      cur = nb
    }
  }
  return best.map((k) => stops[k - 1])
}

// ───────────────────────── Service hours ─────────────────────────
export const SERVICE_HOURS = { start: 9, end: 18 }
export const hoursLabel = (lang = 'en') => (lang === 'hi' ? 'सुबह 9 बजे से शाम 6 बजे तक' : '9:00 am to 6:00 pm')
export const withinHours = (d = new Date()) => d.getHours() >= SERVICE_HOURS.start && d.getHours() < SERVICE_HOURS.end

export function validityFor(now = new Date(), afterHours = false) {
  const from = new Date(now)
  from.setHours(SERVICE_HOURS.start, 0, 0, 0)
  const until = new Date(now)
  until.setHours(SERVICE_HOURS.end, 0, 0, 0)
  if (withinHours(now)) return { validFrom: from.getTime(), validUntil: until.getTime(), extended: false }
  if (!afterHours) return null
  // Demonstration outside service hours: valid for 4 hours from issue.
  return { validFrom: now.getTime(), validUntil: now.getTime() + 4 * 3600 * 1000, extended: true }
}

export function tokenState(t, now = Date.now()) {
  if (!t) return 'missing'
  if (t.status !== 'active') return 'closed'
  if (t.validFrom && now < t.validFrom) return 'early'
  if (t.validUntil && now >= t.validUntil) return 'expired'
  return 'ok'
}
