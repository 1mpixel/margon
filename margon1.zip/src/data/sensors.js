// Strap sensing: validation of readings, differential barometry and barrier detection.
// Sensors on the strap: ESP32 (Wi-Fi position + uplink), MPU6050 (accelerometer + gyroscope),
// BMP280/BMP388 (barometric pressure). The Help Desk keeps a reference barometer.

export const HPA_PER_M = 0.12 // near-surface pressure gradient, about 12 Pa per metre
export const FLOOR_H = 4 // metres per floor
export const RAMP_LIMIT_DEG = +((Math.atan(1 / 12) * 180) / Math.PI).toFixed(2) // 1:12 = 4.76°
export const CAMPUS = { x0: -95, x1: 95, z0: -60, z1: 70 }

/**
 * Plausibility checks for one strap reading against the previous one.
 * Returns { ok, issues: [code] }. Rejected readings are not used for position or alerts.
 */
export function validateTelemetry(prev, next) {
  const issues = []
  if (!next || typeof next !== 'object') return { ok: false, issues: ['missing'] }
  const num = (v) => typeof v === 'number' && Number.isFinite(v)
  if (!['x', 'z', 'relHeight', 'pressure', 'ts'].every((k) => num(next[k]))) issues.push('non-numeric')
  if (num(next.pressure) && (next.pressure < 900 || next.pressure > 1100)) issues.push('pressure-range')
  if (num(next.level) && (next.level < 0 || next.level > 10)) issues.push('floor-range')
  if (num(next.relHeight) && (next.relHeight < -2 || next.relHeight > 46)) issues.push('height-range')
  if (num(next.x) && num(next.z) && (next.x < CAMPUS.x0 || next.x > CAMPUS.x1 || next.z < CAMPUS.z0 || next.z > CAMPUS.z1)) issues.push('outside-campus')
  if (prev && num(prev.ts) && num(next.ts)) {
    const dt = (next.ts - prev.ts) / 1000
    if (dt <= 0) issues.push('time-order')
    else {
      const horiz = Math.hypot(next.x - prev.x, next.z - prev.z) / dt
      const vert = Math.abs(next.relHeight - prev.relHeight) / dt
      if (horiz > 3) issues.push('speed') // a wheelchair does not exceed about 3 m/s
      if (vert > 2.5) issues.push('vertical-speed') // faster than a lift (about 1.5 m/s)
    }
  }
  return { ok: issues.length === 0, issues }
}

/** Floor from the strap pressure compared with the Help Desk reference barometer. */
export function floorFromPressure(pStrap, pRef, groundOffsetM = 0) {
  const height = (pRef - pStrap) / HPA_PER_M - groundOffsetM
  const exact = height / FLOOR_H
  const level = Math.max(0, Math.min(10, Math.round(exact)))
  const confidence = +(1 - Math.min(1, Math.abs(exact - level) * 2)).toFixed(2) // 1 at slab level, 0 midway
  return { height: +height.toFixed(2), level, confidence }
}

/** Ramp gradient from the MPU pitch while on a ramp. Flags ramps steeper than 1:12. */
export function detectSteepRamp(pitchDegSamples, toleranceDeg = 0.7) {
  if (!pitchDegSamples?.length) return null
  const mean = pitchDegSamples.reduce((s, v) => s + v, 0) / pitchDegSamples.length
  const steep = mean > RAMP_LIMIT_DEG + toleranceDeg
  return { steep, meanDeg: +mean.toFixed(2), limitDeg: RAMP_LIMIT_DEG }
}

/** Lift not arriving: waiting at the landing for 3+ minutes with no change in height. */
export function detectLiftStall(waitSec, pressureDeltaHpa) {
  return { stalled: waitSec >= 180 && Math.abs(pressureDeltaHpa) < 0.1, waitSec, pressureDeltaHpa }
}

/** Blocked corridor: two or more different straps turned back on the same segment within 15 minutes. */
export function detectTurnBacks(events, windowMs = 15 * 60 * 1000, now = Date.now()) {
  const recent = events.filter((e) => now - e.ts <= windowMs)
  const bySeg = {}
  recent.forEach((e) => {
    bySeg[e.segment] = bySeg[e.segment] ?? new Set()
    bySeg[e.segment].add(e.strapId)
  })
  return Object.entries(bySeg)
    .filter(([, s]) => s.size >= 2)
    .map(([segment, s]) => ({ segment, straps: [...s] }))
}

/** Independent reports combine: P(barrier) = 1 − Π(1 − cᵢ). */
export const SOURCE_CONFIDENCE = { visitor: 0.5, visitorPhoto: 0.6, strap: 0.65 }
export function combinedConfidence(reports) {
  const p = reports.reduce((acc, r) => acc * (1 - (r.confidence ?? 0.5)), 1)
  return +(1 - p).toFixed(2)
}
export const VERIFY_THRESHOLD = 0.85
