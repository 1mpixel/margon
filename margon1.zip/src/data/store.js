// MARGON shared store.
// Hosted (claude.ai artifact): uses the artifact `db` capability so Admin/Help Desk and
// visitors on different devices see the same facility state, tokens and strap positions.
// Own server (node server/server.mjs): REST writes + Server-Sent Events, shared by all devices.
// Local (static hosting, file://): falls back to localStorage + BroadcastChannel (tabs of one browser).
//
// Documents
//   facility/state       { elevators, ramps, stairs, blocked, notice, afterHours, updatedAt }
//   tokens/<TOKEN>       { token, strapId, visitor, startId, destId, profile, status,
//                          issuedAt, returnedAt?, telemetry? }
//   telemetry            { x, z, level, relHeight, pressure, heading, speed, step, progress, nav, ts }
//   reports/<ID>         { id, source: 'visitor'|'strap', category, target, note, photo?, token, strapId,
//                          confidence, evidence, telemetry, ts, status: 'pending'|'verified'|'dismissed' }

import { NORMAL_FACILITIES, withDefaults } from './routeData'

const LS_FAC = 'margon.facility.v4'
const LS_TOK = 'margon.token.v4:'
const LS_REP = 'margon.report.v4:'
const listeners = { facility: new Set(), tokens: new Set(), reports: new Set(), mode: new Set() }
let mode = 'connecting' // 'connecting' | 'shared' | 'server' | 'local'
let db = null
let cache = { facility: { ...NORMAL_FACILITIES, notice: '', afterHours: false, engine: 'astar', updatedAt: 0 }, tokens: {}, reports: {} }
let bc = null

const valueOf = (key) => (key === 'mode' ? mode : cache[key])
const emit = (key) => listeners[key].forEach((fn) => fn(valueOf(key)))
const emitAll = () => ['facility', 'tokens', 'reports'].forEach(emit)

// Local mode keeps one storage key per document, so tabs never overwrite each other's documents.
function readLocal() {
  try {
    const f = localStorage.getItem(LS_FAC)
    if (f) {
      const v = JSON.parse(f)
      cache.facility = { ...withDefaults(v), notice: v.notice ?? '', afterHours: !!v.afterHours, engine: v.engine ?? 'astar', updatedAt: v.updatedAt ?? 0 }
    }
    const t = {}
    const r = {}
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i)
      if (k?.startsWith(LS_TOK)) t[k.slice(LS_TOK.length)] = JSON.parse(localStorage.getItem(k))
      if (k?.startsWith(LS_REP)) r[k.slice(LS_REP.length)] = JSON.parse(localStorage.getItem(k))
    }
    cache.tokens = t
    cache.reports = r
  } catch {
    /* storage unavailable: keep in-memory state */
  }
}
function writeLocal(key, value) {
  try {
    if (value === null) localStorage.removeItem(key)
    else localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* ignore */
  }
  try {
    bc?.postMessage('changed')
  } catch {
    /* ignore */
  }
}

function startLocal() {
  mode = 'local'
  readLocal()
  try {
    bc = new BroadcastChannel('margon')
    bc.onmessage = () => {
      readLocal()
      emitAll()
    }
  } catch {
    bc = null
  }
  window.addEventListener('storage', (e) => {
    if (e.key && e.key !== LS_FAC && !e.key.startsWith(LS_TOK) && !e.key.startsWith(LS_REP)) return
    readLocal()
    emitAll()
  })
  emit('mode')
  emitAll()
}

function startShared(handle) {
  db = handle
  mode = 'shared'
  emit('mode')
  db.doc('facility/state').onSnapshot(
    (snap) => {
      const d = snap.exists ? snap.data() : {}
      cache.facility = { ...withDefaults(d), notice: d?.notice ?? '', afterHours: !!d?.afterHours, engine: d?.engine ?? 'astar', updatedAt: d?.updatedAt ?? 0 }
      emit('facility')
    },
    () => {},
  )
  db.collection('tokens').onSnapshot(
    (qs) => {
      const t = {}
      qs.docs.forEach((d) => (t[d.id] = d.data()))
      cache.tokens = t
      emit('tokens')
    },
    () => {},
  )
  db.collection('reports').onSnapshot(
    (qs) => {
      const r = {}
      qs.docs.forEach((d) => (r[d.id] = d.data()))
      cache.reports = r
      emit('reports')
    },
    () => {},
  )
}

// ---------- own server: REST + Server-Sent Events ----------
const CLIENT_ID = Math.random().toString(36).slice(2, 10)
const API = './api/'
const normFacility = (d = {}) => ({ ...withDefaults(d), notice: d?.notice ?? '', afterHours: !!d?.afterHours, engine: d?.engine ?? 'astar', updatedAt: d?.updatedAt ?? 0 })

function applyServer(col, id, data) {
  if (col === 'facility') {
    cache.facility = normFacility(data ?? {})
    emit('facility')
    return
  }
  const next = { ...cache[col] }
  if (data == null) delete next[id]
  else next[id] = data
  cache[col] = next
  emit(col)
}

function startServer() {
  serverMode = true
  mode = 'server'
  emit('mode')
  const es = new EventSource(API + 'events')
  es.addEventListener('snapshot', (e) => {
    const s = JSON.parse(e.data)
    cache.facility = normFacility(s.facility?.state ?? {})
    cache.tokens = s.tokens ?? {}
    cache.reports = s.reports ?? {}
    if (mode !== 'server') {
      mode = 'server'
      emit('mode')
    }
    emitAll()
  })
  // Skip echoes of this device's own writes: the local cache already holds them (and may be newer).
  es.addEventListener('put', (e) => {
    const m = JSON.parse(e.data)
    if (m.from !== CLIENT_ID) applyServer(m.col, m.id, m.data)
  })
  es.addEventListener('del', (e) => {
    const m = JSON.parse(e.data)
    if (m.from !== CLIENT_ID) applyServer(m.col, m.id, null)
  })
  es.onerror = () => {
    mode = 'connecting' // EventSource reconnects by itself; the next snapshot restores 'server'
    emit('mode')
  }
}

function remote(method, path, body) {
  return fetch(API + 'doc/' + path, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Client': CLIENT_ID },
    body: body === undefined ? undefined : JSON.stringify(body),
  }).then((r) => {
    if (!r.ok) throw new Error('HTTP ' + r.status)
  })
}

function probeServer() {
  const ctl = new AbortController()
  const t = setTimeout(() => ctl.abort(), 2500)
  return fetch(API + 'health', { signal: ctl.signal, cache: 'no-store' })
    .then((r) => (r.ok ? r.json() : null))
    .then((j) => !!j?.ok)
    .catch(() => false)
    .finally(() => clearTimeout(t))
}

let started = false
export function initStore() {
  if (started) return
  started = true
  const c = window.claude
  if (!c || typeof c.use !== 'function') {
    if (location.protocol === 'file:' || typeof EventSource === 'undefined') {
      startLocal()
      return
    }
    probeServer().then((ok) => (ok ? startServer() : startLocal()))
    return
  }
  let settled = false
  const timer = setTimeout(() => {
    if (!settled) {
      settled = true
      startLocal()
    }
  }, 6000)
  c.use('db')
    .then((h) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      if (h) startShared(h)
      else startLocal()
    })
    .catch(() => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      startLocal()
    })
}

let serverMode = false
const isServer = () => serverMode
export const getMode = () => mode
export const getFacility = () => cache.facility
export const getTokens = () => cache.tokens
export const getReports = () => cache.reports

export function subscribe(key, fn) {
  listeners[key].add(fn)
  fn(valueOf(key))
  return () => listeners[key].delete(fn)
}

// Serialise writes per document (the shared store asks for one write at a time per doc).
const queues = {}
function enqueue(path, job) {
  const prev = queues[path] ?? Promise.resolve()
  const next = prev.then(job, job)
  queues[path] = next.catch(() => {})
  return next
}

export function saveFacility(next) {
  const doc = { ...withDefaults(next), notice: next.notice ?? '', afterHours: !!next.afterHours, engine: next.engine ?? 'astar', updatedAt: Date.now() }
  cache.facility = doc
  emit('facility')
  if (mode === 'shared') return enqueue('facility/state', () => db.doc('facility/state').set(doc))
  if (isServer()) return enqueue('facility/state', () => remote('PUT', 'facility/state', doc))
  writeLocal(LS_FAC, doc)
  return Promise.resolve()
}

export function saveToken(id, data) {
  cache.tokens = { ...cache.tokens, [id]: data }
  emit('tokens')
  if (mode === 'shared') return enqueue(`tokens/${id}`, () => db.doc(`tokens/${id}`).set(data))
  if (isServer()) return enqueue(`tokens/${id}`, () => remote('PUT', `tokens/${id}`, data))
  writeLocal(LS_TOK + id, data)
  return Promise.resolve()
}

export function patchToken(id, patch) {
  const cur = cache.tokens[id]
  if (!cur) return Promise.resolve()
  const data = { ...cur, ...patch }
  cache.tokens = { ...cache.tokens, [id]: data }
  emit('tokens')
  if (mode === 'shared') return enqueue(`tokens/${id}`, () => db.doc(`tokens/${id}`).update(patch))
  if (isServer()) return enqueue(`tokens/${id}`, () => remote('PATCH', `tokens/${id}`, patch))
  writeLocal(LS_TOK + id, data)
  return Promise.resolve()
}

export function removeToken(id) {
  const t = { ...cache.tokens }
  delete t[id]
  cache.tokens = t
  emit('tokens')
  if (mode === 'shared') return enqueue(`tokens/${id}`, () => db.doc(`tokens/${id}`).delete())
  if (isServer()) return enqueue(`tokens/${id}`, () => remote('DELETE', `tokens/${id}`))
  writeLocal(LS_TOK + id, null)
  return Promise.resolve()
}

export function newTokenId() {
  for (let i = 0; i < 50; i++) {
    const id = `MRG-${Math.floor(1000 + Math.random() * 9000)}`
    if (!cache.tokens[id]) return id
  }
  return `MRG-${Date.now().toString().slice(-6)}`
}

export function saveReport(data) {
  const id = data.id ?? `R${Date.now().toString(36)}${Math.floor(Math.random() * 1296).toString(36)}`
  const doc = { ...data, id }
  cache.reports = { ...cache.reports, [id]: doc }
  emit('reports')
  if (mode === 'shared') return enqueue(`reports/${id}`, () => db.doc(`reports/${id}`).set(doc)).then(() => id)
  if (isServer()) return enqueue(`reports/${id}`, () => remote('PUT', `reports/${id}`, doc)).then(() => id)
  writeLocal(LS_REP + id, doc)
  return Promise.resolve(id)
}

export function patchReport(id, patch) {
  const cur = cache.reports[id]
  if (!cur) return Promise.resolve()
  const data = { ...cur, ...patch }
  cache.reports = { ...cache.reports, [id]: data }
  emit('reports')
  if (mode === 'shared') return enqueue(`reports/${id}`, () => db.doc(`reports/${id}`).update(patch))
  if (isServer()) return enqueue(`reports/${id}`, () => remote('PATCH', `reports/${id}`, patch))
  writeLocal(LS_REP + id, data)
  return Promise.resolve()
}
