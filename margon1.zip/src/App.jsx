import { useEffect, useState } from 'react'
import LoginPage from './components/LoginPage'
import AdminDashboard from './admin/AdminDashboard'
import VisitorNavigator from './visitor/VisitorNavigator'
import { initStore } from './data/store'
import { setEngine } from './data/routeData'
import useStore from './hooks/useStore'

const KEY = 'margon.session'
const load = () => {
  try {
    return JSON.parse(sessionStorage.getItem(KEY)) ?? null
  } catch {
    return null
  }
}
const save = (s) => {
  try {
    if (s) sessionStorage.setItem(KEY, JSON.stringify(s))
    else sessionStorage.removeItem(KEY)
  } catch {
    /* session storage unavailable */
  }
}

export default function App() {
  const [session, setSession] = useState(load)
  const fac = useStore('facility')
  setEngine(fac.engine) // routing engine chosen by the Help Desk (A* or Dijkstra)
  useEffect(() => initStore(), [])
  useEffect(() => save(session), [session])

  if (session?.role === 'admin') return <AdminDashboard onLogout={() => setSession(null)} />
  if (session?.role === 'visitor') return <VisitorNavigator tokenId={session.token} onLogout={() => setSession(null)} />
  return <LoginPage onAdmin={() => setSession({ role: 'admin' })} onVisitor={(token) => setSession({ role: 'visitor', token })} />
}
