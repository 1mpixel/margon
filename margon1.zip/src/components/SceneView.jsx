import { useCallback, useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Expand, RotateCcw, Shrink, ZoomIn, ZoomOut } from 'lucide-react'
import BuildingScene from '../three/BuildingScene'
import { FLOORS } from '../data/buildingData'
import { SceneErrorBoundary, WebGLMessage, hasWebGL } from './SceneFallback'

const LEGEND = [
  { c: '#16a34a', t: 'Route', hi: 'मार्ग' },
  { c: '#2563eb', t: 'Alternative', hi: 'वैकल्पिक' },
  { c: '#dc2626', t: 'Closed', hi: 'बंद' },
  { c: '#b7791f', t: 'Stairs', hi: 'सीढ़ियाँ' },
]

/**
 * 3D campus viewport with floor pills, view controls and a compact legend.
 * `activeLevel` highlights a floor without moving the camera (used while navigating).
 */
export default function SceneView({ gapRef, rightInset = 0, leftInset = 0, onSelect, selectedObject, paused = false, activeLevel, lang = 'en', hideFloorPills = false, ...sceneProps }) {
  const webgl = useMemo(() => hasWebGL(), [])
  const [ready, setReady] = useState(false)
  const [floor, setFloor] = useState('all')
  const [exploded, setExploded] = useState(true)
  const [cmd, setCmd] = useState(null)
  const gap = exploded ? 5.6 : 4
  useEffect(() => {
    if (gapRef) gapRef.current = gap
  }, [gap, gapRef])

  const camera = useCallback((type, extra = {}) => setCmd({ type, n: Math.random(), ...extra }), [])
  const selectFloor = useCallback(
    (level) => {
      setFloor(level)
      camera(level === 'all' ? 'reset' : 'focus', { level })
    },
    [camera],
  )
  const shownFloor = activeLevel ?? floor

  const onReady = useCallback(() => setTimeout(() => setReady(true), 500), [])
  const onPointerMissed = useCallback((e) => e?.target?.tagName === 'CANVAS' && onSelect?.(null), [onSelect])
  const viewInset = useMemo(() => ({ left: leftInset, right: rightInset }), [leftInset, rightInset])

  return (
    <div className="absolute inset-0">
      {webgl ? (
        <SceneErrorBoundary>
          <BuildingScene
            {...sceneProps}
            paused={paused}
            gap={gap}
            selectedFloor={shownFloor}
            onSelectFloor={selectFloor}
            onSelect={onSelect}
            selectedObject={selectedObject}
            cameraCmd={cmd}
            viewInset={viewInset}
            onReady={onReady}
            onPointerMissed={onPointerMissed}
          />
        </SceneErrorBoundary>
      ) : (
        <WebGLMessage />
      )}

      {!hideFloorPills && (
        <div className="absolute top-4 z-20 flex items-center gap-0.5 p-1 rounded-xl bg-surface/95 border border-line shadow-sm max-w-[calc(100%-2rem)] overflow-x-auto" style={{ left: leftInset + 16 }} role="radiogroup" aria-label="Floor">
          {[{ level: 'all', short: 'All', name: 'All floors', operational: true }, ...FLOORS].map((f) => {
            const on = shownFloor === f.level
            return (
              <button
                key={f.level}
                type="button"
                role="radio"
                aria-checked={on}
                aria-label={f.name}
                title={f.operational ? f.name : `${f.name} (not in use)`}
                onClick={() => selectFloor(f.level)}
                className={`focus-ring shrink-0 h-8 min-w-8 px-2 rounded-lg text-[12.5px] font-medium transition-colors ${
                  on ? 'bg-ink text-white' : f.operational ? 'text-body hover:bg-subtle' : 'text-muted/60 hover:bg-subtle'
                }`}
              >
                {f.short}
              </button>
            )
          })}
        </div>
      )}

      <div className="absolute top-4 z-20 flex items-center gap-1 p-1 rounded-xl bg-surface/95 border border-line shadow-sm" style={{ right: rightInset + 16 }}>
        {[
          { icon: ZoomIn, t: 'Zoom in', a: () => camera('zoomIn') },
          { icon: ZoomOut, t: 'Zoom out', a: () => camera('zoomOut') },
          { icon: RotateCcw, t: 'Reset view', a: () => selectFloor('all') },
          { icon: exploded ? Shrink : Expand, t: exploded ? 'Real floor spacing' : 'Spread floors apart', a: () => setExploded((v) => !v) },
        ].map(({ icon: Icon, t, a }) => (
          <button key={t} type="button" onClick={a} title={t} aria-label={t} className="focus-ring w-8 h-8 grid place-items-center rounded-lg text-body hover:bg-subtle">
            <Icon className="w-4 h-4" />
          </button>
        ))}
      </div>

      <div className="absolute bottom-4 z-20 flex items-center gap-3 px-3 h-8 rounded-lg bg-surface/90 border border-line text-[11.5px] text-body" style={{ left: leftInset + 16 }}>
        {LEGEND.map((l) => (
          <span key={l.t} className="flex items-center gap-1.5">
            <span className="w-3.5 h-[3px] rounded-full" style={{ background: l.c }} />
            {lang === 'hi' ? l.hi : l.t}
          </span>
        ))}
      </div>

      <AnimatePresence>
        {webgl && !ready && (
          <motion.div key="load" exit={{ opacity: 0 }} transition={{ duration: 0.4 }} className="absolute inset-0 z-30 grid place-items-center bg-canvas">
            <div className="flex flex-col items-center gap-3 text-muted text-[13px]">
              <span className="w-8 h-8 rounded-full border-2 border-line border-t-brand animate-spin" />
              Loading campus model
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
