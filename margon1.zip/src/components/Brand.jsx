import logoUrl from '../assets/margon-logo.png'

// मार्गON wordmark (logo image) with an optional sub-line.
export default function Brand({ sub, size = 'md' }) {
  const h = size === 'lg' ? 'h-20' : 'h-9'
  return (
    <div className="flex items-center gap-3 min-w-0">
      <img src={logoUrl} alt="मार्गON" className={`${h} w-auto shrink-0`} />
      {sub && <div className="hidden sm:block text-[11.5px] leading-tight text-muted border-l border-line pl-3 max-w-[180px]">{sub}</div>}
    </div>
  )
}
