import { Component } from 'react'

export function hasWebGL() {
  try {
    const c = document.createElement('canvas')
    return !!(window.WebGL2RenderingContext && c.getContext('webgl2')) || !!c.getContext('webgl')
  } catch {
    return false
  }
}

export function WebGLMessage({ detail }) {
  return (
    <div className="absolute inset-0 grid place-items-center p-8 bg-canvas">
      <div className="panel max-w-md p-6 text-center">
        <div className="font-semibold text-ink mb-1">3D view unavailable</div>
        <p className="text-[13px] text-body leading-relaxed">
          This browser could not start WebGL. Turn on hardware acceleration or open मार्गON in a current version of Chrome or Edge. Route instructions remain available in the side panel.
        </p>
        {detail && <p className="mt-3 text-[11px] text-muted tabular break-words">{detail}</p>}
      </div>
    </div>
  )
}

export class SceneErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { error: null }
  }
  static getDerivedStateFromError(error) {
    return { error }
  }
  render() {
    if (this.state.error) return <WebGLMessage detail={String(this.state.error?.message ?? this.state.error)} />
    return this.props.children
  }
}
