import { useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { ArrowLeft, KeyRound, ShieldCheck } from 'lucide-react'
import SyncBadge from './SyncBadge'
import useStore from '../hooks/useStore'
import logoUrl from '../assets/margon-logo.png'
import iconUrl from '../assets/margon-icon.png'
import bannerUrl from '../assets/glbajaj-banner.png'
import { hoursLabel, tokenState } from '../data/routeData'

export const ADMIN_USER = 'admin'
export const ADMIN_PASS = 'margon123'

const ease = [0.22, 1, 0.36, 1]

function VisitorForm({ onVisitor, onBack }) {
  const tokens = useStore('tokens')
  const [strap, setStrap] = useState('')
  const [tok, setTok] = useState('')
  const [err, setErr] = useState('')

  const submit = (e) => {
    e.preventDefault()
    const digits = strap.trim().toUpperCase().replace(/^ST-?/, '').replace(/\D/g, '')
    const strapId = `ST-${String(Number(digits || 0)).padStart(2, '0')}`
    const raw = tok.trim().toUpperCase().replace(/^MRG-?/, '').replace(/\D/g, '')
    const t = tokens[`MRG-${raw}`]
    const st = tokenState(t)
    if (st === 'missing') return setErr('Token not found. Check the card given with your strap. / टोकन नहीं मिला।')
    if (t.strapId !== strapId) return setErr('This token belongs to a different strap. / यह टोकन किसी दूसरे स्ट्रैप का है।')
    if (st === 'closed') return setErr('This strap has been returned. Please visit the Help Desk. / यह स्ट्रैप लौटाया जा चुका है।')
    if (st === 'expired') return setErr(`Token expired. Straps are valid ${hoursLabel('en')}. / टोकन की अवधि समाप्त हो गई है।`)
    if (st === 'early') return setErr(`Token not yet valid. Service hours are ${hoursLabel('en')}. / सेवा ${hoursLabel('hi')}।`)
    onVisitor(t.token)
  }

  return (
    <form onSubmit={submit} className="w-full max-w-sm flex flex-col gap-4" aria-labelledby="v-h">
      <button type="button" onClick={onBack} className="focus-ring self-start inline-flex items-center gap-1.5 text-[13px] text-muted hover:text-ink">
        <ArrowLeft className="w-4 h-4" /> Back · वापस
      </button>
      <div className="flex items-center gap-3">
        <img src={iconUrl} alt="" className="w-14 h-14" />
        <div>
          <h2 id="v-h" className="text-[22px] font-semibold text-ink leading-tight">Visitor · आगंतुक</h2>
          <p className="text-[13px] text-muted">Enter your strap number and token</p>
        </div>
      </div>
      <div>
        <label className="label block mb-1.5" htmlFor="strap-no">
          Strap number · स्ट्रैप नंबर
        </label>
        <input id="strap-no" className="field !h-12 !text-[18px] tabular uppercase" placeholder="ST-01" value={strap} autoComplete="off" onChange={(e) => (setStrap(e.target.value), setErr(''))} />
      </div>
      <div>
        <label className="label block mb-1.5" htmlFor="token">
          Token · टोकन
        </label>
        <input id="token" className="field !h-12 !text-[18px] tabular tracking-[0.1em] uppercase" placeholder="MRG-0000" value={tok} autoComplete="off" onChange={(e) => (setTok(e.target.value), setErr(''))} />
      </div>
      {err && (
        <p className="text-[12.5px] text-bad" role="alert">
          {err}
        </p>
      )}
      <button type="submit" className="btn btn-primary !h-12 !text-[15px]">
        Start · शुरू करें
      </button>
      <p className="text-[12px] text-muted">Straps are valid {hoursLabel('en')} on the day of issue.</p>
    </form>
  )
}

function AdminForm({ onAdmin, onBack }) {
  const [u, setU] = useState('')
  const [p, setP] = useState('')
  const [err, setErr] = useState('')
  const submit = (e) => {
    e.preventDefault()
    if (u.trim().toLowerCase() === ADMIN_USER && p === ADMIN_PASS) onAdmin()
    else setErr('Incorrect username or password.')
  }
  return (
    <form onSubmit={submit} className="w-full max-w-sm flex flex-col gap-4" aria-labelledby="a-h">
      <button type="button" onClick={onBack} className="focus-ring self-start inline-flex items-center gap-1.5 text-[13px] text-muted hover:text-ink">
        <ArrowLeft className="w-4 h-4" /> Back
      </button>
      <div className="flex items-center gap-3">
        <span className="w-14 h-14 rounded-2xl grid place-items-center bg-[#0b2545] text-white">
          <ShieldCheck className="w-7 h-7" />
        </span>
        <div>
          <h2 id="a-h" className="text-[22px] font-semibold text-ink leading-tight">Help Desk · Admin</h2>
          <p className="text-[13px] text-muted">Issue straps, monitor visitors, report closures</p>
        </div>
      </div>
      <div>
        <label className="label block mb-1.5" htmlFor="adm-user">
          Username
        </label>
        <input id="adm-user" className="field !h-11" value={u} autoComplete="username" onChange={(e) => (setU(e.target.value), setErr(''))} />
      </div>
      <div>
        <label className="label block mb-1.5" htmlFor="adm-pass">
          Password
        </label>
        <input id="adm-pass" type="password" className="field !h-11" value={p} autoComplete="current-password" onChange={(e) => (setP(e.target.value), setErr(''))} />
      </div>
      {err && (
        <p className="text-[12.5px] text-bad" role="alert">
          {err}
        </p>
      )}
      <button type="submit" className="btn !h-12 !text-[15px] !bg-[#0b2545] !border-[#0b2545] !text-white hover:!bg-[#123462]">
        <KeyRound className="w-4 h-4" /> Sign in
      </button>
      <p className="text-[12px] text-muted">
        Demo account: <span className="tabular text-body">admin</span> / <span className="tabular text-body">margon123</span>
      </p>
    </form>
  )
}

function Half({ k, side, setSide, hover, setHover, reduce, bg, glow, glowPos, children }) {
  const grow = side ? (side === k ? 1 : 0.0001) : hover === k ? 1.2 : hover ? 0.85 : 1
  const other = side && side !== k
  return (
    <motion.section
      className="relative overflow-hidden flex items-center justify-center min-h-0 min-w-0"
      style={{ background: bg, flexBasis: 0 }}
      initial={reduce ? false : { opacity: 0, x: k === 'visitor' ? -60 : 60 }}
      animate={{ flexGrow: grow, opacity: other ? 0 : 1, x: 0 }}
      transition={{ duration: 0.6, ease }}
      onMouseEnter={() => !side && setHover(k)}
      onMouseLeave={() => setHover(null)}
      aria-hidden={other || undefined}
    >
      <motion.div
        aria-hidden
        className="absolute w-[460px] h-[460px] rounded-full pointer-events-none"
        style={{ ...glowPos, background: `radial-gradient(circle, ${glow}, transparent 65%)` }}
        animate={reduce ? {} : { scale: [1, 1.1, 1] }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
      />
      <AnimatePresence mode="wait">{children(side === k, () => setSide(k), () => setSide(null))}</AnimatePresence>
    </motion.section>
  )
}

export default function LoginPage({ onAdmin, onVisitor }) {
  const [side, setSide] = useState(null)
  const [hover, setHover] = useState(null)
  const reduce = useReducedMotion()
  const shared = { side, setSide, hover, setHover, reduce }

  return (
    <div className="h-full flex flex-col bg-white overflow-hidden">
      <header className="relative z-10 shrink-0 h-16 flex items-center justify-between px-4 md:px-6 border-b border-line bg-white">
        <motion.img src={logoUrl} alt="मार्गON" className="h-11 w-auto" initial={reduce ? false : { opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease }} />
        <div className="flex items-center gap-3">
          <motion.img src={bannerUrl} alt="GL BAJAJ, Greater Noida" className="hidden md:block h-11 w-auto rounded" initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4, duration: 0.6 }} />
          <SyncBadge />
        </div>
      </header>

      <div className="relative flex-1 min-h-0 flex flex-col md:flex-row">
        <Half k="visitor" {...shared} bg="linear-gradient(150deg, #eef7ff 0%, #e8f8ef 100%)" glow="rgba(34,197,94,0.22)" glowPos={{ left: -120, bottom: -140 }}>
          {(open, choose, back) =>
            open ? (
              <motion.div key="vf" className="w-full flex justify-center px-6" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.35, ease }}>
                <VisitorForm onVisitor={onVisitor} onBack={back} />
              </motion.div>
            ) : (
              <motion.button key="vb" type="button" onClick={choose} className="focus-ring group relative flex flex-col items-center gap-4 md:gap-5 p-6 md:p-8 text-center" exit={{ opacity: 0, scale: 0.96 }}>
                <motion.img
                  src={iconUrl}
                  alt=""
                  className="w-32 h-32 md:w-56 md:h-56 drop-shadow-xl"
                  initial={reduce ? false : { scale: 0.5, rotate: -10, opacity: 0 }}
                  animate={{ scale: 1, rotate: 0, opacity: 1 }}
                  whileHover={reduce ? {} : { scale: 1.06, rotate: -3 }}
                  transition={{ type: 'spring', stiffness: 110, damping: 13, delay: 0.25 }}
                />
                <div>
                  <div className="text-[28px] md:text-[38px] font-semibold text-[#0b2545] leading-tight">Visitor</div>
                  <div className="text-[20px] md:text-[22px] text-[#15803d] font-medium">आगंतुक</div>
                </div>
                <div className="hidden md:block text-[14px] text-body max-w-xs">Plan your visit and get turn-by-turn guidance in English or Hindi.</div>
                <span className="inline-flex items-center gap-2 h-11 px-6 rounded-full bg-[#15803d] text-white text-[14.5px] font-medium shadow-lg shadow-green-700/20 group-hover:bg-[#166534] transition-colors">
                  Strap number · स्ट्रैप नंबर
                </span>
              </motion.button>
            )
          }
        </Half>

        <div className="hidden md:block w-px bg-line" aria-hidden />

        <Half k="admin" {...shared} bg="#ffffff" glow="rgba(37,99,235,0.16)" glowPos={{ right: -120, top: -140 }}>
          {(open, choose, back) =>
            open ? (
              <motion.div key="af" className="w-full flex justify-center px-6" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.35, ease }}>
                <AdminForm onAdmin={onAdmin} onBack={back} />
              </motion.div>
            ) : (
              <motion.button key="ab" type="button" onClick={choose} className="focus-ring group relative flex flex-col items-center gap-4 md:gap-5 p-6 md:p-8 text-center" exit={{ opacity: 0, scale: 0.96 }}>
                <motion.span
                  className="w-32 h-32 md:w-56 md:h-56 rounded-[2.5rem] grid place-items-center text-white shadow-xl"
                  style={{ background: 'linear-gradient(145deg, #0ea5e9 0%, #1d4ed8 55%, #0b2545 100%)' }}
                  initial={reduce ? false : { scale: 0.5, rotate: 10, opacity: 0 }}
                  animate={{ scale: 1, rotate: 0, opacity: 1 }}
                  whileHover={reduce ? {} : { scale: 1.06, rotate: 3 }}
                  transition={{ type: 'spring', stiffness: 110, damping: 13, delay: 0.35 }}
                >
                  <ShieldCheck className="w-20 h-20 md:w-32 md:h-32" strokeWidth={1.6} />
                </motion.span>
                <div>
                  <div className="text-[28px] md:text-[38px] font-semibold text-[#0b2545] leading-tight">Help Desk · Admin</div>
                  <div className="text-[20px] md:text-[22px] text-[#1d4ed8] font-medium">सहायता डेस्क</div>
                </div>
                <div className="hidden md:block text-[14px] text-body max-w-xs">Issue straps, watch live positions, answer SOS alerts and report closures.</div>
                <span className="inline-flex items-center gap-2 h-11 px-6 rounded-full bg-[#0b2545] text-white text-[14.5px] font-medium shadow-lg shadow-blue-900/20 group-hover:bg-[#123462] transition-colors">
                  Credentials · लॉगिन
                </span>
              </motion.button>
            )
          }
        </Half>
      </div>
    </div>
  )
}
