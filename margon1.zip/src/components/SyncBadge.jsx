import useStore from '../hooks/useStore'

export default function SyncBadge() {
  const mode = useStore('mode')
  const map = {
    shared: { t: 'Live · shared', c: 'bg-ok' },
    server: { t: 'Live · server', c: 'bg-ok' },
    local: { t: 'Live · this browser', c: 'bg-warn' },
    connecting: { t: 'Connecting…', c: 'bg-muted' },
  }
  const m = map[mode] ?? map.connecting
  return (
    <span
      className="inline-flex items-center gap-1.5 h-7 px-2.5 rounded-full border border-line bg-surface text-[11.5px] text-body"
      title={mode === 'shared' || mode === 'server' ? 'Data is shared between all devices opening this link' : 'Data is shared between tabs of this browser only'}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${m.c}`} />
      {m.t}
    </span>
  )
}
