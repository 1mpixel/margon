import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource/inter/400.css'
import '@fontsource/inter/500.css'
import '@fontsource/inter/600.css'
import '@fontsource/inter/700.css'
import '@fontsource/jetbrains-mono/500.css'
import './index.css'
import App from './App.jsx'

// A WebGL canvas with HTML overlays can raise a harmless DOM NotFoundError while unmounting
// (for example on sign-out). It does not affect the application, so it is not reported.
window.addEventListener('error', (e) => {
  if (e?.error?.name === 'NotFoundError' && /removeChild/.test(e.error.message)) e.preventDefault()
})

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
