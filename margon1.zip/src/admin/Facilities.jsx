import { useState } from 'react'
import { RotateCcw } from 'lucide-react'
import SceneView from '../components/SceneView'
import { BUILDINGS, CORRIDOR_SEGMENTS, FLOORS, LIFTS, OPERATIONAL, RAMPS, STAIRS } from '../data/buildingData'
import { NORMAL_FACILITIES } from '../data/routeData'
import { saveFacility } from '../data/store'
import useStore from '../hooks/useStore'

function Row({ title, sub, open, onToggle }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={open}
      aria-label={`${title}${sub ? `, ${sub}` : ''}`}
      onClick={onToggle}
      className={`focus-ring w-full flex items-center gap-3 px-3 py-2 rounded-lg border text-left transition-colors ${open ? 'border-line bg-surface hover:bg-subtle' : 'border-bad/40 bg-bad/5'}`}
    >
      <span className="flex-1 min-w-0">
        <span className="block text-[13px] font-medium text-ink">{title}</span>
        {sub && <span className="block text-[11.5px] text-muted truncate">{sub}</span>}
      </span>
      <span className={`text-[11.5px] font-medium w-12 text-right ${open ? 'text-ok' : 'text-bad'}`}>{open ? 'Open' : 'Closed'}</span>
      <span className={`switch ${open ? 'is-on' : 'is-off-bad'}`} aria-hidden />
    </button>
  )
}

export default function Facilities({ paused }) {
  const fac = useStore('facility')
  const [bid, setBid] = useState('B1')
  const [notice, setNotice] = useState(null)
  const [noticeSaved, setNoticeSaved] = useState(false)
  const noticeValue = notice ?? fac.notice ?? ''

  const set = (patch) => saveFacility({ ...fac, ...patch })
  const toggle = (group, id) => set({ [group]: { ...fac[group], [id]: !(fac[group][id] !== false) } })
  const toggleSeg = (id) => set({ blocked: fac.blocked.includes(id) ? fac.blocked.filter((b) => b !== id) : [...fac.blocked, id] })
  const closedIn = (b) =>
    LIFTS.filter((l) => l.building === b && fac.elevators[l.id] === false).length +
    RAMPS.filter((r) => r.building === b && fac.ramps[r.id] === false).length +
    Object.entries(fac.stairs).filter(([k, v]) => k.startsWith(b) && v === false).length +
    fac.blocked.filter((s) => s.startsWith(b)).length
  const total = closedIn('B1') + closedIn('B2')

  return (
    <div className="flex h-full min-h-0">
      <aside className="w-[400px] shrink-0 border-r border-line bg-surface overflow-auto scroll-thin">
        <div className="p-5 flex flex-col gap-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-semibold text-ink">Facility status</h2>
              <p className="text-[12.5px] text-muted mt-0.5">Changes reach every visitor at once and their routes are recalculated.</p>
            </div>
            <span className={`shrink-0 text-[11.5px] font-medium px-2 py-1 rounded-md ${total ? 'bg-bad/10 text-bad' : 'bg-ok/10 text-ok'}`}>{total ? `${total} closed` : 'All open'}</span>
          </div>

          <div className="grid grid-cols-2 p-1 rounded-xl bg-subtle border border-line" role="tablist" aria-label="Block">
            {BUILDINGS.map((b) => (
              <button
                key={b.id}
                type="button"
                role="tab"
                aria-selected={bid === b.id}
                onClick={() => setBid(b.id)}
                className={`focus-ring h-9 rounded-lg text-[13px] font-medium flex items-center justify-center gap-2 ${bid === b.id ? 'bg-surface shadow-sm text-ink' : 'text-muted'}`}
              >
                {b.name}
                {closedIn(b.id) > 0 && <span className="min-w-5 h-5 px-1 rounded-full bg-bad text-white text-[10.5px] grid place-items-center">{closedIn(b.id)}</span>}
              </button>
            ))}
          </div>

          <section className="flex flex-col gap-2">
            <div className="label">Lifts</div>
            <div className="grid grid-cols-2 gap-2">
              {LIFTS.filter((l) => l.building === bid).map((l) => (
                <Row key={l.id} title={`Lift ${l.label}`} sub={l.side === 'left' ? 'Left core' : 'Right core'} open={fac.elevators[l.id] !== false} onToggle={() => toggle('elevators', l.id)} />
              ))}
            </div>
          </section>

          <section className="flex flex-col gap-2">
            <div className="label">Entrance ramps and stairs</div>
            {RAMPS.filter((r) => r.building === bid).map((r) => (
              <Row key={r.id} title={r.name} sub={`${r.gradient} · ${r.location}`} open={fac.ramps[r.id] !== false} onToggle={() => toggle('ramps', r.id)} />
            ))}
            <Row title="Front steps" sub="Main entrance" open={fac.stairs[`${bid}-ST`] !== false} onToggle={() => toggle('stairs', `${bid}-ST`)} />
            {STAIRS.filter((s) => s.building === bid).map((s) => (
              <Row key={s.id} title={s.name} sub="All floors" open={fac.stairs[s.id] !== false} onToggle={() => toggle('stairs', s.id)} />
            ))}
          </section>

          <section className="flex flex-col gap-2">
            <div className="label">Corridors</div>
            <div className="rounded-lg border border-line divide-y divide-line">
              {[...FLOORS]
                .filter((f) => OPERATIONAL.includes(f.level))
                .reverse()
                .map((f) => (
                  <div key={f.level} className="flex items-center gap-2 px-3 py-1.5">
                    <span className="w-24 text-[12.5px] text-body">{f.name}</span>
                    <div className="flex-1 grid grid-cols-3 gap-1">
                      {CORRIDOR_SEGMENTS.filter((s) => s.building === bid && s.level === f.level).map((s) => {
                        const shut = fac.blocked.includes(s.id)
                        return (
                          <button
                            key={s.id}
                            type="button"
                            aria-pressed={shut}
                            title={`${s.name}: ${shut ? 'closed' : 'open'}`}
                            onClick={() => toggleSeg(s.id)}
                            className={`focus-ring h-7 rounded-md text-[11.5px] border transition-colors ${shut ? 'bg-bad text-white border-bad' : 'border-line text-body hover:bg-subtle'}`}
                          >
                            {s.shortName}
                          </button>
                        )
                      })}
                    </div>
                  </div>
                ))}
            </div>
            <p className="text-[11.5px] text-muted">Floors 1, 7, 8 and 9 are not in use and are not shown.</p>
          </section>

          <section className="flex flex-col gap-2">
            <label className="label" htmlFor="notice">
              Notice to visitors
            </label>
            <textarea
              id="notice"
              rows={3}
              className="field !h-auto py-2 resize-none"
              placeholder="e.g. Lift L1 in the AI & ML Block is under maintenance until 4 pm."
              value={noticeValue}
              onChange={(e) => {
                setNotice(e.target.value)
                setNoticeSaved(false)
              }}
            />
            <div className="flex items-center gap-2">
              <button
                type="button"
                className="btn"
                onClick={() => {
                  set({ notice: noticeValue.trim() })
                  setNotice(null)
                  setNoticeSaved(true)
                }}
              >
                Publish notice
              </button>
              {noticeSaved && <span className="text-[12px] text-ok">Published</span>}
            </div>
          </section>

          <button type="button" className="btn" onClick={() => saveFacility({ ...NORMAL_FACILITIES, notice: '' })}>
            <RotateCcw className="w-4 h-4" /> Reopen everything
          </button>
        </div>
      </aside>
      <div className="relative flex-1 min-w-0">
        <SceneView facilities={fac} minimal={false} paused={paused} />
      </div>
    </div>
  )
}
