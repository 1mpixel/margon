import { useState } from 'react'
import { Activity, FlaskConical, LogOut, Radio, ShieldQuestion, Wrench } from 'lucide-react'
import Brand from '../components/Brand'
import SyncBadge from '../components/SyncBadge'
import LiveMonitor from './LiveMonitor'
import IssueStrap from './IssueStrap'
import Facilities from './Facilities'
import useStore from '../hooks/useStore'
import SosAlerts from './SosAlerts'
import Reports from './Reports'
import RoutingLab from './RoutingLab'

const TABS = [
  { id: 'monitor', label: 'Live map', icon: Radio },
  { id: 'issue', label: 'Issue strap', icon: Activity },
  { id: 'facilities', label: 'Facilities', icon: Wrench },
  { id: 'reports', label: 'Reports', icon: ShieldQuestion },
  { id: 'lab', label: 'Routing lab', icon: FlaskConical },
]

export default function AdminDashboard({ onLogout }) {
  const [tab, setTab] = useState('monitor')
  const [selected, setSelected] = useState(null)
  const fac = useStore('facility')
  const reports = useStore('reports')
  const pendingReports = Object.values(reports).filter((r) => r.status === 'pending').length
  const closures =
    Object.values(fac.elevators).filter((v) => !v).length +
    Object.values(fac.ramps).filter((v) => !v).length +
    Object.values(fac.stairs).filter((v) => !v).length +
    fac.blocked.length

  return (
    <div className="h-full flex flex-col bg-canvas">
      <header className="h-14 shrink-0 flex items-center gap-4 px-4 border-b border-line bg-surface overflow-x-auto">
        <Brand sub="Help Desk · Command centre · GL BAJAJ" />
        <nav className="flex items-center gap-1" aria-label="Sections">
          {TABS.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              aria-current={tab === id ? 'page' : undefined}
              onClick={() => setTab(id)}
              className={`focus-ring relative h-9 px-3 rounded-lg inline-flex items-center gap-2 text-[13px] font-medium transition-colors ${
                tab === id ? 'bg-subtle text-ink' : 'text-muted hover:text-ink'
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
              {id === 'facilities' && closures > 0 && <span className="min-w-5 h-5 px-1 rounded-full bg-bad text-white text-[10.5px] grid place-items-center">{closures}</span>}
              {id === 'reports' && pendingReports > 0 && <span className="min-w-5 h-5 px-1 rounded-full bg-warn text-white text-[10.5px] grid place-items-center">{pendingReports}</span>}
            </button>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <SyncBadge />
          <button type="button" className="btn !h-8" onClick={onLogout}>
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>
      </header>
      <SosAlerts
        onLocate={(id) => {
          setSelected(id)
          setTab('monitor')
        }}
      />
      {/* Tabs stay mounted so the 3D views keep their camera and do not reload. */}
      <main className="relative flex-1 min-h-0">
        <div className="absolute inset-0" hidden={tab !== 'monitor'}>
          <LiveMonitor selected={selected} setSelected={setSelected} paused={tab !== 'monitor'} />
        </div>
        <div className="absolute inset-0" hidden={tab !== 'issue'}>
          <IssueStrap
            onViewOnMap={(id) => {
              setSelected(id)
              setTab('monitor')
            }}
          />
        </div>
        <div className="absolute inset-0" hidden={tab !== 'facilities'}>
          <Facilities paused={tab !== 'facilities'} />
        </div>
        {tab === 'reports' && (
          <div className="absolute inset-0">
            <Reports />
          </div>
        )}
        {tab === 'lab' && (
          <div className="absolute inset-0">
            <RoutingLab />
          </div>
        )}
      </main>
    </div>
  )
}
