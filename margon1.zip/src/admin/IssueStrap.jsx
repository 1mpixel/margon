import { useState } from 'react'
import { CircleCheck, Clock, Copy, Undo2 } from 'lucide-react'
import { floorName } from '../data/buildingData'
import { roomById } from '../data/roomData'
import { hoursLabel, nodeLabel, validityFor, withinHours } from '../data/routeData'
import { STRAPS, telemetryAtNode, timeAgo } from '../data/straps'
import { newTokenId, patchToken, saveFacility, saveToken } from '../data/store'
import useStore from '../hooks/useStore'

const timeOf = (ms) => (ms ? new Date(ms).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '-')

export default function IssueStrap({ onViewOnMap }) {
  const tokens = useStore('tokens')
  const fac = useStore('facility')
  const now = Date.now()
  const active = Object.values(tokens)
    .filter((t) => t.status === 'active')
    .sort((a, b) => b.issuedAt - a.issuedAt)
  const inUse = new Set(active.map((t) => t.strapId))
  const free = STRAPS.filter((s) => !inUse.has(s))

  const [visitor, setVisitor] = useState('')
  const [phone, setPhone] = useState('')
  const [strapId, setStrapId] = useState('')
  const [issued, setIssued] = useState(null)
  const [copied, setCopied] = useState(false)

  const strap = strapId && free.includes(strapId) ? strapId : free[0] ?? ''
  const open = withinHours()
  const validity = validityFor(new Date(), fac.afterHours)

  const issue = async (e) => {
    e.preventDefault()
    if (!strap || !validity) return
    const id = newTokenId()
    const doc = {
      token: id,
      strapId: strap,
      visitor: visitor.trim() || 'Visitor',
      phone: phone.trim(),
      startId: 'HD',
      lastNode: 'HD',
      stops: [],
      leg: 0,
      mode: 'ramp',
      status: 'active',
      issuedAt: Date.now(),
      ...validity,
      nav: 'idle',
      step: 0,
      sos: null,
      telemetry: telemetryAtNode('HD'),
    }
    await saveToken(id, doc)
    setIssued(doc)
    setVisitor('')
    setPhone('')
    setStrapId('')
    setCopied(false)
  }

  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
    } catch {
      setCopied(false)
    }
  }

  return (
    <div className="h-full overflow-auto scroll-thin">
      <div className="max-w-6xl mx-auto px-4 py-6 grid lg:grid-cols-[400px_1fr] gap-6 items-start">
        <div className="flex flex-col gap-4">
          <form onSubmit={issue} className="panel p-5 flex flex-col gap-4">
            <div>
              <h2 className="font-semibold text-ink">Issue a strap</h2>
              <p className="text-[12.5px] text-muted mt-0.5">The visitor chooses destinations and route preference on their own screen.</p>
            </div>
            <div className={`flex items-start gap-2.5 rounded-lg px-3 py-2.5 text-[12.5px] ${open ? 'bg-ok/8 text-ok' : 'bg-warn/10 text-[#8a5a00]'}`}>
              <Clock className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <div className="font-medium">{open ? `Service open · straps valid until 6:00 pm today` : `Outside service hours (${hoursLabel()})`}</div>
                {!open && (
                  <label className="mt-1.5 flex items-center gap-2 text-body cursor-pointer">
                    <input type="checkbox" checked={!!fac.afterHours} onChange={(e) => saveFacility({ ...fac, afterHours: e.target.checked })} />
                    Allow issuing for a demonstration (valid 4 hours)
                  </label>
                )}
              </div>
            </div>
            <div>
              <label className="label block mb-1.5" htmlFor="v-name">
                Visitor name
              </label>
              <input id="v-name" className="field" placeholder="Optional" value={visitor} onChange={(e) => setVisitor(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label block mb-1.5" htmlFor="v-phone">
                  Mobile
                </label>
                <input id="v-phone" className="field tabular" inputMode="tel" placeholder="Optional" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div>
                <label className="label block mb-1.5" htmlFor="v-strap">
                  Strap
                </label>
                <select id="v-strap" className="field" value={strap} onChange={(e) => setStrapId(e.target.value)} disabled={!free.length}>
                  {free.length === 0 && <option value="">None free</option>}
                  {free.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <button type="submit" className="btn btn-primary !h-11" disabled={!strap || !validity}>
              Generate token
            </button>
          </form>

          {issued && (
            <div className="panel p-5 border-ok/40" role="status">
              <div className="flex items-center gap-2 text-ok text-[13px] font-medium">
                <CircleCheck className="w-4 h-4" /> Strap issued to {issued.visitor}
              </div>
              <div className="mt-3 grid grid-cols-2 gap-3">
                <div>
                  <div className="label">Strap number</div>
                  <div className="tabular text-[28px] leading-none font-semibold text-ink mt-1 select-all">{issued.strapId}</div>
                </div>
                <div>
                  <div className="label">Token</div>
                  <div className="tabular text-[28px] leading-none font-semibold tracking-[0.06em] text-ink mt-1 select-all">{issued.token}</div>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-between gap-3">
                <div className="text-[12.5px] text-body">
                  Valid {timeOf(issued.validFrom)} to {timeOf(issued.validUntil)}
                  {issued.extended ? ' (demonstration)' : ''}
                </div>
                <button type="button" className="btn !h-8" onClick={() => copy(`${issued.strapId} / ${issued.token}`)}>
                  <Copy className="w-4 h-4" /> {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <ol className="mt-4 text-[12.5px] text-body list-decimal pl-4 grid gap-1">
                <li>Fasten strap {issued.strapId} to the wheelchair frame and switch it on.</li>
                <li>Show the visitor the SOS button on their screen.</li>
                <li>The visitor signs in with the strap number and token, then chooses where to go.</li>
              </ol>
            </div>
          )}
        </div>

        <section className="panel overflow-hidden">
          <div className="px-5 py-4 border-b border-line">
            <h2 className="font-semibold text-ink">Straps in use</h2>
            <p className="text-[12.5px] text-muted mt-0.5">
              {active.length} in use · {free.length} free of {STRAPS.length}
            </p>
          </div>
          {active.length === 0 ? (
            <p className="px-5 py-10 text-center text-[13px] text-muted">No straps issued. Generate a token to fit the first strap.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="text-left text-muted text-[11.5px] uppercase tracking-wide">
                    <th className="px-5 py-2 font-medium">Strap</th>
                    <th className="px-3 py-2 font-medium">Token</th>
                    <th className="px-3 py-2 font-medium">Visitor</th>
                    <th className="px-3 py-2 font-medium">Trip</th>
                    <th className="px-3 py-2 font-medium">Valid until</th>
                    <th className="px-5 py-2" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {active.map((t) => {
                    const stops = t.stops ?? []
                    const curStop = stops[t.leg ?? 0]
                    const expired = t.validUntil && now >= t.validUntil
                    return (
                      <tr key={t.token} className={t.sos?.active ? 'bg-bad/5' : 'hover:bg-subtle'}>
                        <td className="px-5 py-2.5 tabular font-semibold text-ink whitespace-nowrap">
                          {t.strapId}
                          {t.sos?.active && <span className="ml-2 text-[10.5px] px-1.5 py-0.5 rounded bg-bad text-white">SOS</span>}
                        </td>
                        <td className="px-3 py-2.5 tabular text-body whitespace-nowrap">{t.token}</td>
                        <td className="px-3 py-2.5 text-body">
                          {t.visitor}
                          {t.phone && <div className="text-[11.5px] text-muted tabular">{t.phone}</div>}
                        </td>
                        <td className="px-3 py-2.5 text-body">
                          {stops.length === 0 ? (
                            <span className="text-muted">Planning</span>
                          ) : curStop ? (
                            `Stop ${(t.leg ?? 0) + 1} of ${stops.length}: ${nodeLabel(curStop)}`
                          ) : t.returnToDesk && (t.leg ?? 0) === stops.length ? (
                            'Returning to Help Desk'
                          ) : (
                            'All stops done'
                          )}
                          {curStop && roomById[curStop] && <div className="text-[11.5px] text-muted">{roomById[curStop].building === 'B2' ? 'CSDS' : 'AI & ML'} · {floorName(roomById[curStop].level)}</div>}
                        </td>
                        <td className={`px-3 py-2.5 tabular ${expired ? 'text-bad' : 'text-muted'}`}>
                          {timeOf(t.validUntil)}
                          {expired ? ' · expired' : ''}
                          <div className="text-[11px]">issued {timeAgo(t.issuedAt)}</div>
                        </td>
                        <td className="px-5 py-2.5 text-right whitespace-nowrap">
                          <button type="button" className="btn !h-8 !px-2.5 !text-[12px]" onClick={() => onViewOnMap(t.token)}>
                            Locate
                          </button>{' '}
                          <button type="button" className="btn btn-danger !h-8 !px-2.5 !text-[12px]" onClick={() => patchToken(t.token, { status: 'returned', returnedAt: Date.now() })}>
                            <Undo2 className="w-3.5 h-3.5" /> Return
                          </button>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
