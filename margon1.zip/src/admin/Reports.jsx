import { useMemo, useState } from 'react'
import { Camera, CheckCircle2, Cpu, ShieldQuestion, User, XCircle } from 'lucide-react'
import { categoryLabel, closeInFacility, isClosed, targetLabel } from '../data/barriers'
import { VERIFY_THRESHOLD, combinedConfidence } from '../data/sensors'
import { timeAgo } from '../data/straps'
import { patchReport, saveFacility } from '../data/store'
import useStore from '../hooks/useStore'

function Bar({ value }) {
  const pct = Math.round(value * 100)
  const tone = value >= VERIFY_THRESHOLD ? '#16a34a' : value >= 0.6 ? '#ca8a04' : '#64748b'
  return (
    <div className="flex items-center gap-2" title={`Combined confidence ${pct}%`}>
      <div className="relative w-28 h-2 rounded-full bg-subtle overflow-hidden border border-line">
        <div className="absolute inset-y-0 left-0 rounded-full" style={{ width: `${pct}%`, background: tone }} />
        <div className="absolute inset-y-0 w-px bg-ink/40" style={{ left: `${VERIFY_THRESHOLD * 100}%` }} />
      </div>
      <span className="tabular text-[12px] font-semibold" style={{ color: tone }}>
        {pct}%
      </span>
    </div>
  )
}

const evidenceText = (r) => {
  const e = r.evidence ?? {}
  if (r.source === 'visitor') return r.note ? `“${r.note}”` : 'Reported by visitor'
  if (e.kind === 'steep-ramp') return `MPU pitch ${e.meanDeg}° (limit ${e.limitDeg}° for 1:12)`
  if (e.kind === 'lift-stall') return `Waited ${Math.round(e.waitSec / 60)} min at landing, height change ${e.pressureDeltaHpa} hPa`
  if (e.kind === 'turn-back') return `Strap turned back on this segment (${e.straps ?? 1} strap${(e.straps ?? 1) > 1 ? 's' : ''})`
  return 'Sensor flag'
}

export default function Reports() {
  const reports = useStore('reports')
  const fac = useStore('facility')
  const [photo, setPhoto] = useState(null)
  const [view, setView] = useState('pending')

  const groups = useMemo(() => {
    const g = {}
    Object.values(reports).forEach((r) => {
      const key = `${r.category}|${r.target}`
      g[key] = g[key] ?? { key, category: r.category, target: r.target, items: [] }
      g[key].items.push(r)
    })
    return Object.values(g)
      .map((x) => {
        const pending = x.items.filter((r) => r.status === 'pending')
        return { ...x, pending, confidence: combinedConfidence(pending), last: Math.max(...x.items.map((r) => r.ts)) }
      })
      .sort((a, b) => b.confidence - a.confidence || b.last - a.last)
  }, [reports])

  const pendingGroups = groups.filter((g) => g.pending.length)
  const history = Object.values(reports)
    .filter((r) => r.status !== 'pending')
    .sort((a, b) => (b.decidedTs ?? b.ts) - (a.decidedTs ?? a.ts))

  const decide = async (g, status) => {
    if (status === 'verified') await saveFacility(closeInFacility(fac, g.category, g.target))
    await Promise.all(g.pending.map((r) => patchReport(r.id, { status, decidedTs: Date.now() })))
  }

  return (
    <div className="h-full overflow-auto scroll-thin">
      <div className="max-w-5xl mx-auto px-4 py-6 flex flex-col gap-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="font-semibold text-ink text-[17px]">Barrier reports</h2>
            <p className="text-[12.5px] text-muted mt-0.5 max-w-2xl">
              Reports come from visitors and from strap sensors. Independent reports on the same item combine as 1 − Π(1 − cᵢ). Verify closes the item for every route;
              Dismiss keeps it open.
            </p>
          </div>
          <div className="flex p-1 rounded-xl bg-subtle border border-line" role="tablist">
            {[
              ['pending', `Pending (${pendingGroups.length})`],
              ['history', `Decided (${history.length})`],
            ].map(([k, l]) => (
              <button key={k} type="button" role="tab" aria-selected={view === k} onClick={() => setView(k)} className={`focus-ring h-8 px-3 rounded-lg text-[12.5px] font-medium ${view === k ? 'bg-surface shadow-sm text-ink' : 'text-muted'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>

        {view === 'pending' &&
          (pendingGroups.length === 0 ? (
            <div className="panel px-5 py-12 text-center text-[13px] text-muted">
              <ShieldQuestion className="w-8 h-8 mx-auto mb-2 text-line-strong" />
              No reports waiting. Visitor reports and strap sensor flags appear here for verification.
            </div>
          ) : (
            pendingGroups.map((g) => {
              const already = isClosed(fac, g.category, g.target)
              const recommend = g.confidence >= VERIFY_THRESHOLD
              return (
                <section key={g.key} className={`panel p-5 ${recommend ? 'border-ok/50' : ''}`}>
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="text-[11.5px] uppercase tracking-wide text-muted">{categoryLabel(g.category)}</div>
                      <div className="text-[16px] font-semibold text-ink">{targetLabel(g.category, g.target)}</div>
                      <div className="mt-1.5 flex items-center gap-3 text-[12px] text-muted">
                        <Bar value={g.confidence} />
                        <span>
                          {g.pending.length} report{g.pending.length > 1 ? 's' : ''} · {g.pending.filter((r) => r.source === 'strap').length} sensor ·{' '}
                          {g.pending.filter((r) => r.source === 'visitor').length} visitor
                        </span>
                      </div>
                      {recommend && <div className="mt-1 text-[12px] text-ok font-medium">Above {VERIFY_THRESHOLD * 100}%: verification recommended</div>}
                      {already && <div className="mt-1 text-[12px] text-bad">Already closed in Facilities</div>}
                    </div>
                    <div className="flex items-center gap-2">
                      <button type="button" className="btn btn-primary !h-9" onClick={() => decide(g, 'verified')}>
                        <CheckCircle2 className="w-4 h-4" /> Verify and close
                      </button>
                      <button type="button" className="btn !h-9" onClick={() => decide(g, 'dismissed')}>
                        <XCircle className="w-4 h-4" /> Dismiss
                      </button>
                    </div>
                  </div>
                  <ul className="mt-4 divide-y divide-line border-t border-line">
                    {g.pending
                      .sort((a, b) => b.ts - a.ts)
                      .map((r) => (
                        <li key={r.id} className="flex items-start gap-3 py-2.5">
                          <span className={`w-7 h-7 rounded-lg grid place-items-center shrink-0 ${r.source === 'strap' ? 'bg-alt/10 text-alt' : 'bg-brand/10 text-brand'}`}>
                            {r.source === 'strap' ? <Cpu className="w-4 h-4" /> : <User className="w-4 h-4" />}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="text-[13px] text-ink">{evidenceText(r)}</div>
                            <div className="text-[11.5px] text-muted">
                              {r.source === 'strap' ? 'Strap sensor' : 'Visitor'} · {r.strapId} · confidence {Math.round((r.confidence ?? 0.5) * 100)}% · {timeAgo(r.ts)}
                            </div>
                          </div>
                          {r.photo && (
                            <button type="button" onClick={() => setPhoto(r.photo)} className="focus-ring shrink-0 rounded-md overflow-hidden border border-line" title="View photo">
                              <img src={r.photo} alt="Reported barrier" className="w-16 h-12 object-cover" />
                            </button>
                          )}
                          {!r.photo && r.source === 'visitor' && <Camera className="w-4 h-4 text-line-strong mt-1" aria-label="No photo" />}
                        </li>
                      ))}
                  </ul>
                </section>
              )
            })
          ))}

        {view === 'history' && (
          <section className="panel overflow-hidden">
            {history.length === 0 ? (
              <p className="px-5 py-10 text-center text-[13px] text-muted">No decisions yet.</p>
            ) : (
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="text-left text-muted text-[11.5px] uppercase tracking-wide">
                    <th className="px-5 py-2 font-medium">Item</th>
                    <th className="px-3 py-2 font-medium">Source</th>
                    <th className="px-3 py-2 font-medium">Evidence</th>
                    <th className="px-5 py-2 font-medium">Decision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {history.map((r) => (
                    <tr key={r.id}>
                      <td className="px-5 py-2.5 text-ink">{targetLabel(r.category, r.target)}</td>
                      <td className="px-3 py-2.5 text-body">{r.source === 'strap' ? 'Sensor' : 'Visitor'}</td>
                      <td className="px-3 py-2.5 text-body">{evidenceText(r)}</td>
                      <td className={`px-5 py-2.5 font-medium ${r.status === 'verified' ? 'text-ok' : 'text-muted'}`}>
                        {r.status === 'verified' ? 'Verified' : 'Dismissed'} · {timeAgo(r.decidedTs)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        )}
      </div>

      {photo && (
        <button type="button" className="fixed inset-0 z-50 bg-black/70 grid place-items-center p-6" onClick={() => setPhoto(null)} aria-label="Close photo">
          <img src={photo} alt="Reported barrier" className="max-w-full max-h-full rounded-xl" />
        </button>
      )}
    </div>
  )
}
