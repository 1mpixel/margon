import { useMemo, useState } from 'react'
import { FlaskConical, Play } from 'lucide-react'
import { BUILDINGS, FLOORS, OPERATIONAL } from '../data/buildingData'
import { DESTINATIONS } from '../data/roomData'
import { GRAPH, START_POINTS, nodeLabel, profileFor, search, withDefaults } from '../data/routeData'
import { saveFacility } from '../data/store'
import useStore from '../hooks/useStore'

const ALGOS = [
  { id: 'dijkstra', name: 'Dijkstra', note: 'Binary-heap priority queue, explores by cost only' },
  { id: 'astar', name: 'A*', note: 'Same queue, plus an admissible distance heuristic' },
]

function Metric({ label, a, b, unit = '', lowerBetter = true }) {
  const max = Math.max(a, b) || 1
  const better = lowerBetter ? (a < b ? 'a' : b < a ? 'b' : null) : null
  return (
    <div className="grid grid-cols-[120px_1fr] items-center gap-3 py-2 border-b border-line last:border-0">
      <div className="text-[12.5px] text-muted">{label}</div>
      <div className="flex flex-col gap-1.5">
        {[
          ['Dijkstra', a, '#64748b', better === 'a'],
          ['A*', b, '#0f5f5a', better === 'b'],
        ].map(([n, v, c, win]) => (
          <div key={n} className="flex items-center gap-2">
            <span className="w-14 text-[11.5px] text-body">{n}</span>
            <div className="flex-1 h-3 rounded bg-subtle overflow-hidden">
              <div className="h-full rounded" style={{ width: `${(v / max) * 100}%`, background: c }} />
            </div>
            <span className={`w-20 text-right tabular text-[12px] ${win ? 'font-semibold text-ink' : 'text-body'}`}>
              {typeof v === 'number' ? (v < 10 ? v.toFixed(3) : v.toFixed(0)) : v}
              {unit}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function RoutingLab() {
  const fac = useStore('facility')
  const [from, setFrom] = useState('HD')
  const [to, setTo] = useState('B2-10-L5')
  const [mode, setMode] = useState('ramp')
  const [res, setRes] = useState(null)
  const [bench, setBench] = useState(null)
  const f = useMemo(() => withDefaults(fac), [fac])

  const run = () => {
    const p = profileFor(mode)
    const out = {}
    for (const a of ALGOS) {
      let best = null
      for (let i = 0; i < 5; i++) {
        const r = search(from, to, f, p, a.id)
        if (!best || r.ms < best.ms) best = r
      }
      out[a.id] = best
    }
    setRes(out)
  }

  const runBench = () => {
    const p = profileFor(mode)
    const ids = DESTINATIONS.map((d) => d.id)
    let seed = 42
    const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296)
    const agg = { dijkstra: { e: 0, ms: 0 }, astar: { e: 0, ms: 0 } }
    let same = 0
    let n = 0
    while (n < 300) {
      const a = ids[Math.floor(rnd() * ids.length)]
      const b = ids[Math.floor(rnd() * ids.length)]
      if (a === b) continue
      const d = search(a, b, f, p, 'dijkstra')
      const s = search(a, b, f, p, 'astar')
      if (!d.found || !s.found) {
        n++
        continue
      }
      agg.dijkstra.e += d.expanded
      agg.dijkstra.ms += d.ms
      agg.astar.e += s.expanded
      agg.astar.ms += s.ms
      if (Math.abs(d.cost - s.cost) < 1e-9) same++
      n++
    }
    setBench({ n, same, d: { e: agg.dijkstra.e / n, ms: agg.dijkstra.ms / n }, a: { e: agg.astar.e / n, ms: agg.astar.ms / n } })
  }

  const d = res?.dijkstra
  const a = res?.astar

  return (
    <div className="h-full overflow-auto scroll-thin">
      <div className="max-w-5xl mx-auto px-4 py-6 flex flex-col gap-5">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="font-semibold text-ink text-[17px] flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-brand" /> Routing lab
            </h2>
            <p className="text-[12.5px] text-muted mt-0.5">
              Campus graph: {Object.keys(GRAPH.nodes).length} nodes, {GRAPH.edges.length} edges, stored as adjacency lists. Current closures apply.
            </p>
          </div>
          <div className="flex items-center gap-2 text-[12.5px] text-body">
            Engine for visitor routes
            <div className="flex p-1 rounded-xl bg-subtle border border-line" role="radiogroup" aria-label="Routing engine">
              {ALGOS.map((x) => (
                <button
                  key={x.id}
                  type="button"
                  role="radio"
                  aria-checked={(fac.engine ?? 'astar') === x.id}
                  onClick={() => saveFacility({ ...fac, engine: x.id })}
                  className={`focus-ring h-8 px-3 rounded-lg text-[12.5px] font-medium ${(fac.engine ?? 'astar') === x.id ? 'bg-surface shadow-sm text-ink' : 'text-muted'}`}
                >
                  {x.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        <section className="panel p-5 grid gap-4">
          <div className="grid md:grid-cols-[1fr_1fr_200px_auto] gap-3 items-end">
            <div>
              <label className="label block mb-1.5" htmlFor="lab-from">
                From
              </label>
              <select id="lab-from" className="field" value={from} onChange={(e) => setFrom(e.target.value)}>
                {START_POINTS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
                {DESTINATIONS.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({r.building === 'B1' ? 'AI & ML' : 'CSDS'})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label block mb-1.5" htmlFor="lab-to">
                To
              </label>
              <select id="lab-to" className="field" value={to} onChange={(e) => setTo(e.target.value)}>
                {BUILDINGS.flatMap((b) =>
                  FLOORS.filter((fl) => OPERATIONAL.includes(fl.level)).map((fl) => (
                    <optgroup key={`${b.id}${fl.level}`} label={`${b.short} · ${fl.name}`}>
                      {DESTINATIONS.filter((r) => r.building === b.id && r.level === fl.level).map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                    </optgroup>
                  )),
                )}
              </select>
            </div>
            <div>
              <label className="label block mb-1.5" htmlFor="lab-mode">
                Preference
              </label>
              <select id="lab-mode" className="field" value={mode} onChange={(e) => setMode(e.target.value)}>
                <option value="ramp">Ramp + Lift</option>
                <option value="steps">Steps + Lift</option>
              </select>
            </div>
            <button type="button" className="btn btn-primary !h-10" onClick={run}>
              <Play className="w-4 h-4" /> Compare
            </button>
          </div>

          {res &&
            (d?.found ? (
              <div className="grid md:grid-cols-[1fr_260px] gap-5">
                <div>
                  <Metric label="Nodes expanded" a={d.expanded} b={a.expanded} />
                  <Metric label="Queue insertions" a={d.pushes} b={a.pushes} />
                  <Metric label="Search time" a={d.ms} b={a.ms} unit=" ms" />
                  <Metric label="Path cost" a={d.cost} b={a.cost} lowerBetter={false} />
                </div>
                <div className="rounded-xl bg-subtle p-4 text-[12.5px] text-body flex flex-col gap-2">
                  <div className="font-semibold text-ink">{Math.abs(d.cost - a.cost) < 1e-9 ? 'Same optimal cost' : 'Costs differ'}</div>
                  <div>
                    A* expanded <b className="text-ink">{(100 * (1 - a.expanded / d.expanded)).toFixed(0)}% fewer</b> nodes for {nodeLabel(from)} → {nodeLabel(to)}.
                  </div>
                  <div className="text-muted">
                    Heuristic h(n) = 0.9 × horizontal distance + 0.6 × height difference. No edge costs less, so A* stays optimal.
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-[13px] text-bad">No step-free route with the current closures.</p>
            ))}
        </section>

        <section className="panel p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="font-semibold text-ink">Benchmark</div>
              <div className="text-[12.5px] text-muted">300 random room-to-room pairs with the current closures and preference.</div>
            </div>
            <button type="button" className="btn" onClick={runBench}>
              <Play className="w-4 h-4" /> Run benchmark
            </button>
          </div>
          {bench && (
            <div className="mt-4 grid sm:grid-cols-4 gap-3">
              {[
                ['Pairs tested', bench.n],
                ['Identical optimal cost', `${bench.same} / ${bench.n}`],
                ['Nodes expanded (avg)', `${bench.d.e.toFixed(0)} → ${bench.a.e.toFixed(0)}`],
                ['Reduction with A*', `${(100 * (1 - bench.a.e / bench.d.e)).toFixed(1)}%`],
              ].map(([k, v]) => (
                <div key={k} className="rounded-xl border border-line px-4 py-3">
                  <div className="tabular text-[20px] font-semibold text-ink">{v}</div>
                  <div className="text-[11.5px] text-muted">{k}</div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
