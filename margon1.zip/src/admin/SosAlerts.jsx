import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { BellRing, CheckCheck, MapPin, Siren } from 'lucide-react'
import { BUILDINGS, floorName } from '../data/buildingData'
import { timeAgo } from '../data/straps'
import { patchToken } from '../data/store'
import useStore from '../hooks/useStore'

export const SOS_TYPES = {
  fall: { en: 'Fall or impact detected by strap', hi: 'स्ट्रैप ने गिरने का पता लगाया' },
  accident: { en: 'Accident', hi: 'दुर्घटना' },
  medical: { en: 'Medical help', hi: 'चिकित्सा सहायता' },
  assist: { en: 'Needs assistance', hi: 'सहायता चाहिए' },
}

const blockAt = (x) => (x == null ? '' : BUILDINGS.reduce((b, c) => (Math.abs(x - c.ox) < Math.abs(x - b.ox) ? c : b)).short)
export const sosWhere = (tm) => {
  if (!tm) return 'Location unknown'
  const outside = Math.abs(tm.z) > 10.5 || tm.relHeight < -0.2
  return outside ? `Campus forecourt (${tm.x.toFixed(0)}, ${tm.z.toFixed(0)})` : `${blockAt(tm.x)} Block · ${floorName(tm.level)} (${tm.x.toFixed(0)}, ${tm.z.toFixed(0)})`
}

// Repeating two-tone alarm while any SOS is unacknowledged.
function useAlarm(on) {
  const ctx = useRef(null)
  useEffect(() => {
    if (!on) return
    let stopped = false
    const AC = window.AudioContext || window.webkitAudioContext
    if (!AC) return
    if (!ctx.current) ctx.current = new AC()
    const c = ctx.current
    c.resume?.()
    const beep = () => {
      if (stopped) return
      ;[880, 660].forEach((f, i) => {
        const o = c.createOscillator()
        const g = c.createGain()
        o.frequency.value = f
        g.gain.setValueAtTime(0.0001, c.currentTime + i * 0.22)
        g.gain.exponentialRampToValueAtTime(0.25, c.currentTime + i * 0.22 + 0.02)
        g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + i * 0.22 + 0.2)
        o.connect(g).connect(c.destination)
        o.start(c.currentTime + i * 0.22)
        o.stop(c.currentTime + i * 0.22 + 0.22)
      })
    }
    beep()
    const id = setInterval(beep, 1800)
    return () => {
      stopped = true
      clearInterval(id)
    }
  }, [on])
}

export default function SosAlerts({ onLocate }) {
  const tokens = useStore('tokens')
  const [, tick] = useState(0)
  useEffect(() => {
    const id = setInterval(() => tick((n) => n + 1), 5000)
    return () => clearInterval(id)
  }, [])
  const alerts = useMemo(
    () =>
      Object.values(tokens)
        .filter((t) => t.status === 'active' && t.sos?.active)
        .sort((a, b) => b.sos.ts - a.sos.ts),
    [tokens],
  )
  const unacked = alerts.some((a) => !a.sos.ack)
  useAlarm(unacked)

  return (
    <AnimatePresence>
      {alerts.length > 0 && (
        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="shrink-0 overflow-hidden" role="alert" aria-live="assertive">
          <div className="flex flex-col gap-px bg-bad/30">
            {alerts.map((t) => {
              const s = t.sos
              return (
                <div key={t.token} className={`flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-2.5 text-white ${s.ack ? 'bg-[#b45309]' : 'bg-bad'}`}>
                  <span className="inline-flex items-center gap-2 font-semibold text-[14px]">
                    {s.ack ? <BellRing className="w-5 h-5" /> : <Siren className="w-5 h-5 animate-pulse" />} SOS · {t.strapId}
                  </span>
                  <span className="text-[13px]">
                    {t.visitor}
                    {t.phone ? ` · ${t.phone}` : ''} · {SOS_TYPES[s.type]?.en ?? 'Help requested'}
                  </span>
                  <span className="inline-flex items-center gap-1 text-[13px] opacity-95">
                    <MapPin className="w-4 h-4" />
                    {sosWhere(s.telemetry ?? t.telemetry)}
                  </span>
                  <span className="text-[12px] opacity-85">{timeAgo(s.ts)}</span>
                  <span className="ml-auto flex items-center gap-1.5">
                    <button type="button" className="btn !h-8 !bg-white/15 !border-white/40 !text-white hover:!bg-white/25" onClick={() => onLocate(t.token)}>
                      Locate
                    </button>
                    {!s.ack ? (
                      <button type="button" className="btn !h-8 !bg-white !text-bad !border-white" onClick={() => patchToken(t.token, { sos: { ...s, ack: true, ackTs: Date.now() } })}>
                        Acknowledge
                      </button>
                    ) : (
                      <button type="button" className="btn !h-8 !bg-white !text-[#b45309] !border-white" onClick={() => patchToken(t.token, { sos: { ...s, active: false, resolvedTs: Date.now() } })}>
                        <CheckCheck className="w-4 h-4" /> Resolved
                      </button>
                    )}
                  </span>
                </div>
              )
            })}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
