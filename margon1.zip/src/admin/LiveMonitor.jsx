import { useEffect, useMemo, useState } from 'react'
import { Compass, Gauge, MapPin, Mountain } from 'lucide-react'
import SceneView from '../components/SceneView'
import { floorName } from '../data/buildingData'
import { computeRoute, nodeLabel, profileFor } from '../data/routeData'
import { DESK_GROUND_OFFSET_M, NAV_LABEL, P_REF_DESK, compass, timeAgo } from '../data/straps'
import { floorFromPressure } from '../data/sensors'
import useStore from '../hooks/useStore'

const NAV_COLOR = { running: '#0f5f5a', paused: '#ca8a04', arrived: '#16a34a', idle: '#64748b' }
const PANEL_W = 380

export default function LiveMonitor({ selected, setSelected, paused }) {
  const tokens = useStore('tokens')
  const fac = useStore('facility')
  const [, tick] = useState(0)
  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 5000)
    return () => clearInterval(t)
  }, [])

  const active = useMemo(
    () => Object.values(tokens).filter((t) => t.status === 'active').sort((a, b) => (b.sos?.active ? 1 : 0) - (a.sos?.active ? 1 : 0) || a.strapId.localeCompare(b.strapId)),
    [tokens],
  )
  const sel = active.find((t) => t.token === selected) ?? null
  const selDest = sel?.stops?.[sel.leg ?? 0] ?? null
  const route = useMemo(() => (sel && selDest ? computeRoute(sel.lastNode ?? 'HD', selDest, fac, profileFor(sel.mode)) : null), [sel, selDest, fac])

  const chairs = useMemo(
    () =>
      active
        .filter((t) => t.telemetry)
        .map((t) => ({
          id: t.token,
          label: t.strapId,
          x: t.telemetry.x,
          z: t.telemetry.z,
          relHeight: t.telemetry.relHeight,
          color: t.sos?.active ? '#dc2626' : NAV_COLOR[t.nav] ?? NAV_COLOR.idle,
          selected: t.token === selected,
        })),
    [active, selected],
  )

  const moving = active.filter((t) => t.nav === 'running').length
  const closures =
    Object.values(fac.elevators).filter((v) => !v).length +
    Object.values(fac.ramps).filter((v) => !v).length +
    Object.values(fac.stairs).filter((v) => !v).length +
    fac.blocked.length

  return (
    <div className="relative h-full">
      <SceneView
        facilities={fac}
        route={route}
        startId={sel ? sel.lastNode ?? 'HD' : undefined}
        destId={selDest ?? undefined}
        showUser={false}
        paused={paused}
        chairs={chairs}
        rightInset={PANEL_W + 24}
        onSelect={(o) => o?.kind === 'chair' && setSelected(o.id)}
      />
      <aside className="panel absolute right-4 top-4 bottom-4 z-20 flex flex-col overflow-hidden" style={{ width: PANEL_W }} aria-label="Active straps">
        <div className="grid grid-cols-3 border-b border-line">
          {[
            ['Active', active.length],
            ['Moving', moving],
            ['Closures', closures],
          ].map(([k, v]) => (
            <div key={k} className="px-4 py-3">
              <div className={`tabular text-[22px] font-semibold ${k === 'Closures' && v ? 'text-bad' : 'text-ink'}`}>{v}</div>
              <div className="text-[11.5px] text-muted">{k}</div>
            </div>
          ))}
        </div>
        <div className="px-4 pt-3 pb-2 text-[11.5px] text-muted">Positions from strap sensors: Wi-Fi (ESP32), motion (MPU6050), pressure (BMP280) checked against the desk reference barometer</div>
        <div className="flex-1 overflow-auto scroll-thin px-3 pb-3 flex flex-col gap-2">
          {active.length === 0 && <p className="px-2 py-8 text-center text-[13px] text-muted">No straps in use. Issue a strap to see it here.</p>}
          {active.map((t) => {
            const tm = t.telemetry ?? {}
            const on = t.token === selected
            const r = on ? route : null
            return (
              <button
                key={t.token}
                type="button"
                onClick={() => setSelected(on ? null : t.token)}
                className={`focus-ring text-left rounded-lg border px-3 py-2.5 transition-colors ${t.sos?.active ? 'border-bad bg-bad/5' : on ? 'border-brand bg-brand/5' : 'border-line hover:bg-subtle'}`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: t.sos?.active ? '#dc2626' : NAV_COLOR[t.nav] ?? NAV_COLOR.idle }} />
                  <span className="tabular text-[13px] font-semibold text-ink">{t.strapId}</span>
                  <span className="tabular text-[12px] text-muted">{t.token}</span>
                  <span className={`ml-auto text-[11.5px] ${t.sos?.active ? 'text-bad font-semibold' : 'text-muted'}`}>{t.sos?.active ? 'SOS' : NAV_LABEL[t.nav] ?? 'Ready'}</span>
                </div>
                <div className="mt-1 text-[12.5px] text-body truncate">
                  {t.visitor}
                  {(t.stops ?? []).length > 0
                    ? t.stops[t.leg ?? 0]
                      ? ` · stop ${(t.leg ?? 0) + 1} of ${t.stops.length}: ${nodeLabel(t.stops[t.leg ?? 0])}`
                      : ' · trip complete'
                    : ' · planning trip'}
                </div>
                <div className="mt-2 grid grid-cols-4 gap-2 text-[11.5px]">
                  <span className="flex items-center gap-1 text-ink" title="Floor from barometric height">
                    <Mountain className="w-3.5 h-3.5 text-muted" />
                    {tm.level === undefined ? '-' : tm.level === 0 ? 'G' : tm.level}
                  </span>
                  <span className="flex items-center gap-1 text-ink tabular col-span-2" title="Position (x, y) in metres">
                    <MapPin className="w-3.5 h-3.5 text-muted" />
                    {tm.x?.toFixed?.(1) ?? '-'}, {tm.z?.toFixed?.(1) ?? '-'}
                  </span>
                  <span className="flex items-center gap-1 text-ink tabular" title="Heading">
                    <Compass className="w-3.5 h-3.5 text-muted" />
                    {tm.heading !== undefined ? compass(tm.heading) : '-'}
                  </span>
                </div>
                <div className="mt-1.5 flex items-center gap-1 text-[11px] text-muted">
                  <Gauge className="w-3 h-3" />
                  {tm.pressure
                    ? (() => {
                        const b = floorFromPressure(tm.pressure, P_REF_DESK, DESK_GROUND_OFFSET_M)
                        return `${tm.pressure} hPa vs desk ${P_REF_DESK} → floor ${b.level === 0 ? 'G' : b.level} (${Math.round(b.confidence * 100)}%)`
                      })()
                    : 'No reading'}{' '}
                  · {timeAgo(tm.ts)}
                </div>
                {t.telemetryRejected && Date.now() - t.telemetryRejected.ts < 60000 && (
                  <div className="mt-1 text-[11px] text-bad">Reading rejected: {t.telemetryRejected.issues.join(', ')}</div>
                )}
                {on && r && (
                  <div className={`mt-2 text-[12px] rounded-md px-2 py-1.5 ${!r.ok ? 'bg-bad/8 text-bad' : r.kind === 'alternative' ? 'bg-alt/8 text-alt' : 'bg-ok/8 text-ok'}`}>
                    {!r.ok
                      ? 'No step-free route. Send assistance.'
                      : `${r.kind === 'alternative' ? 'Alternative' : 'Recommended'} route · ${r.distance} m · ${floorName(r.endLevel)}`}
                    {r.ok && r.instructions[t.step] && <div className="text-body mt-0.5">Now: {r.instructions[t.step].text}</div>}
                  </div>
                )}
              </button>
            )
          })}
        </div>
      </aside>
    </div>
  )
}
