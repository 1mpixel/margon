import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Camera, Flag, X } from 'lucide-react'
import { CATEGORIES, nearestTarget, targetLabel, visitorConfidence } from '../data/barriers'
import { saveReport } from '../data/store'

const TXT = {
  en: {
    open: 'Report a barrier',
    title: 'Report a barrier',
    sub: 'Your report goes to the Help Desk for verification.',
    near: 'Nearest to you',
    note: 'Details (optional)',
    photo: 'Add photo (optional)',
    send: 'Send report',
    cancel: 'Cancel',
    sent: 'Report sent. The Help Desk will verify it.',
  },
  hi: {
    open: 'बाधा की सूचना दें',
    title: 'बाधा की सूचना दें',
    sub: 'आपकी सूचना सत्यापन के लिए सहायता डेस्क को भेजी जाएगी।',
    near: 'आपके सबसे पास',
    note: 'विवरण (वैकल्पिक)',
    photo: 'फ़ोटो जोड़ें (वैकल्पिक)',
    send: 'सूचना भेजें',
    cancel: 'रद्द करें',
    sent: 'सूचना भेज दी गई। सहायता डेस्क इसकी पुष्टि करेगा।',
  },
}

// Downscale a photo to keep the report small (shared store documents are limited to 256 KB).
function compress(file) {
  return new Promise((resolve, reject) => {
    const img = new Image()
    const url = URL.createObjectURL(file)
    img.onload = () => {
      const s = Math.min(1, 640 / Math.max(img.width, img.height))
      const c = document.createElement('canvas')
      c.width = Math.round(img.width * s)
      c.height = Math.round(img.height * s)
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height)
      URL.revokeObjectURL(url)
      resolve(c.toDataURL('image/jpeg', 0.6))
    }
    img.onerror = reject
    img.src = url
  })
}

export default function ReportBarrier({ token, lang, telemetry, hints = {}, onSent }) {
  const L = TXT[lang]
  const [open, setOpen] = useState(false)
  const [cat, setCat] = useState('lift')
  const [note, setNote] = useState('')
  const [photo, setPhoto] = useState(null)
  const [busy, setBusy] = useState(false)
  // Prefer the facility on the visitor's current route; otherwise the nearest one.
  const target = hints[cat] ?? nearestTarget(cat, telemetry)

  const send = async () => {
    if (!target) return
    setBusy(true)
    await saveReport({
      source: 'visitor',
      category: cat,
      target,
      note: note.trim(),
      photo,
      token: token.token,
      strapId: token.strapId,
      confidence: visitorConfidence(!!photo),
      telemetry,
      ts: Date.now(),
      status: 'pending',
    })
    setBusy(false)
    setOpen(false)
    setNote('')
    setPhoto(null)
    onSent?.(L.sent)
  }

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="focus-ring mt-2 w-full h-10 rounded-xl border border-line text-[13.5px] font-medium text-ink flex items-center justify-center gap-2 hover:bg-subtle">
        <Flag className="w-4 h-4 text-warn" /> {L.open}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div className="fixed inset-0 z-50 grid place-items-center bg-black/40 px-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)}>
            <motion.div className="panel w-full max-w-md p-5 flex flex-col gap-4" initial={{ y: 30 }} animate={{ y: 0 }} exit={{ y: 30 }} onClick={(e) => e.stopPropagation()} role="dialog" aria-label={L.title}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-semibold text-ink text-[16px]">{L.title}</div>
                  <div className="text-[12.5px] text-muted">{L.sub}</div>
                </div>
                <button type="button" onClick={() => setOpen(false)} className="focus-ring text-muted hover:text-ink" aria-label={L.cancel}>
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="grid gap-1.5" role="radiogroup">
                {CATEGORIES.map((c) => (
                  <button key={c.id} type="button" role="radio" aria-checked={cat === c.id} onClick={() => setCat(c.id)} className={`focus-ring text-left px-3 py-2.5 rounded-lg border text-[13.5px] ${cat === c.id ? 'border-brand bg-brand/5 text-brand font-medium' : 'border-line text-ink hover:bg-subtle'}`}>
                    {c[lang]}
                  </button>
                ))}
              </div>
              <div className="rounded-lg bg-subtle px-3 py-2 text-[12.5px]">
                <span className="text-muted">{L.near}: </span>
                <span className="text-ink font-medium">{targetLabel(cat, target, lang)}</span>
              </div>
              <div>
                <label className="label block mb-1.5" htmlFor="rep-note">
                  {L.note}
                </label>
                <textarea id="rep-note" rows={2} className="field !h-auto py-2 resize-none" value={note} onChange={(e) => setNote(e.target.value)} />
              </div>
              <div className="flex items-center gap-3">
                <label className="btn cursor-pointer">
                  <Camera className="w-4 h-4" /> {L.photo}
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="sr-only"
                    onChange={async (e) => {
                      const f = e.target.files?.[0]
                      if (f) setPhoto(await compress(f).catch(() => null))
                    }}
                  />
                </label>
                {photo && <img src={photo} alt="" className="h-12 w-16 object-cover rounded-md border border-line" />}
              </div>
              <button type="button" className="btn btn-primary !h-11" onClick={send} disabled={busy || !target}>
                {L.send}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
