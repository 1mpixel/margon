import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import * as THREE from 'three'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowDownToLine,
  ArrowUp,
  ArrowUpToLine,
  CircleAlert,
  CircleCheck,
  CornerUpLeft,
  CornerUpRight,
  DoorOpen,
  Flag,
  Footprints,
  Gauge,
  ListChecks,
  LocateFixed,
  LogOut,
  MapPinned,
  Pause,
  Play,
  Repeat2,
  RotateCcw,
  TrendingDown,
  TrendingUp,
  Undo2,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react'
import Brand from '../components/Brand'
import SyncBadge from '../components/SyncBadge'
import SceneView from '../components/SceneView'
import TripPlanner from './TripPlanner'
import SosControl from './SosControl'
import ReportBarrier from './ReportBarrier'
import { nearestTarget, targetLabel } from '../data/barriers'
import { SOURCE_CONFIDENCE, detectLiftStall, detectSteepRamp, validateTelemetry } from '../data/sensors'
import { floorName, floorNameHi } from '../data/buildingData'
import { roomById } from '../data/roomData'
import { GRAPH, closureList, computeRoute, formatStep, formatTime, hoursLabel, maneuverOf, nodeLabel, orderStops, profileFor, tokenState } from '../data/routeData'
import { compass, telemetryAtNode, telemetryFromScene } from '../data/straps'
import { patchToken, saveReport } from '../data/store'
import { hasVoice, speak, stopSpeaking, voiceInfo, voiceSupported, voicesReady } from '../data/voice'
import useStore from '../hooks/useStore'

const PANEL_W = 380
const ICON = {
  left: CornerUpLeft,
  right: CornerUpRight,
  straight: ArrowUp,
  uturn: Undo2,
  'lift-up': ArrowUpToLine,
  'lift-down': ArrowDownToLine,
  'ramp-up': TrendingUp,
  'ramp-down': TrendingDown,
  stairs: Footprints,
  exit: DoorOpen,
  arrive: Flag,
}
const HOLD_KINDS = new Set(['lift', 'ramp', 'door', 'stairs', 'arrive'])
const inTransit = (id) => ['liftDoor', 'liftCar', 'stair'].includes(GRAPH.nodes[id]?.kind)

const T = {
  en: {
    plan: 'Plan your visit',
    planSub: 'Choose where you want to go. You can add several places.',
    startTrip: 'Start trip',
    updateTrip: 'Save stops',
    stop: 'Stop',
    of: 'of',
    returnDesk: 'Return to Help Desk',
    route: 'Route available',
    alt: 'Alternative route',
    none: 'No route available',
    uses: 'Uses lift',
    noLift: 'No lift needed',
    avoids: 'Avoids',
    notices: 'Notices',
    readings: 'Strap readings',
    steps: 'Steps',
    trip: 'Trip',
    then: 'Then',
    start: 'Start',
    resume: 'Resume',
    pause: 'Pause',
    follow: 'Follow',
    repeat: 'Repeat',
    pressStart: 'Press Start to begin guidance',
    remaining: 'remaining',
    arrive: 'Arrive',
    arrivedAt: 'Arrived at stop',
    continue: 'Continue to next stop',
    tripDone: 'Trip complete',
    tripDoneSub: 'You have visited all your stops.',
    planMore: 'Plan more stops',
    floor: 'Floor',
    height: 'Height',
    pressure: 'Pressure',
    position: 'Position',
    heading: 'Heading',
    speed: 'Speed',
    sent: 'Sent to the Help Desk from strap',
    impact: 'Simulate impact (motion sensor)',
    simTitle: 'Strap sensor events (simulation)',
    simImpact: 'Impact (MPU)',
    simRamp: 'Steep ramp (MPU tilt)',
    simLift: 'Lift not arriving (baro)',
    simTurn: 'Turned back (blocked)',
    simBad: 'Faulty reading',
    flagged: 'Sensor flag sent for verification',
    rejected: 'Reading rejected by validation',
    exit: 'Exit',
    changed: 'Route changed',
    restored: 'Recommended route restored.',
    blocked: 'No step-free route right now. Please wait or press SOS for help.',
    noHindi: 'No Hindi voice is installed on this device. Hindi text is shown; voice uses English. To add Hindi: Windows Settings > Time & language > Language > Add Hindi with Speech. Android: Settings > Text-to-speech > Google > install Hindi.',
    testVoice: 'Test voice',
    testLine: 'Voice guidance is working.',
    validUntil: 'Valid until',
    expired: 'Your strap time has ended',
    expiredSub: `Straps are valid ${hoursLabel('en')}. Please return to the Help Desk.`,
    closed: 'Token not active',
    closedSub: 'This strap has been returned. Please visit the Help Desk.',
    back: 'Back',
    pace: 'Pace',
  },
  hi: {
    plan: 'अपनी यात्रा तय करें',
    planSub: 'जहाँ जाना है वह चुनें। आप कई स्थान जोड़ सकते हैं।',
    startTrip: 'यात्रा शुरू करें',
    updateTrip: 'स्थान सहेजें',
    stop: 'पड़ाव',
    of: 'में से',
    returnDesk: 'सहायता डेस्क पर वापसी',
    route: 'मार्ग उपलब्ध',
    alt: 'वैकल्पिक मार्ग',
    none: 'कोई मार्ग उपलब्ध नहीं',
    uses: 'लिफ्ट',
    noLift: 'लिफ्ट की ज़रूरत नहीं',
    avoids: 'बचाव',
    notices: 'सूचनाएँ',
    readings: 'स्ट्रैप रीडिंग',
    steps: 'चरण',
    trip: 'यात्रा',
    then: 'फिर',
    start: 'शुरू करें',
    resume: 'जारी रखें',
    pause: 'रोकें',
    follow: 'साथ चलें',
    repeat: 'दोहराएँ',
    pressStart: 'मार्गदर्शन के लिए शुरू करें दबाएँ',
    remaining: 'शेष',
    arrive: 'पहुँचना',
    arrivedAt: 'पड़ाव पर पहुँचे',
    continue: 'अगले पड़ाव की ओर चलें',
    tripDone: 'यात्रा पूरी हुई',
    tripDoneSub: 'आपने सभी पड़ाव देख लिए हैं।',
    planMore: 'और स्थान जोड़ें',
    floor: 'मंज़िल',
    height: 'ऊँचाई',
    pressure: 'दबाव',
    position: 'स्थिति',
    heading: 'दिशा',
    speed: 'गति',
    sent: 'सहायता डेस्क को भेजा गया, स्ट्रैप',
    impact: 'टक्कर का अनुकरण (मोशन सेंसर)',
    simTitle: 'स्ट्रैप सेंसर घटनाएँ (अनुकरण)',
    simImpact: 'टक्कर (MPU)',
    simRamp: 'खड़ी ढलान (MPU झुकाव)',
    simLift: 'लिफ्ट नहीं आई (बैरोमीटर)',
    simTurn: 'वापस मुड़े (रास्ता बंद)',
    simBad: 'गलत रीडिंग',
    flagged: 'सेंसर सूचना सत्यापन के लिए भेजी गई',
    rejected: 'रीडिंग अस्वीकार की गई',
    exit: 'बाहर',
    changed: 'मार्ग बदला गया',
    restored: 'अनुशंसित मार्ग फिर से उपलब्ध है।',
    blocked: 'अभी कोई सुलभ मार्ग नहीं है। कृपया प्रतीक्षा करें या सहायता के लिए SOS दबाएँ।',
    noHindi: 'इस डिवाइस पर हिंदी आवाज़ इंस्टॉल नहीं है। निर्देश हिंदी में दिखाए जा रहे हैं, आवाज़ अंग्रेज़ी में है। हिंदी जोड़ने के लिए: Windows Settings > Time & language > Language > Add Hindi (Speech सहित)। Android: Settings > Text-to-speech > Google > Hindi इंस्टॉल करें।',
    testVoice: 'आवाज़ जाँचें',
    testLine: 'आवाज़ मार्गदर्शन काम कर रहा है।',
    validUntil: 'मान्य',
    expired: 'स्ट्रैप का समय समाप्त हो गया',
    expiredSub: `स्ट्रैप ${hoursLabel('hi')} मान्य है। कृपया सहायता डेस्क पर लौटें।`,
    closed: 'टोकन सक्रिय नहीं है',
    closedSub: 'यह स्ट्रैप लौटाया जा चुका है। कृपया सहायता डेस्क पर जाएँ।',
    back: 'वापस',
    pace: 'गति',
  },
}

const LANG_KEY = 'margon.lang'
const readLang = () => {
  try {
    return localStorage.getItem(LANG_KEY) === 'hi' ? 'hi' : 'en'
  } catch {
    return 'en'
  }
}
const lowerFirst = (s, lang) => (lang === 'hi' || !s ? s : s.charAt(0).toLowerCase() + s.slice(1))

export default function VisitorNavigator({ tokenId, onLogout }) {
  const tokens = useStore('tokens')
  const fac = useStore('facility')
  const t = tokens[tokenId]
  const tState = tokenState(t)

  const [lang, setLang] = useState(readLang)
  const [voiceOn, setVoiceOn] = useState(voiceSupported())
  const [voiceReady, setVoiceReady] = useState(false)
  const [follow, setFollow] = useState(true)
  const [speedMul, setSpeedMul] = useState(1)
  const [tab, setTab] = useState('steps')
  const [phase, setPhase] = useState(() => ((t?.stops ?? []).length ? 'nav' : 'plan'))
  const [draft, setDraft] = useState(() => t?.stops?.slice(t?.leg ?? 0) ?? [])
  const [mode, setMode] = useState(t?.mode ?? 'ramp')
  const [returnToDesk, setReturnToDesk] = useState(t?.returnToDesk ?? true)
  const [plan, setPlan] = useState(() => ({ origin: t?.lastNode ?? 'HD', fac }))
  const [navStatus, setNavStatus] = useState('idle')
  const [stepIndex, setStepIndex] = useState(0)
  const [toast, setToast] = useState(null)
  const [live, setLive] = useState(() => telemetryAtNode(t?.lastNode ?? 'HD'))
  const [prog, setProg] = useState({ step: 0, route: 0 })
  const [fallSignal, setFallSignal] = useState(0)
  const progressRef = useRef(0)
  const navRef = useRef({ pos: new THREE.Vector3(), dir: new THREE.Vector3(0, 0, -1), elev: null, lastElev: null, lastY: 0, stepFrac: 0, routeFrac: 0, hold: false, speed: 1 })
  const gapRef = useRef(5.6)
  const prevTm = useRef(null)
  const lastWrite = useRef(0)
  const lastSent = useRef(null)
  const [note, setNote] = useState(null)
  const aheadSaid = useRef(-1)
  const L = T[lang]

  useEffect(() => {
    try {
      localStorage.setItem(LANG_KEY, lang)
    } catch {
      /* ignore */
    }
  }, [lang])
  useEffect(() => {
    voicesReady().then(() => setVoiceReady(true))
  }, [])
  useEffect(() => {
    navRef.current.speed = speedMul
  }, [speedMul])
  useEffect(() => () => stopSpeaking(), [])

  // Trip: the visitor's stops plus an optional final leg back to the Help Desk.
  const stops = useMemo(() => t?.stops ?? [], [t?.stops])
  const leg = t?.leg ?? 0
  const targets = useMemo(() => [...stops, ...(t?.returnToDesk && stops.length ? ['HD'] : [])], [stops, t?.returnToDesk])
  const target = targets[leg] ?? null
  const profile = useMemo(() => profileFor(t?.mode ?? mode), [t?.mode, mode])

  const route = useMemo(() => {
    if (phase === 'plan') {
      const first = draft[0]
      return first ? computeRoute(plan.origin, first, fac, profileFor(mode)) : null
    }
    return target && plan.origin ? computeRoute(plan.origin, target, plan.fac, profile) : null
  }, [phase, draft, mode, plan, target, profile, fac])
  const steps = route?.ok ? route.instructions : []
  const cur = steps[stepIndex]
  const next = steps[stepIndex + 1]
  const say = useCallback((text, opts) => (voiceOn ? speak(text, lang, opts) : Promise.resolve()), [voiceOn, lang])

  const resetLeg = useCallback((origin) => {
    progressRef.current = 0
    lastSent.current = null
    navRef.current.hold = false
    navRef.current.stepFrac = 0
    navRef.current.routeFrac = 0
    setProg({ step: 0, route: 0 })
    aheadSaid.current = -1
    setStepIndex(0)
    setNavStatus('idle')
    setPlan((p) => ({ origin: origin ?? p.origin, fac }))
  }, [fac])

  // Re-plan from the current position whenever the Admin changes a facility.
  const lastFacTs = useRef(fac.updatedAt)
  useEffect(() => {
    if (fac.updatedAt === lastFacTs.current) return
    lastFacTs.current = fac.updatedAt
    if (phase !== 'nav') return
    const step = route?.ok ? route.instructions[stepIndex] : null
    const here = route?.ok && navStatus !== 'idle' && step ? route.nodeIds[Math.min(step.i0, route.nodeIds.length - 1)] : plan.origin
    const safeHere = here && !inTransit(here) ? here : plan.origin
    const nextRoute = target ? computeRoute(safeHere, target, fac, profile) : null
    const prevSig = route?.ok ? route.edges.map((e) => e.id).join() : ''
    const nextSig = nextRoute?.ok ? nextRoute.edges.map((e) => e.id).join() : ''
    if (prevSig === nextSig) {
      setPlan((p) => ({ ...p, fac }))
      return
    }
    const wasRunning = navStatus === 'running'
    resetLeg(safeHere)
    if (!nextRoute?.ok) setToast({ tone: 'bad', key: 'blocked' })
    else {
      setToast({ tone: nextRoute.kind === 'alternative' ? 'alt' : 'ok', key: nextRoute.kind === 'alternative' ? 'changed' : 'restored', reasons: nextRoute.reasons })
      if (wasRunning) setTimeout(() => setNavStatus('running'), 600)
    }
  }, [fac]) // eslint-disable-line react-hooks/exhaustive-deps

  const toastText = toast ? (toast.key === 'changed' ? `${L.changed}: ${toast.reasons.map((r) => r[lang]).join('; ')}.` : L[toast.key]) : ''
  useEffect(() => {
    if (!toast) return
    say(toastText, { interrupt: true })
    const id = setTimeout(() => setToast(null), 7000)
    return () => clearTimeout(id)
  }, [toast]) // eslint-disable-line react-hooks/exhaustive-deps

  // Voice: announce each new step; wait at lifts, ramps and doors until it has been spoken.
  useEffect(() => {
    if (navStatus !== 'running' || !cur) return
    aheadSaid.current = -1
    const text = formatStep(cur, lang)
    if (voiceOn && HOLD_KINDS.has(cur.kind)) {
      navRef.current.hold = true
      say(text).then(() => {
        navRef.current.hold = false
      })
    } else say(text)
  }, [stepIndex, navStatus === 'running']) // eslint-disable-line react-hooks/exhaustive-deps

  // Arrival at a stop
  useEffect(() => {
    if (navStatus !== 'arrived' || phase !== 'nav') return
    navRef.current.hold = false
    const isLast = leg >= targets.length - 1
    const msg = isLast
      ? `${formatStep(steps[steps.length - 1], lang)}. ${L.tripDone}.`
      : `${formatStep(steps[steps.length - 1], lang)}. ${lang === 'hi' ? `${L.stop} ${leg + 1} ${L.of} ${targets.length}` : `${L.stop} ${leg + 1} ${L.of} ${targets.length}`}.`
    say(msg)
    if (target) patchToken(tokenId, { lastNode: target })
  }, [navStatus]) // eslint-disable-line react-hooks/exhaustive-deps

  // Progress polling: distance to the next action, ETA and the "in 8 metres" prompt.
  useEffect(() => {
    const id = setInterval(() => {
      const n = navRef.current
      setProg({ step: n.stepFrac ?? 0, route: n.routeFrac ?? 0 })
    }, 250)
    return () => clearInterval(id)
  }, [])
  useEffect(() => {
    if (navStatus !== 'running' || !cur || !next || cur.kind !== 'walk' || cur.dist < 14) return
    const left = cur.dist * (1 - prog.step)
    if (left <= 8 && aheadSaid.current !== stepIndex) {
      aheadSaid.current = stepIndex
      const nt = lowerFirst(formatStep(next, lang), lang)
      say(lang === 'hi' ? `8 मीटर बाद, ${nt}` : `In 8 metres, ${nt}`)
    }
  }, [prog.step]) // eslint-disable-line react-hooks/exhaustive-deps

  // Strap telemetry to the Help Desk
  const report = useCallback(
    (force = false) => {
      if (!t) return
      const now = Date.now()
      const dt = prevTm.current ? (now - prevTm.current.ts) / 1000 : 0
      const tm = navRef.current.pos.lengthSq() > 0 && route?.ok ? telemetryFromScene(navRef.current.pos, gapRef.current, prevTm.current, dt) : telemetryAtNode(plan.origin)
      prevTm.current = tm
      setLive(tm)
      if (force || now - lastWrite.current > 2400) {
        lastWrite.current = now
        const step = route?.ok ? route.instructions[stepIndex] : null
        const node = step && route ? route.nodeIds[Math.min(step.i0, route.nodeIds.length - 1)] : plan.origin
        const base = { nav: phase === 'plan' ? 'idle' : navStatus, step: stepIndex, lastNode: node && !inTransit(node) ? node : plan.origin }
        // Plausibility check before the reading is accepted by the Help Desk
        const v = validateTelemetry(lastSent.current, tm)
        if (v.ok || !lastSent.current) {
          lastSent.current = tm
          patchToken(tokenId, { ...base, telemetry: tm })
        } else {
          lastSent.current = null // resynchronise on the next reading
          patchToken(tokenId, { ...base, telemetryRejected: { issues: v.issues, ts: now } })
        }
      }
    },
    [t, tokenId, navStatus, stepIndex, route, plan.origin, phase],
  )
  const reportRef = useRef(report)
  useEffect(() => {
    reportRef.current = report
  }, [report])
  useEffect(() => {
    const id = setInterval(() => reportRef.current(false), 1200)
    return () => clearInterval(id)
  }, [])
  useEffect(() => {
    const id = setTimeout(() => reportRef.current(true), 300)
    return () => clearTimeout(id)
  }, [navStatus])

  // SOS pauses guidance
  useEffect(() => {
    if (t?.sos?.active && navStatus === 'running') setNavStatus('paused')
  }, [t?.sos?.active]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!note) return
    const id = setTimeout(() => setNote(null), 6000)
    return () => clearTimeout(id)
  }, [note])

  if (tState === 'missing' || tState === 'closed') {
    return (
      <div className="h-full grid place-items-center bg-canvas px-4">
        <div className="panel p-6 max-w-sm text-center">
          <div className="font-semibold text-ink">{L.closed}</div>
          <p className="text-[13px] text-body mt-1">{L.closedSub}</p>
          <button type="button" className="btn mt-4" onClick={onLogout}>
            {L.back}
          </button>
        </div>
      </div>
    )
  }

  const expired = tState === 'expired'
  const color = route?.kind === 'alternative' ? '#2563eb' : '#16a34a'
  const closures = closureList(fac)
  const ManIcon = ICON[maneuverOf(cur)] ?? ArrowUp
  const NextIcon = next ? ICON[maneuverOf(next)] ?? ArrowUp : null
  const running = navStatus !== 'idle'
  const stepLeft = cur?.dist ? Math.max(0, Math.round(cur.dist * (1 - (running ? prog.step : 0)))) : 0
  const routeLeft = route?.ok ? Math.max(0, Math.round(route.distance * (1 - (running ? prog.route : 0)))) : 0
  const timeLeft = route?.ok ? Math.round((route.timeSec * (1 - (running ? prog.route : 0))) / speedMul) : 0
  const eta = new Date(Date.now() + timeLeft * 1000).toLocaleTimeString(lang === 'hi' ? 'hi-IN' : 'en-IN', { hour: '2-digit', minute: '2-digit' })
  const fl = (l) => (lang === 'hi' ? floorNameHi(l) : floorName(l))
  const hiMissing = lang === 'hi' && voiceOn && voiceSupported() && voiceReady && !hasVoice('hi')
  const isLastLeg = leg >= targets.length - 1
  const legLabel = (i) => (targets[i] === 'HD' && i === targets.length - 1 && t.returnToDesk ? L.returnDesk : nodeLabel(targets[i], lang))
  const doneAll = phase === 'nav' && navStatus === 'arrived' && isLastLeg

  // Facilities on the current route, used to pre-select what a report refers to.
  const reportHints = (() => {
    if (!route?.ok) return {}
    const rest = route.edges.slice(cur?.i0 ?? 0)
    return {
      ramp: rest.find((e) => e.type === 'ramp')?.ramp,
      lift: rest.find((e) => e.type === 'elevator')?.elev,
      corridor: rest.find((e) => e.type === 'corridor')?.segment,
      steps: undefined,
    }
  })()

  // Strap sensor events (simulated): each runs the same detector the firmware would run.
  const simulate = async (kind) => {
    const tm = live ?? telemetryAtNode(plan.origin)
    const base = { source: 'strap', token: t.token, strapId: t.strapId, telemetry: tm, ts: Date.now(), status: 'pending' }
    if (kind === 'impact') return setFallSignal((n) => n + 1)
    if (kind === 'ramp') {
      const samples = Array.from({ length: 12 }, () => 6.3 + Math.random() * 0.6)
      const r = detectSteepRamp(samples)
      const target = route?.ok ? route.edges.find((e) => e.type === 'ramp')?.ramp ?? nearestTarget('ramp', tm) : nearestTarget('ramp', tm)
      if (r.steep) await saveReport({ ...base, category: 'ramp', target, confidence: SOURCE_CONFIDENCE.strap, evidence: { kind: 'steep-ramp', ...r } })
      return setNote(`${L.flagged}: ${targetLabel('ramp', target, lang)} (${r.meanDeg}° > ${r.limitDeg}°)`)
    }
    if (kind === 'lift') {
      const r = detectLiftStall(200, 0.02)
      const target = route?.elevatorsUsed?.[0] ?? nearestTarget('lift', tm)
      if (r.stalled) await saveReport({ ...base, category: 'lift', target, confidence: SOURCE_CONFIDENCE.strap, evidence: { kind: 'lift-stall', ...r } })
      return setNote(`${L.flagged}: ${targetLabel('lift', target, lang)}`)
    }
    if (kind === 'turn') {
      const seg = route?.ok ? route.edges.find((e) => e.type === 'corridor' && e.level > 0)?.segment ?? nearestTarget('corridor', tm) : nearestTarget('corridor', tm)
      await saveReport({ ...base, category: 'corridor', target: seg, confidence: 0.45, evidence: { kind: 'turn-back', straps: 1 } })
      return setNote(`${L.flagged}: ${targetLabel('corridor', seg, lang)}`)
    }
    if (kind === 'bad') {
      const bad = { ...tm, pressure: 1203.4, relHeight: tm.relHeight + 28, ts: Date.now() }
      const v = validateTelemetry(lastSent.current ?? tm, bad)
      patchToken(tokenId, { telemetryRejected: { issues: v.issues, ts: Date.now() } })
      return setNote(`${L.rejected}: ${v.issues.join(', ')}`)
    }
  }

  const saveTrip = (startNow) => {
    const done = stops.slice(0, leg)
    const newStops = [...done, ...draft]
    patchToken(tokenId, { stops: newStops, leg: done.length, mode, returnToDesk })
    setPhase('nav')
    setTab('steps')
    resetLeg(plan.origin)
    if (startNow) setTimeout(() => setNavStatus('running'), 400)
  }
  const optimise = () => setDraft(orderStops(plan.origin, draft, fac, profileFor(mode), returnToDesk ? 'HD' : null))
  const startOrResume = () => {
    if (!route?.ok || expired) return
    setNavStatus('running')
  }
  const continueNext = () => {
    const origin = target
    patchToken(tokenId, { leg: leg + 1, lastNode: origin })
    resetLeg(origin)
    setTimeout(() => setNavStatus('running'), 500)
  }
  const planMore = () => {
    patchToken(tokenId, { stops: [], leg: 0, lastNode: plan.origin })
    setDraft([])
    setPhase('plan')
    resetLeg(plan.origin)
  }

  return (
    <div className="h-full flex flex-col bg-canvas">
      <header className="h-14 shrink-0 flex items-center gap-3 px-4 border-b border-line bg-surface">
        <Brand sub={lang === 'hi' ? 'आगंतुक नेविगेशन · जीएल बजाज' : 'Visitor navigation · GL BAJAJ'} />
        <span className="hidden lg:inline-flex items-center gap-2 h-8 px-3 rounded-lg bg-subtle text-[12.5px] text-body">
          <span className="tabular font-semibold text-ink">{t.strapId}</span> · <span className="tabular">{t.token}</span> · {L.validUntil}{' '}
          <span className="tabular">{new Date(t.validUntil).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
        </span>
        <div className="ml-auto flex items-center gap-2">
          <div className="lang-toggle flex p-0.5 rounded-lg border border-line bg-surface" role="group" aria-label="Language">
            <button type="button" aria-pressed={lang === 'en'} onClick={() => setLang('en')} className="focus-ring h-7 px-2.5 rounded-md text-[12.5px] font-medium text-body">
              English
            </button>
            <button type="button" aria-pressed={lang === 'hi'} onClick={() => setLang('hi')} className="focus-ring h-7 px-2.5 rounded-md text-[12.5px] font-medium text-body">
              हिन्दी
            </button>
          </div>
          <button
            type="button"
            className={`btn !h-8 !px-2.5 ${voiceOn ? '!border-brand !text-brand' : ''}`}
            onClick={() => {
              if (voiceOn) stopSpeaking()
              setVoiceOn(!voiceOn)
            }}
            disabled={!voiceSupported()}
            aria-pressed={voiceOn}
            title={voiceOn ? `Voice on: ${voiceInfo(lang) ?? 'default voice'}` : 'Voice off'}
          >
            {voiceOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">{lang === 'hi' ? 'आवाज़' : 'Voice'}</span>
          </button>
          <button type="button" className="btn !h-8 !px-2.5 hidden md:inline-flex" onClick={() => speak(L.testLine, lang, { interrupt: true })} disabled={!voiceSupported()} title={voiceInfo(lang) ?? ''}>
            {L.testVoice}
          </button>
          <SyncBadge />
          <button type="button" className="btn !h-8" onClick={onLogout}>
            <LogOut className="w-4 h-4" /> {L.exit}
          </button>
        </div>
      </header>

      <main className="relative flex-1 min-h-0">
        <SceneView
          gapRef={gapRef}
          facilities={fac}
          route={route}
          startId={plan.origin}
          destId={phase === 'plan' ? draft[0] : target}
          navRef={navRef}
          navStatus={phase === 'plan' ? 'idle' : navStatus}
          setNavStatus={setNavStatus}
          progressRef={progressRef}
          setStepIndex={setStepIndex}
          stepIndex={stepIndex}
          rightInset={PANEL_W + 24}
          follow={follow && navStatus === 'running'}
          activeLevel={follow && navStatus === 'running' && live?.level !== undefined ? live.level : undefined}
          lang={lang}
          hideFloorPills={phase === 'nav'}
        />

        {/* Guidance card */}
        {phase === 'nav' && (
          <div className="absolute left-4 top-4 z-20" style={{ width: `min(460px, calc(100% - ${PANEL_W + 56}px))` }}>
            {doneAll ? (
              <div className="guide-card p-4" role="status">
                <div className="flex items-center gap-3">
                  <CircleCheck className="w-12 h-12 shrink-0" />
                  <div>
                    <div className="text-[20px] font-semibold">{L.tripDone}</div>
                    <div className="text-[13px] opacity-90">{L.tripDoneSub}</div>
                  </div>
                </div>
                <button type="button" className="mt-3 btn !bg-white !text-brand !border-white" onClick={planMore}>
                  <MapPinned className="w-4 h-4" /> {L.planMore}
                </button>
              </div>
            ) : navStatus === 'arrived' ? (
              <div className="guide-card p-4" role="status">
                <div className="flex items-center gap-3">
                  <Flag className="w-12 h-12 shrink-0" />
                  <div>
                    <div className="text-[13px] opacity-90">
                      {L.arrivedAt} {leg + 1} {L.of} {targets.length}
                    </div>
                    <div className="text-[19px] font-semibold leading-snug">{legLabel(leg)}</div>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button type="button" className="btn !bg-white !text-brand !border-white !h-10" onClick={continueNext}>
                    <Play className="w-4 h-4" /> {L.continue}: {legLabel(leg + 1)}
                  </button>
                </div>
              </div>
            ) : route?.ok ? (
              <div className={`guide-card overflow-hidden ${route.kind === 'alternative' ? 'alt' : ''}`} role="status" aria-live="polite">
                <div className="px-4 pt-3 text-[12px] opacity-85">
                  {L.stop} {leg + 1} {L.of} {targets.length} · {legLabel(leg)}
                </div>
                <div className="flex items-center gap-4 px-4 pb-4 pt-2">
                  <ManIcon className="w-16 h-16 shrink-0" strokeWidth={2.4} aria-hidden />
                  <div className="min-w-0">
                    {(cur?.kind === 'walk' || cur?.kind === 'ramp') && cur.dist > 0 && <div className="tabular text-[30px] leading-none font-semibold">{stepLeft} {lang === 'hi' ? 'मी' : 'm'}</div>}
                    <div className="text-[16px] leading-snug font-medium mt-1">{formatStep(cur, lang)}</div>
                  </div>
                </div>
                {next && (
                  <div className="guide-next flex items-center gap-2 px-4 py-2 text-[13px]">
                    <span className="opacity-80">{L.then}</span>
                    {NextIcon && <NextIcon className="w-4 h-4 shrink-0" />}
                    <span className="truncate">{formatStep(next, lang)}</span>
                  </div>
                )}
                {navStatus === 'idle' && <div className="px-4 pb-3 text-[12.5px] opacity-85">{L.pressStart}</div>}
              </div>
            ) : (
              <div className="guide-card bad p-4 flex gap-3" role="alert">
                <CircleAlert className="w-8 h-8 shrink-0" />
                <div>
                  <div className="font-semibold">{L.none}</div>
                  <div className="text-[13px] opacity-90 mt-0.5">{lang === 'hi' ? route?.messageHi : route?.message}</div>
                </div>
              </div>
            )}
            {hiMissing && <div className="mt-2 panel px-3 py-2 text-[12px] text-body">{L.noHindi}</div>}
            <AnimatePresence>
              {toast && (
                <motion.div
                  key={toastText}
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  role="status"
                  aria-live="assertive"
                  className={`mt-2 panel px-4 py-2.5 text-[13px] text-ink border-l-4 ${toast.tone === 'bad' ? '!border-l-bad' : toast.tone === 'alt' ? '!border-l-alt' : '!border-l-ok'}`}
                >
                  {toastText}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* Trip bar */}
        {phase === 'nav' && route?.ok && navStatus !== 'arrived' && (
          <div className="absolute bottom-16 z-20 flex justify-center pointer-events-none" style={{ left: 16, right: PANEL_W + 40 }}>
            <div className="panel pointer-events-auto flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
              <div className="leading-tight min-w-[120px]">
                <div className="tabular text-[20px] font-semibold" style={{ color }}>
                  {formatTime(timeLeft, lang)}
                </div>
                <div className="text-[12px] text-muted tabular">
                  {routeLeft} {lang === 'hi' ? 'मीटर' : 'm'} {L.remaining} · {L.arrive} {eta}
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <button type="button" className="btn btn-primary !h-10 !px-4" onClick={startOrResume} disabled={navStatus === 'running' || expired}>
                  <Play className="w-4 h-4" /> {navStatus === 'paused' ? L.resume : L.start}
                </button>
                <button type="button" className="btn !h-10" onClick={() => setNavStatus('paused')} disabled={navStatus !== 'running'}>
                  <Pause className="w-4 h-4" /> {L.pause}
                </button>
                <button type="button" className="btn !h-10" onClick={() => resetLeg(plan.origin)} title="Restart this leg" aria-label="Restart this leg">
                  <RotateCcw className="w-4 h-4" />
                </button>
                <button type="button" className={`btn !h-10 ${follow ? '!border-brand !text-brand' : ''}`} onClick={() => setFollow(!follow)} aria-pressed={follow} title={L.follow}>
                  <LocateFixed className="w-4 h-4" /> <span className="hidden xl:inline">{L.follow}</span>
                </button>
                <button type="button" className="btn !h-10" onClick={() => cur && speak(formatStep(cur, lang), lang, { interrupt: true })} disabled={!voiceSupported()} title={L.repeat} aria-label={L.repeat}>
                  <Repeat2 className="w-4 h-4" />
                </button>
                <div className="flex items-center gap-0.5 p-0.5 rounded-lg border border-line" role="group" aria-label={L.pace} title={L.pace}>
                  <Gauge className="w-4 h-4 text-muted mx-1" />
                  {[1, 2, 4].map((m) => (
                    <button key={m} type="button" aria-pressed={speedMul === m} onClick={() => setSpeedMul(m)} className={`focus-ring h-8 px-2 rounded-md text-[12px] tabular ${speedMul === m ? 'bg-ink text-white' : 'text-body hover:bg-subtle'}`}>
                      {m}×
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {expired && (
          <div className="absolute inset-x-0 top-0 z-30 flex justify-center pt-4 pointer-events-none">
            <div className="panel pointer-events-auto px-5 py-3 border-warn/50 bg-warn/10 text-center">
              <div className="font-semibold text-ink">{L.expired}</div>
              <div className="text-[12.5px] text-body">{L.expiredSub}</div>
            </div>
          </div>
        )}

        <aside className="panel absolute right-4 top-4 bottom-4 z-20 flex flex-col overflow-hidden" style={{ width: PANEL_W }} aria-label="Navigation">
          <div className="p-4 border-b border-line">
            <SosControl token={t} lang={lang} liveTelemetry={live} voiceOn={voiceOn} fallSignal={fallSignal} />
            <ReportBarrier token={t} lang={lang} telemetry={live} hints={reportHints} onSent={(m) => setNote(m)} />
            {note && (
              <div className="mt-2 rounded-lg bg-subtle px-3 py-2 text-[12px] text-body" role="status">
                {note}
              </div>
            )}
          </div>

          {phase === 'plan' ? (
            <div className="flex-1 overflow-auto scroll-thin p-5">
              <h2 className="text-[18px] font-semibold text-ink">{L.plan}</h2>
              <p className="text-[12.5px] text-muted mb-4">{L.planSub}</p>
              <TripPlanner
                lang={lang}
                stops={draft}
                setStops={setDraft}
                mode={mode}
                setMode={setMode}
                returnToDesk={returnToDesk}
                setReturnToDesk={setReturnToDesk}
                onOptimise={optimise}
                onStart={() => saveTrip(true)}
                startLabel={stops.length ? L.updateTrip : L.startTrip}
              />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 px-4 pt-3 gap-1" role="tablist">
                {[
                  ['steps', L.steps, ListChecks],
                  ['trip', L.trip, MapPinned],
                ].map(([k, label, Icon]) => (
                  <button
                    key={k}
                    type="button"
                    role="tab"
                    aria-selected={tab === k}
                    onClick={() => {
                      setTab(k)
                      if (k === 'trip') setDraft(stops.slice(leg))
                    }}
                    className={`focus-ring h-9 rounded-lg text-[13px] font-medium inline-flex items-center justify-center gap-1.5 ${tab === k ? 'bg-subtle text-ink' : 'text-muted hover:text-ink'}`}
                  >
                    <Icon className="w-4 h-4" /> {label}
                  </button>
                ))}
              </div>
              <div className="flex-1 overflow-auto scroll-thin p-5 flex flex-col gap-5">
                {tab === 'trip' ? (
                  <TripPlanner
                    lang={lang}
                    stops={draft}
                    setStops={setDraft}
                    mode={mode}
                    setMode={setMode}
                    returnToDesk={returnToDesk}
                    setReturnToDesk={setReturnToDesk}
                    onOptimise={optimise}
                    onStart={() => saveTrip(false)}
                    startLabel={L.updateTrip}
                    compact
                  />
                ) : (
                  <>
                    <section>
                      <div className="label mb-2">{L.trip}</div>
                      <ol className="flex flex-col gap-1">
                        {targets.map((id, i) => (
                          <li key={`${id}-${i}`} className={`flex items-center gap-2 text-[12.5px] ${i < leg ? 'text-muted line-through' : i === leg ? 'text-ink font-medium' : 'text-body'}`}>
                            <span className={`w-5 h-5 rounded-full grid place-items-center text-[10px] tabular text-white shrink-0 ${i < leg ? 'bg-muted' : i === leg ? 'bg-brand' : 'bg-line-strong'}`}>{i + 1}</span>
                            <span className="truncate">{legLabel(i)}</span>
                            {roomById[id] && <span className="text-muted text-[11.5px] shrink-0">· {fl(roomById[id].level)}</span>}
                          </li>
                        ))}
                      </ol>
                    </section>

                    {route?.ok && (
                      <section className="rounded-xl px-4 py-3" style={{ background: `${color}12`, border: `1px solid ${color}40` }}>
                        <div className="flex items-center justify-between">
                          <span className="text-[13px] font-semibold" style={{ color }}>
                            {route.kind === 'alternative' ? L.alt : L.route}
                          </span>
                          <span className="text-[12px] text-body tabular">
                            {route.distance} {lang === 'hi' ? 'मी' : 'm'} · {formatTime(route.timeSec, lang)}
                          </span>
                        </div>
                        <div className="text-[12px] text-body mt-1">
                          {route.liftLabels.length ? `${L.uses} ${route.liftLabels.join(', ')}` : L.noLift}
                          {route.reasons.length > 0 && (
                            <div className="mt-0.5">
                              {L.avoids}: {route.reasons.map((r) => r[lang]).join('; ')}
                            </div>
                          )}
                        </div>
                      </section>
                    )}

                    {(closures.length > 0 || fac.notice) && (
                      <section className="flex flex-col gap-1.5">
                        <div className="label">{L.notices}</div>
                        {fac.notice && <div className="text-[12.5px] text-ink bg-warn/10 rounded-lg px-3 py-2">{fac.notice}</div>}
                        {closures.map((c) => (
                          <div key={c.en} className="flex items-center gap-2 text-[12.5px] text-body">
                            <span className="w-1.5 h-1.5 rounded-full bg-bad shrink-0" /> {c[lang]}
                          </div>
                        ))}
                      </section>
                    )}

                    {route?.ok && (
                      <section>
                        <div className="label mb-2">{L.steps}</div>
                        <ol className="flex flex-col gap-1">
                          {steps.map((s, i) => {
                            const Icon = ICON[maneuverOf(s)] ?? ArrowUp
                            const isCur = i === stepIndex
                            return (
                              <li key={i} className={`flex gap-2.5 items-start rounded-lg px-2 py-1.5 ${isCur ? 'bg-subtle' : ''} ${running && i < stepIndex ? 'opacity-45' : ''}`} aria-current={isCur ? 'step' : undefined}>
                                <span className="w-6 h-6 shrink-0 rounded-md grid place-items-center text-white" style={{ background: s.warn ? '#ca8a04' : color }}>
                                  <Icon className="w-3.5 h-3.5" />
                                </span>
                                <span className="text-[12.5px] leading-snug text-body pt-0.5">{formatStep(s, lang)}</span>
                              </li>
                            )
                          })}
                        </ol>
                      </section>
                    )}

                    <section>
                      <div className="label mb-2">{L.readings}</div>
                      <dl className="grid grid-cols-3 gap-x-3 gap-y-2.5 text-[12px]">
                        {[
                          [L.floor, live ? fl(live.level) : '-'],
                          [L.height, live ? `${live.relHeight.toFixed(1)} m` : '-'],
                          [L.pressure, live ? `${live.pressure} hPa` : '-'],
                          [L.position, live ? `${live.x.toFixed(1)}, ${live.z.toFixed(1)}` : '-'],
                          [L.heading, live ? `${live.heading}° ${compass(live.heading)}` : '-'],
                          [L.speed, live ? `${live.speed.toFixed(1)} m/s` : '-'],
                        ].map(([k, v]) => (
                          <div key={k} className="min-w-0">
                            <dt className="text-muted">{k}</dt>
                            <dd className="tabular text-ink truncate">{v}</dd>
                          </div>
                        ))}
                      </dl>
                      <p className="text-[11px] text-muted mt-2">
                        {L.sent} {t.strapId}
                      </p>
                      <div className="mt-3 rounded-lg border border-dashed border-line p-3">
                        <div className="text-[11px] font-semibold uppercase tracking-wide text-muted mb-2">{L.simTitle}</div>
                        <div className="grid grid-cols-2 gap-1.5">
                          {[
                            ['impact', L.simImpact],
                            ['ramp', L.simRamp],
                            ['lift', L.simLift],
                            ['turn', L.simTurn],
                            ['bad', L.simBad],
                          ].map(([k, label]) => (
                            <button key={k} type="button" onClick={() => simulate(k)} className="focus-ring text-left px-2 py-1.5 rounded-md text-[11.5px] border border-line hover:bg-subtle text-body inline-flex items-center gap-1.5">
                              <Zap className={`w-3.5 h-3.5 shrink-0 ${k === 'impact' ? 'text-bad' : 'text-alt'}`} /> {label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </section>
                  </>
                )}
              </div>
            </>
          )}
        </aside>
      </main>
    </div>
  )
}
