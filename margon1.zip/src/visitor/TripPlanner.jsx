import { useMemo, useState } from 'react'
import { ArrowDown, ArrowUp, Plus, Route as RouteIcon, Search, Shuffle, X } from 'lucide-react'
import { BUILDINGS, floorName, floorNameHi } from '../data/buildingData'
import { DESTINATIONS, ROOM_TYPES, roomById } from '../data/roomData'
import { PREFERENCES, nodeLabel } from '../data/routeData'

const QUICK = ['admission', 'exam', 'hod', 'seminar', 'lab', 'washroom']

/** Visitor chooses stops, their order and the route preference. */
export default function TripPlanner({ lang, stops, setStops, mode, setMode, returnToDesk, setReturnToDesk, onOptimise, onStart, startLabel, compact = false }) {
  const [q, setQ] = useState('')
  const [block, setBlock] = useState('all')
  const hi = lang === 'hi'
  const results = useMemo(() => {
    const s = q.trim().toLowerCase()
    return DESTINATIONS.filter((r) => (block === 'all' || r.building === block) && !stops.includes(r.id)).filter((r) => {
      if (!s) return true
      return (
        r.name.toLowerCase().includes(s) ||
        r.nameHi.includes(q.trim()) ||
        (r.number ?? '').includes(s) ||
        ROOM_TYPES[r.type].label.toLowerCase().includes(s) ||
        r.dept.toLowerCase().includes(s)
      )
    })
  }, [q, block, stops])
  const move = (i, d) => {
    const a = [...stops]
    const j = i + d
    if (j < 0 || j >= a.length) return
    ;[a[i], a[j]] = [a[j], a[i]]
    setStops(a)
  }
  const where = (id) => {
    const r = roomById[id]
    if (!r) return ''
    const b = BUILDINGS.find((x) => x.id === r.building)
    return `${hi ? floorNameHi(r.level) : floorName(r.level)} · ${hi ? b.nameHi : b.short}`
  }

  return (
    <div className="flex flex-col gap-4">
      <section>
        <div className="label mb-2">{hi ? 'मार्ग पसंद' : 'Route preference'}</div>
        <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Route preference">
          {PREFERENCES.map((p) => (
            <button
              key={p.id}
              type="button"
              role="radio"
              aria-checked={mode === p.id}
              onClick={() => setMode(p.id)}
              className={`focus-ring text-left rounded-xl border px-3 py-2.5 transition-colors ${mode === p.id ? 'border-brand bg-brand/5' : 'border-line hover:bg-subtle'}`}
            >
              <div className={`text-[13.5px] font-semibold ${mode === p.id ? 'text-brand' : 'text-ink'}`}>{hi ? p.hi : p.en}</div>
              <div className="text-[11.5px] text-muted">{hi ? p.hiSub : p.enSub}</div>
            </button>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-2">
          <div className="label">{hi ? 'आपके गंतव्य' : 'Your stops'}</div>
          {stops.length > 1 && (
            <button type="button" className="focus-ring inline-flex items-center gap-1 text-[12px] text-brand hover:underline" onClick={onOptimise}>
              <Shuffle className="w-3.5 h-3.5" /> {hi ? 'सबसे छोटा क्रम' : 'Shortest order'}
            </button>
          )}
        </div>
        {stops.length === 0 ? (
          <p className="text-[12.5px] text-muted rounded-lg border border-dashed border-line px-3 py-3">{hi ? 'नीचे से एक या अधिक स्थान जोड़ें।' : 'Add one or more places from the list below.'}</p>
        ) : (
          <ol className="flex flex-col gap-1.5">
            {stops.map((id, i) => (
              <li key={id} className="flex items-center gap-2 rounded-lg border border-line px-2.5 py-2 bg-surface">
                <span className="w-6 h-6 rounded-full bg-brand text-white text-[11px] font-semibold grid place-items-center tabular shrink-0">{i + 1}</span>
                <span className="flex-1 min-w-0">
                  <span className="block text-[13px] text-ink truncate">{nodeLabel(id, lang)}</span>
                  <span className="block text-[11.5px] text-muted truncate">{where(id)}</span>
                </span>
                <button type="button" className="focus-ring w-7 h-7 grid place-items-center rounded-md text-muted hover:bg-subtle disabled:opacity-30" disabled={i === 0} onClick={() => move(i, -1)} aria-label="Move up">
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button type="button" className="focus-ring w-7 h-7 grid place-items-center rounded-md text-muted hover:bg-subtle disabled:opacity-30" disabled={i === stops.length - 1} onClick={() => move(i, 1)} aria-label="Move down">
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
                <button type="button" className="focus-ring w-7 h-7 grid place-items-center rounded-md text-muted hover:bg-bad/10 hover:text-bad" onClick={() => setStops(stops.filter((s) => s !== id))} aria-label="Remove stop">
                  <X className="w-3.5 h-3.5" />
                </button>
              </li>
            ))}
          </ol>
        )}
        <label className="mt-2 flex items-center gap-2 text-[12.5px] text-body cursor-pointer">
          <input type="checkbox" checked={returnToDesk} onChange={(e) => setReturnToDesk(e.target.checked)} />
          {hi ? 'अंत में सहायता डेस्क पर लौटें (स्ट्रैप लौटाने के लिए)' : 'Return to the Help Desk at the end (to hand back the strap)'}
        </label>
      </section>

      <section className="flex flex-col gap-2">
        <div className="label">{hi ? 'स्थान जोड़ें' : 'Add a place'}</div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted pointer-events-none" />
          <input className="field !pl-9" placeholder={hi ? 'कमरा नंबर या नाम, जैसे 402, परीक्षा' : 'Room number or name, e.g. 402, exam'} value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search places" />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {[{ id: 'all', en: 'Both blocks', hi: 'दोनों ब्लॉक' }, ...BUILDINGS.map((b) => ({ id: b.id, en: b.short, hi: b.nameHi }))].map((b) => (
            <button key={b.id} type="button" onClick={() => setBlock(b.id)} className={`focus-ring h-7 px-2.5 rounded-full text-[12px] border ${block === b.id ? 'bg-ink text-white border-ink' : 'border-line text-body hover:bg-subtle'}`}>
              {hi ? b.hi : b.en}
            </button>
          ))}
          {!q &&
            QUICK.map((t) => (
              <button key={t} type="button" onClick={() => setQ(ROOM_TYPES[t].label.split(' ')[0])} className="focus-ring h-7 px-2.5 rounded-full text-[12px] border border-line text-body hover:bg-subtle">
                {hi ? ROOM_TYPES[t].labelHi : ROOM_TYPES[t].label}
              </button>
            ))}
        </div>
        <ul className={`${compact ? 'max-h-44' : 'max-h-64'} overflow-auto scroll-thin flex flex-col gap-0.5 pr-1`} aria-label="Places">
          {results.slice(0, 60).map((r) => (
            <li key={r.id}>
              <button type="button" onClick={() => setStops([...stops, r.id])} className="focus-ring w-full flex items-center gap-2.5 px-2 py-1.5 rounded-lg text-left hover:bg-subtle">
                <span className="w-2 h-2 rounded-full shrink-0" style={{ background: ROOM_TYPES[r.type].color }} />
                <span className="flex-1 min-w-0">
                  <span className="block text-[13px] text-ink truncate">{hi ? r.nameHi : r.name}</span>
                  <span className="block text-[11.5px] text-muted truncate">{where(r.id)}</span>
                </span>
                <Plus className="w-4 h-4 text-brand shrink-0" />
              </button>
            </li>
          ))}
          {results.length === 0 && <li className="px-2 py-3 text-[12.5px] text-muted">{hi ? 'कोई स्थान नहीं मिला।' : 'No place matches.'}</li>}
        </ul>
      </section>

      {onStart && (
        <button type="button" className="btn btn-primary !h-12 !text-[15px]" disabled={stops.length === 0} onClick={onStart}>
          <RouteIcon className="w-4 h-4" /> {startLabel}
        </button>
      )}
    </div>
  )
}
