import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { HeartPulse, LifeBuoy, ShieldAlert, Siren, X } from 'lucide-react'
import { patchToken } from '../data/store'
import { speak } from '../data/voice'

const TXT = {
  en: {
    sos: 'SOS',
    title: 'Send an alert to the Help Desk',
    accident: 'Accident',
    medical: 'Medical help',
    assist: 'Need assistance',
    cancel: 'Cancel',
    sent: 'Help Desk alerted',
    sentSub: 'Stay where you are. Your location is shared.',
    ack: 'Help is on the way',
    ackSub: 'The Help Desk has seen your alert.',
    cancelSos: 'I am safe, cancel alert',
    fall: 'Fall detected by your strap',
    fallSub: 'An SOS will be sent automatically in',
    ok: 'I am OK',
    say: 'Help Desk alerted. Stay where you are.',
    sayAck: 'Help is on the way.',
    sayFall: 'Fall detected. If you are OK, press I am OK.',
  },
  hi: {
    sos: 'SOS',
    title: 'सहायता डेस्क को अलर्ट भेजें',
    accident: 'दुर्घटना',
    medical: 'चिकित्सा सहायता',
    assist: 'सहायता चाहिए',
    cancel: 'रद्द करें',
    sent: 'सहायता डेस्क को सूचित किया गया',
    sentSub: 'जहाँ हैं वहीं रहें। आपकी स्थिति साझा की गई है।',
    ack: 'सहायता आ रही है',
    ackSub: 'सहायता डेस्क ने आपका अलर्ट देख लिया है।',
    cancelSos: 'मैं सुरक्षित हूँ, अलर्ट रद्द करें',
    fall: 'आपके स्ट्रैप ने गिरने का पता लगाया',
    fallSub: 'अपने आप SOS भेजा जाएगा',
    ok: 'मैं ठीक हूँ',
    say: 'सहायता डेस्क को सूचित कर दिया गया है। जहाँ हैं वहीं रहें।',
    sayAck: 'सहायता आ रही है।',
    sayFall: 'गिरने का पता चला है। अगर आप ठीक हैं तो मैं ठीक हूँ दबाएँ।',
  },
}

/**
 * SOS: manual alert (accident, medical, assistance) and automatic alert after the strap's
 * motion sensor reports an impact, with a 10-second cancel window.
 */
export default function SosControl({ token, lang, liveTelemetry, voiceOn, fallSignal, onSosChange }) {
  const L = TXT[lang]
  const [sheet, setSheet] = useState(false)
  const [countdown, setCountdown] = useState(null)
  const sos = token.sos?.active ? token.sos : null
  const lastAck = useRef(false)

  const send = (type, by = 'visitor') => {
    setSheet(false)
    setCountdown(null)
    patchToken(token.token, { sos: { active: true, type, by, ts: Date.now(), ack: false, telemetry: liveTelemetry ?? token.telemetry ?? null } })
    if (voiceOn) speak(L.say, lang, { interrupt: true })
    onSosChange?.(true)
  }
  const cancel = () => {
    patchToken(token.token, { sos: { ...token.sos, active: false, cancelledTs: Date.now() } })
    onSosChange?.(false)
  }

  // Strap impact signal → countdown → automatic SOS
  useEffect(() => {
    if (!fallSignal) return
    setCountdown(10)
    if (voiceOn) speak(L.sayFall, lang, { interrupt: true })
  }, [fallSignal]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (countdown === null) return
    if (countdown <= 0) {
      send('fall', 'strap')
      return
    }
    const id = setTimeout(() => setCountdown((c) => (c === null ? null : c - 1)), 1000)
    return () => clearTimeout(id)
  }, [countdown]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (sos?.ack && !lastAck.current && voiceOn) speak(L.sayAck, lang, { interrupt: true })
    lastAck.current = !!sos?.ack
  }, [sos?.ack]) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      {sos ? (
        <div className={`rounded-xl px-4 py-3 text-white ${sos.ack ? 'bg-[#b45309]' : 'bg-bad'}`} role="status" aria-live="assertive">
          <div className="flex items-center gap-2 font-semibold text-[15px]">
            <Siren className="w-5 h-5" /> {sos.ack ? L.ack : L.sent}
          </div>
          <div className="text-[12.5px] opacity-95 mt-0.5">{sos.ack ? L.ackSub : L.sentSub}</div>
          <button type="button" className="mt-2 btn !h-8 !bg-white/15 !border-white/50 !text-white hover:!bg-white/25" onClick={cancel}>
            {L.cancelSos}
          </button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setSheet(true)}
          className="focus-ring w-full h-14 rounded-xl bg-bad text-white font-bold text-[20px] tracking-[0.18em] flex items-center justify-center gap-3 shadow-lg shadow-red-600/30 hover:bg-[#b91c1c] active:translate-y-px"
          aria-label="SOS, call for help"
        >
          <Siren className="w-6 h-6" /> SOS <span className="text-[13px] font-medium tracking-normal opacity-90">{lang === 'hi' ? 'आपातकाल' : 'Emergency'}</span>
        </button>
      )}

      <AnimatePresence>
        {sheet && (
          <motion.div className="fixed inset-0 z-50 grid place-items-center bg-black/40 px-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSheet(false)}>
            <motion.div className="panel w-full max-w-md p-5" initial={{ y: 30, scale: 0.97 }} animate={{ y: 0, scale: 1 }} exit={{ y: 30 }} onClick={(e) => e.stopPropagation()} role="dialog" aria-label={L.title}>
              <div className="flex items-center justify-between mb-4">
                <div className="font-semibold text-ink text-[16px]">{L.title}</div>
                <button type="button" onClick={() => setSheet(false)} className="focus-ring text-muted hover:text-ink" aria-label={L.cancel}>
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="grid gap-2">
                {[
                  ['accident', ShieldAlert, L.accident],
                  ['medical', HeartPulse, L.medical],
                  ['assist', LifeBuoy, L.assist],
                ].map(([k, Icon, label]) => (
                  <button key={k} type="button" onClick={() => send(k)} className="focus-ring h-14 rounded-xl bg-bad text-white text-[16px] font-semibold flex items-center gap-3 px-4 hover:bg-[#b91c1c]">
                    <Icon className="w-6 h-6" /> {label}
                  </button>
                ))}
                <button type="button" onClick={() => setSheet(false)} className="btn !h-11 mt-1">
                  {L.cancel}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
        {countdown !== null && (
          <motion.div className="fixed inset-0 z-50 grid place-items-center bg-bad/85 px-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} role="alertdialog" aria-label={L.fall}>
            <div className="text-center text-white max-w-sm">
              <Siren className="w-14 h-14 mx-auto animate-pulse" />
              <div className="text-[22px] font-semibold mt-3">{L.fall}</div>
              <div className="text-[14px] opacity-90 mt-1">{L.fallSub}</div>
              <div className="tabular text-[72px] font-bold leading-none my-4">{countdown}</div>
              <button type="button" className="h-14 px-8 rounded-xl bg-white text-bad text-[18px] font-bold" onClick={() => setCountdown(null)}>
                {L.ok}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
