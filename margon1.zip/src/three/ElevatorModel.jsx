import { memo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { Edges, Html } from '@react-three/drei'
import { BUILDING } from '../data/buildingData'
import { C } from './theme'

// One lift shaft and car, in block-local coordinates.
function ElevatorModel({ lift, gap, working, routeTint, navRef, onSelect, selected, reduceMotion, showChip }) {
  const car = useRef()
  const glow = useRef()
  const w = lift.width
  const d = 4
  const bottom = -BUILDING.slabThickness
  const top = 10 * gap + BUILDING.wallHeight + 0.8
  const h = top - bottom
  const color = !working ? C.red : routeTint ?? C.line

  useFrame(({ clock }, dt) => {
    if (car.current) {
      const n = navRef.current
      const target = n.elev === lift.id ? n.pos.y - 0.3 : n.lastElev === lift.id ? n.lastY : 0
      car.current.position.y = THREE.MathUtils.damp(car.current.position.y, target, 8, dt)
    }
    if (glow.current && !reduceMotion && (!working || routeTint)) {
      const k = 0.5 + 0.5 * Math.sin(clock.elapsedTime * (working ? 2 : 4))
      glow.current.opacity = 0.12 + k * 0.1
    }
  })

  const select = (e) => {
    e.stopPropagation()
    onSelect({ kind: 'elevator', id: lift.id })
  }

  return (
    <group position={[lift.lx, 0, lift.carZ]}>
      <mesh
        position={[0, bottom + h / 2, 0]}
        onClick={select}
        onPointerOver={(e) => {
          e.stopPropagation()
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => (document.body.style.cursor = 'auto')}
      >
        <boxGeometry args={[w, h, d]} />
        <meshStandardMaterial ref={glow} color={color} transparent opacity={working && !routeTint ? 0.08 : 0.14} depthWrite={false} side={THREE.DoubleSide} />
        <Edges color={color} transparent opacity={selected ? 1 : 0.8} />
      </mesh>
      <group ref={car}>
        <mesh position={[0, 1.15, 0]} castShadow>
          <boxGeometry args={[w - 0.6, 2.3, 2.0]} />
          <meshStandardMaterial color={working ? '#e2e8ee' : '#fbd5d5'} metalness={0.2} roughness={0.5} />
          <Edges color={color} />
        </mesh>
      </group>
      {lift.serves.map((l) => (
        <mesh key={l} position={[0, l * gap + 1.1, -d / 2 - 0.02]}>
          <planeGeometry args={[w - 0.8, 2.1]} />
          <meshBasicMaterial color={color} transparent opacity={0.35} side={THREE.DoubleSide} />
        </mesh>
      ))}
      {(showChip || !working || routeTint) && (
        <Html position={[0, top + 0.9, 0]} center zIndexRange={[14, 0]}>
          <button
            type="button"
            className={`marker-chip ${working ? (routeTint ? 'chip-route' : 'chip-neutral') : 'chip-red'}`}
            style={working && routeTint ? { '--c': routeTint } : undefined}
            onClick={() => onSelect({ kind: 'elevator', id: lift.id })}
          >
            <span className="chip-badge">{lift.label}</span>
            {working ? 'Lift' : 'Closed'}
          </button>
        </Html>
      )}
    </group>
  )
}

export default memo(ElevatorModel)
