import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { useFrame, useThree } from '@react-three/fiber'
import { OrbitControls } from '@react-three/drei'

export const DEFAULT_TARGET = new THREE.Vector3(0, 25, 4)
export const DEFAULT_POSITION = new THREE.Vector3(118, 108, 190)

const _v = new THREE.Vector3()

/**
 * Orbit controls with eased camera moves. When `follow` is set (navigation running),
 * the camera chases the wheelchair marker like a map app, keeping the user's chosen angle.
 */
export default function CameraControls({ cameraCmd, gap, autoRotate, viewInset, reduceMotion, follow, navRef }) {
  const controls = useRef()
  const { camera, size } = useThree()
  const goal = useRef(null)
  const followOffset = useRef(null)

  useEffect(() => {
    const shift = (viewInset.right - viewInset.left) / 2
    if (Math.abs(shift) < 1) camera.clearViewOffset()
    else camera.setViewOffset(size.width, size.height, shift, 0, size.width, size.height)
    camera.updateProjectionMatrix()
    return () => camera.clearViewOffset()
  }, [camera, size.width, size.height, viewInset.left, viewInset.right])

  useEffect(() => {
    if (!cameraCmd || !controls.current) return
    const c = controls.current
    const target = c.target.clone()
    const offset = camera.position.clone().sub(target)
    const fixedElevation = (t, dist, deg = 38) => {
      const flat = new THREE.Vector3(offset.x, 0, offset.z)
      if (flat.lengthSq() < 1e-4) flat.set(0.5, 0, 1)
      flat.normalize()
      const el = THREE.MathUtils.degToRad(deg)
      return t.clone().add(new THREE.Vector3(flat.x * Math.cos(el), Math.sin(el), flat.z * Math.cos(el)).multiplyScalar(dist))
    }
    switch (cameraCmd.type) {
      case 'reset':
        goal.current = { pos: DEFAULT_POSITION.clone(), target: DEFAULT_TARGET.clone() }
        break
      case 'zoomIn':
        goal.current = { pos: target.clone().add(offset.multiplyScalar(0.72)), target }
        break
      case 'zoomOut':
        goal.current = { pos: target.clone().add(offset.multiplyScalar(1.35)), target }
        break
      case 'focus': {
        const t = new THREE.Vector3(0, cameraCmd.level * gap + 1.2, 4)
        goal.current = { pos: fixedElevation(t, 125), target: t }
        break
      }
      case 'look': {
        const t = new THREE.Vector3(...cameraCmd.point)
        goal.current = { pos: fixedElevation(t, 48, 42), target: t }
        break
      }
      default:
        break
    }
    if (reduceMotion && goal.current) {
      camera.position.copy(goal.current.pos)
      c.target.copy(goal.current.target)
      c.update()
      goal.current = null
    }
  }, [cameraCmd, camera, gap, reduceMotion])

  useEffect(() => {
    const c = controls.current
    if (!c) return
    c.target.copy(DEFAULT_TARGET)
    c.update()
    const cancel = () => (goal.current = null)
    c.addEventListener('start', cancel)
    return () => c.removeEventListener('start', cancel)
  }, [])

  // Entering follow mode: move to a close chase view once, then track the marker.
  useEffect(() => {
    if (!follow || !navRef?.current || !controls.current) {
      followOffset.current = null
      return
    }
    const p = navRef.current.pos
    const t = new THREE.Vector3(p.x, p.y, p.z)
    const off = camera.position.clone().sub(controls.current.target)
    const flat = new THREE.Vector3(off.x, 0, off.z).normalize()
    const el = THREE.MathUtils.degToRad(48)
    followOffset.current = new THREE.Vector3(flat.x * Math.cos(el), Math.sin(el), flat.z * Math.cos(el)).multiplyScalar(40)
    goal.current = { pos: t.clone().add(followOffset.current), target: t, follow: true }
  }, [follow, navRef, camera])

  useFrame((_, dt) => {
    const c = controls.current
    if (!c) return
    const k = 1 - Math.exp(-dt * 4.5)
    if (follow && navRef?.current && followOffset.current) {
      const p = navRef.current.pos
      if (goal.current?.follow) {
        goal.current.target.copy(p)
        goal.current.pos.copy(p).add(followOffset.current)
      } else {
        // keep the user's own orbit angle while tracking the marker
        _v.copy(camera.position).sub(c.target)
        c.target.lerp(p, k)
        camera.position.copy(c.target).add(_v)
        c.update()
        return
      }
    }
    const g = goal.current
    if (!g) return
    camera.position.lerp(g.pos, k)
    c.target.lerp(g.target, k)
    c.update()
    if (camera.position.distanceTo(g.pos) < 0.05 && c.target.distanceTo(g.target) < 0.05) goal.current = null
  })

  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      minDistance={10}
      maxDistance={320}
      maxPolarAngle={Math.PI * 0.495}
      screenSpacePanning
      autoRotate={autoRotate}
      autoRotateSpeed={0.6}
    />
  )
}
