import { memo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import { CORRIDOR, CORRIDOR_SEGMENTS } from '../data/buildingData'
import { C } from './theme'

function Barrier({ x }) {
  return (
    <group position={[x, 0, 0]}>
      {[-1.4, 0, 1.4].map((z) => (
        <mesh key={z} position={[0, 0.45, z]} castShadow>
          <boxGeometry args={[0.12, 0.9, 0.12]} />
          <meshStandardMaterial color={C.red} emissive={C.red} emissiveIntensity={0.6} />
        </mesh>
      ))}
      <mesh position={[0, 0.8, 0]}>
        <boxGeometry args={[0.1, 0.18, 3.2]} />
        <meshStandardMaterial color={C.yellow} emissive={C.yellow} emissiveIntensity={0.5} />
      </mesh>
    </group>
  )
}

function Segment({ seg, blocked, mode, onSelect, reduceMotion }) {
  const mat = useRef()
  const dim = mode === 'dim'
  useFrame(({ clock }) => {
    if (!mat.current || !blocked) return
    const k = reduceMotion ? 0.5 : 0.5 + 0.5 * Math.sin(clock.elapsedTime * 3)
    mat.current.opacity = (dim ? 0.2 : 0.35) + k * 0.25
  })
  const w = seg.x1 - seg.x0 - 0.1
  const cx = (seg.x0 + seg.x1) / 2
  return (
    <group>
      <mesh
        position={[cx, 0.025, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        onClick={(e) => {
          if (dim) return
          e.stopPropagation()
          onSelect({ kind: 'corridor', id: seg.id })
        }}
        onPointerOver={(e) => {
          if (dim) return
          e.stopPropagation()
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => (document.body.style.cursor = 'auto')}
      >
        <planeGeometry args={[w, CORRIDOR.z1 - CORRIDOR.z0 - 0.2]} />
        <meshStandardMaterial
          ref={mat}
          color={blocked ? C.red : C.line}
          emissive={blocked ? C.red : '#000000'}
          emissiveIntensity={blocked ? 0.4 : 0}
          transparent
          opacity={blocked ? 0.45 : dim ? 0.02 : mode === 'active' ? 0.08 : 0.04}
          depthWrite={false}
        />
      </mesh>
      {blocked && (
        <>
          <Barrier x={seg.x0 + 0.4} />
          <Barrier x={seg.x1 - 0.4} />
          {!dim && (
            <Html position={[cx, 1.6, 0]} center zIndexRange={[12, 0]} style={{ pointerEvents: 'none' }}>
              <div className="marker-chip chip-red">Corridor closed</div>
            </Html>
          )}
        </>
      )}
    </group>
  )
}

function CorridorModel({ bid, level, blocked, mode, onSelect, reduceMotion }) {
  return CORRIDOR_SEGMENTS.filter((s) => s.building === bid && s.level === level).map((s) => (
    <Segment key={s.id} seg={s} blocked={blocked.includes(s.id)} mode={mode} onSelect={onSelect} reduceMotion={reduceMotion} />
  ))
}

export default memo(CorridorModel)
