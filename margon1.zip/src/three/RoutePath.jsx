import { memo, useEffect, useLayoutEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { useFrame } from '@react-three/fiber'
import { Line } from '@react-three/drei'
import { GRAPH, nodePosition } from '../data/routeData'
import { C } from './theme'

const LIFT = 0.35
const UP = new THREE.Vector3(0, 1, 0)
const _m = new THREE.Matrix4()
const _q = new THREE.Quaternion()
const _s = new THREE.Vector3()

export function buildPolyline(nodeIds, gap) {
  const pts = nodeIds.map((id) => new THREE.Vector3(...nodePosition(GRAPH.nodes[id], gap, LIFT)))
  const cum = [0]
  for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + pts[i].distanceTo(pts[i - 1]))
  return { pts, cum, total: cum[cum.length - 1] }
}

export function samplePolyline(poly, d, outPos, outDir) {
  const { pts, cum, total } = poly
  const t = Math.max(0, Math.min(total, d))
  let lo = 0
  let hi = cum.length - 1
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1
    if (cum[mid] <= t) lo = mid
    else hi = mid
  }
  const seg = cum[hi] - cum[lo] || 1
  const f = (t - cum[lo]) / seg
  outPos.lerpVectors(pts[lo], pts[hi], f)
  if (outDir) outDir.subVectors(pts[hi], pts[lo]).normalize()
  return lo
}

function Arrows({ poly, reduceMotion }) {
  const ref = useRef()
  const spacing = 2.4
  const count = Math.min(120, Math.max(1, Math.floor(poly.total / spacing)))
  const pos = useMemo(() => new THREE.Vector3(), [])
  const dir = useMemo(() => new THREE.Vector3(), [])
  useFrame(({ clock }) => {
    if (!ref.current) return
    const offset = reduceMotion ? 0 : (clock.elapsedTime * 2.2) % spacing
    for (let i = 0; i < count; i++) {
      const d = i * spacing + offset + 0.6
      if (d > poly.total - 0.3) {
        _s.set(0, 0, 0)
      } else {
        samplePolyline(poly, d, pos, dir)
        _q.setFromUnitVectors(UP, dir)
        _s.set(1, 1, 1)
      }
      _m.compose(pos, _q, _s)
      ref.current.setMatrixAt(i, _m)
    }
    ref.current.instanceMatrix.needsUpdate = true
  })
  return (
    <instancedMesh ref={ref} args={[null, null, count]} key={count} frustumCulled={false} renderOrder={22}>
      <coneGeometry args={[0.28, 0.6, 3]} />
      <meshBasicMaterial color="#ffffff" toneMapped={false} depthTest={false} transparent />
    </instancedMesh>
  )
}

function Runner({ poly, route, navStatus, setNavStatus, progressRef, navRef, setStepIndex, gap }) {
  const gapRef = useRef(gap)
  useEffect(() => {
    gapRef.current = gap
  }, [gap])
  const pos = useMemo(() => new THREE.Vector3(), [])
  const dir = useMemo(() => new THREE.Vector3(), [])
  const lastStep = useRef(-1)

  useLayoutEffect(() => {
    // place the user at the current progress when the route or geometry changes
    progressRef.current = Math.min(progressRef.current, poly.total)
    samplePolyline(poly, progressRef.current, pos)
    navRef.current.pos.copy(pos)
  }, [poly, progressRef, navRef, pos])

  useEffect(() => {
    lastStep.current = -1
  }, [route])

  useFrame((_, dt) => {
    const n = navRef.current
    let d = progressRef.current
    if (navStatus === 'running' && !n.hold) {
      samplePolyline(poly, d, pos, dir)
      const vertical = Math.abs(dir.y) > 0.8
      // Real pace: wheelchair about 1 m/s, lift about 1.5 m/s (vertical is drawn at gap/4 scale).
      const mul = n.speed ?? 1
      const v = vertical ? 1.5 * (gapRef.current / 4) : 1.0
      d += v * mul * Math.min(dt, 0.1)
      progressRef.current = d
      if (d >= poly.total) {
        progressRef.current = poly.total
        setNavStatus('arrived')
      }
    }
    const segIdx = samplePolyline(poly, progressRef.current, pos, dir)
    n.pos.copy(pos)
    const edge = route.edges[Math.min(segIdx, route.edges.length - 1)]
    const onElev = edge && edge.elev && (edge.type === 'elevator' || edge.type === 'board')
    if (onElev) {
      n.elev = edge.elev
      n.lastElev = edge.elev
      n.lastY = pos.y - 0.3
    } else n.elev = null
    // map edge → instruction
    let step = route.instructions.findIndex((s) => segIdx >= s.i0 && segIdx <= s.i1)
    if (progressRef.current >= poly.total - 0.01) step = route.instructions.length - 1
    if (step !== lastStep.current && step >= 0) {
      lastStep.current = step
      setStepIndex(step)
    }
    // Progress within the current step, for "in 12 m" guidance
    const st = route.instructions[Math.max(0, step)]
    if (st) {
      const a = poly.cum[Math.min(st.i0, poly.cum.length - 1)]
      const b = poly.cum[Math.min(st.i1 + 1, poly.cum.length - 1)]
      n.stepFrac = b > a ? Math.min(1, Math.max(0, (progressRef.current - a) / (b - a))) : 1
      n.routeFrac = poly.total > 0 ? progressRef.current / poly.total : 0
    }
    if (Math.abs(dir.y) < 0.8 && (dir.x || dir.z)) n.dir.set(dir.x, 0, dir.z).normalize()
  })
  return null
}

function RoutePath({ route, gap, navStatus, setNavStatus, progressRef, navRef, setStepIndex, reduceMotion }) {
  const color = route.kind === 'alternative' ? C.blueBright : C.green
  const poly = useMemo(() => buildPolyline(route.nodeIds, gap), [route, gap])

  const blockedSegs = useMemo(
    () =>
      (route.baselineBlockedEdges ?? []).map((e) => [
        new THREE.Vector3(...nodePosition(GRAPH.nodes[e.a], gap, LIFT)),
        new THREE.Vector3(...nodePosition(GRAPH.nodes[e.b], gap, LIFT)),
      ]),
    [route, gap],
  )
  const warnSegs = useMemo(
    () =>
      route.edges
        .filter((e) => e.type === 'ramp' && e.steep)
        .map((e) => [
          new THREE.Vector3(...nodePosition(GRAPH.nodes[e.a], gap, LIFT + 0.05)),
          new THREE.Vector3(...nodePosition(GRAPH.nodes[e.b], gap, LIFT + 0.05)),
        ]),
    [route, gap],
  )

  return (
    <group>
      <Line points={poly.pts} color={color} lineWidth={12} transparent opacity={0.18} depthWrite={false} depthTest={false} renderOrder={20} toneMapped={false} />
      <Line points={poly.pts} color={color} lineWidth={4} transparent opacity={0.95} depthTest={false} renderOrder={21} toneMapped={false} />
      <Arrows poly={poly} reduceMotion={reduceMotion} />
      {blockedSegs.map((seg, i) => (
        <Line key={`b${i}`} points={seg} color={C.red} lineWidth={3.5} dashed dashSize={0.6} gapSize={0.4} depthTest={false} renderOrder={19} toneMapped={false} />
      ))}
      {warnSegs.map((seg, i) => (
        <Line key={`w${i}`} points={seg} color={C.yellow} lineWidth={7} depthTest={false} renderOrder={23} toneMapped={false} />
      ))}
      <Runner
        poly={poly}
        route={route}
        navStatus={navStatus}
        setNavStatus={setNavStatus}
        progressRef={progressRef}
        navRef={navRef}
        setStepIndex={setStepIndex}
        gap={gap}
      />
    </group>
  )
}

export default memo(RoutePath)
