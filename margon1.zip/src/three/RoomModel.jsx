import { memo, useState } from 'react'
import { Html } from '@react-three/drei'
import { ROOM_TYPES } from '../data/roomData'
import { BUILDING } from '../data/buildingData'
import { C } from './theme'

function RoomModel({ room, mode, highlight, selected, onSelect, showLabel, routeColor }) {
  const [hover, setHover] = useState(false)
  const base = ROOM_TYPES[room.type].color
  const inset = 0.12
  const w = room.x1 - room.x0 - inset * 2
  const d = room.z1 - room.z0 - inset * 2
  const cx = (room.x0 + room.x1) / 2
  const cz = (room.z0 + room.z1) / 2
  const dim = mode === 'dim'
  let color = base
  let opacity = dim ? 0.03 : mode === 'active' ? 0.2 : 0.1
  if (highlight === 'dest') {
    color = routeColor
    opacity = dim ? 0.2 : 0.5
  } else if (highlight === 'start') {
    color = C.ink
    opacity = dim ? 0.1 : 0.22
  }
  if (hover && !dim) opacity = Math.min(0.65, opacity + 0.2)
  if (selected) opacity = Math.max(opacity, 0.55)

  return (
    <group>
      <mesh
        position={[cx, 0.03, cz]}
        rotation={[-Math.PI / 2, 0, 0]}
        receiveShadow
        onPointerOver={(e) => {
          if (dim) return
          e.stopPropagation()
          setHover(true)
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => {
          setHover(false)
          document.body.style.cursor = 'auto'
        }}
        onClick={(e) => {
          if (dim) return
          e.stopPropagation()
          onSelect({ kind: 'room', id: room.id })
        }}
      >
        <planeGeometry args={[w, d]} />
        <meshBasicMaterial color={color} transparent opacity={opacity} depthWrite={false} />
      </mesh>
      {showLabel && (
        <Html position={[cx, BUILDING.wallHeight * 0.55, cz]} center zIndexRange={[12, 0]} style={{ pointerEvents: 'none' }}>
          <div className={`room-label ${highlight === 'dest' ? 'is-dest' : ''} ${highlight === 'start' ? 'is-start' : ''}`}>
            {room.name}
          </div>
        </Html>
      )}
    </group>
  )
}

export default memo(RoomModel)
