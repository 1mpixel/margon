// MARGON scene palette: white, minimal architectural model.
export const C = {
  bg: '#f3f5f7',
  fog: '#f3f5f7',
  ground: '#e8ecf0',
  grid: '#c9d1d9',
  slab: '#ffffff',
  slabBasement: '#eceff2',
  line: '#8796a5', // structure outlines
  lineSoft: '#b4bfca',
  cyan: '#8796a5', // structure (legend)
  cyanSoft: '#b4bfca',
  glass: '#cdd7e0',
  green: '#16a34a',
  blue: '#2563eb',
  blueBright: '#2563eb',
  red: '#dc2626',
  yellow: '#ca8a04',
  amber: '#d4a24c',
  furniture: '#d7dde3',
  car: '#c4ccd4',
  path: '#dde3e8',
  text: '#1f2933',
  ink: '#334155',
}

export const routeColor = (kind) => (kind === 'alternative' ? C.blueBright : C.green)
