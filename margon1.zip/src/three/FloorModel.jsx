import { memo, useLayoutEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { Edges, Html } from '@react-three/drei'
import { BUILDING, OPERATIONAL, floorName, floorShort } from '../data/buildingData'
import { roomsOn } from '../data/roomData'
import { floorWalls, mergedWallGeometry, wallOutlineGeometry, furnitureFor } from './geometry'
import RoomModel from './RoomModel'
import CorridorModel from './CorridorModel'
import { C } from './theme'

const _m = new THREE.Matrix4()
const _q = new THREE.Quaternion()
const _p = new THREE.Vector3()
const _s = new THREE.Vector3()

function Furniture({ items, color, visible }) {
  const ref = useRef()
  useLayoutEffect(() => {
    if (!ref.current) return
    items.forEach((it, i) => {
      _p.set(it.x, it.y, it.z)
      _s.set(it.w, it.h, it.d)
      _m.compose(_p, _q, _s)
      ref.current.setMatrixAt(i, _m)
    })
    ref.current.instanceMatrix.needsUpdate = true
  }, [items])
  if (!items.length) return null
  return (
    <instancedMesh ref={ref} args={[null, null, items.length]} castShadow receiveShadow visible={visible}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color={color} roughness={0.8} metalness={0.05} />
    </instancedMesh>
  )
}

// One floor of one block, drawn in the block's local coordinates.
function FloorModel({ bid, level, gap, mode, labelMode, destId, startId, routeColor, selectedObject, blocked, onSelect, onSelectFloor, reduceMotion, showTag }) {
  const open = OPERATIONAL.includes(level)
  const walls = useMemo(() => floorWalls(bid, level), [bid, level])
  const wallGeo = useMemo(() => mergedWallGeometry(walls.filter((w) => w.kind !== 'facadeLow')), [walls])
  const lowGeo = useMemo(() => mergedWallGeometry(walls.filter((w) => w.kind === 'facadeLow')), [walls])
  const outlineGeo = useMemo(() => wallOutlineGeometry(walls), [walls])
  const furniture = useMemo(() => furnitureFor(bid, level), [bid, level])
  const rooms = useMemo(() => (open ? roomsOn(bid, level) : []), [bid, level, open])

  const hidden = mode === 'hidden'
  const dim = mode === 'dim'
  const active = mode === 'active'
  const slabOpacity = dim ? 0.12 : active ? 0.96 : open ? 0.86 : 0.7
  const wallOpacity = dim ? 0.04 : active ? 0.32 : open ? 0.22 : 0.12
  const lineOpacity = dim ? 0.1 : active ? 0.85 : open ? 0.5 : 0.3

  return (
    <group position={[0, level * gap, 0]} visible={!hidden}>
      <mesh position={[0, -BUILDING.slabThickness / 2, 0]} receiveShadow>
        <boxGeometry args={[42.4, BUILDING.slabThickness, 20.4]} />
        <meshStandardMaterial color={open ? C.slab : '#e3e7eb'} transparent opacity={slabOpacity} roughness={0.85} depthWrite={!dim} />
        <Edges color={active ? C.ink : C.line} transparent opacity={dim ? 0.12 : active ? 0.9 : 0.55} />
      </mesh>

      {wallGeo && (
        <mesh geometry={wallGeo} castShadow={!dim && open}>
          <meshStandardMaterial color={C.glass} transparent opacity={wallOpacity} roughness={0.15} metalness={0.3} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
      )}
      {lowGeo && (
        <mesh geometry={lowGeo}>
          <meshStandardMaterial color={C.glass} transparent opacity={wallOpacity * 1.3} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
      )}
      <lineSegments geometry={outlineGeo}>
        <lineBasicMaterial color={active ? C.ink : C.line} transparent opacity={lineOpacity} depthWrite={false} />
      </lineSegments>

      {open && <Furniture items={furniture} color={C.furniture} visible={!dim} />}
      {open && <CorridorModel bid={bid} level={level} blocked={blocked} mode={mode} onSelect={onSelect} reduceMotion={reduceMotion} />}

      {rooms.map((r) => (
        <RoomModel
          key={r.id}
          room={r}
          mode={mode}
          routeColor={routeColor}
          highlight={r.id === destId ? 'dest' : r.id === startId ? 'start' : null}
          selected={selectedObject?.kind === 'room' && selectedObject.id === r.id}
          onSelect={onSelect}
          showLabel={!dim && labelMode === 'all' && r.id !== destId && r.id !== startId}
        />
      ))}

      {!open && active && (
        <Html position={[0, 0.9, 0]} center zIndexRange={[11, 0]} style={{ pointerEvents: 'none' }}>
          <div className="closed-floor">{floorName(level)} · not in use</div>
        </Html>
      )}

      {showTag && (
        <Html position={[-23, 0.4, 10]} center zIndexRange={[14, 0]}>
          <button
            type="button"
            className={`floor-tag ${active ? 'is-active' : ''} ${dim ? 'is-dim' : ''} ${open ? '' : 'is-closed'}`}
            onClick={() => onSelectFloor(level)}
            title={`${floorName(level)}${open ? '' : ' (not in use)'}`}
            aria-label={`Show ${floorName(level)}`}
          >
            {floorShort(level)}
          </button>
        </Html>
      )}
    </group>
  )
}

export default memo(FloorModel)
