import { memo } from 'react'
import { Edges, Html } from '@react-three/drei'
import { C } from './theme'

// Exterior ramps are at Ground level; they connect the exterior grade (-0.75 m) to the floor (0 m).
function RampModel({ ramp, onSelect, inRoute, routeColor, selected, open = true }) {
  const x0 = ramp.from.lx
  const x1 = ramp.to.lx
  const y0 = ramp.from.dy
  const y1 = ramp.to.dy
  const len = Math.hypot(x1 - x0, y1 - y0)
  const angle = Math.atan2(y1 - y0, x1 - x0)
  const cx = (x0 + x1) / 2
  const cy = (y0 + y1) / 2
  const z = ramp.from.z
  const color = !open ? C.red : inRoute ? routeColor : ramp.steep ? C.yellow : C.line
  const select = (e) => {
    e.stopPropagation()
    onSelect({ kind: 'ramp', id: ramp.id })
  }
  return (
    <group>
      <mesh
        position={[cx, cy - 0.08, z]}
        rotation={[0, 0, angle]}
        castShadow
        receiveShadow
        onClick={select}
        onPointerOver={(e) => {
          e.stopPropagation()
          document.body.style.cursor = 'pointer'
        }}
        onPointerOut={() => (document.body.style.cursor = 'auto')}
      >
        <boxGeometry args={[len, 0.16, ramp.width]} />
        <meshStandardMaterial color={!open ? "#fde2e2" : selected ? "#e6eef5" : "#f4f6f8"} roughness={0.8} />
        <Edges color={color} />
      </mesh>
      {/* Handrails */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[cx, cy + 0.85, z + s * (ramp.width / 2)]} rotation={[0, 0, angle]}>
          <boxGeometry args={[len, 0.05, 0.05]} />
          <meshStandardMaterial color={color} />
        </mesh>
      ))}
      {[0, 0.5, 1].flatMap((t) =>
        [-1, 1].map((s) => (
          <mesh key={`${t}${s}`} position={[x0 + (x1 - x0) * t, y0 + (y1 - y0) * t + 0.42, z + s * (ramp.width / 2)]}>
            <boxGeometry args={[0.05, 0.85, 0.05]} />
            <meshStandardMaterial color={color} />
          </mesh>
        )),
      )}
      <Html position={[cx, cy + 1.7, z]} center zIndexRange={[14, 0]}>
        <button
          type="button"
          className={`marker-chip ${!open ? 'chip-red' : inRoute ? 'chip-route' : ramp.steep ? 'chip-yellow' : 'chip-neutral'}`}
          style={open && inRoute ? { '--c': routeColor } : undefined}
          onClick={() => onSelect({ kind: 'ramp', id: ramp.id })}
        >
          <span className="chip-badge">{ramp.id.endsWith('RW') ? 'RW' : 'RE'}</span>
          {!open ? 'Ramp closed' : `Ramp ${ramp.gradient}`}
        </button>
      </Html>
      {/* Landings */}
      <mesh position={[x1 + Math.sign(x1 - x0) * 0.75, y1 - 0.08, z]} receiveShadow>
        <boxGeometry args={[1.5, 0.16, ramp.width]} />
        <meshStandardMaterial color="#f4f6f8" />
      </mesh>
      <mesh position={[x0 - Math.sign(x1 - x0) * 0.75, y0 - 0.08, z]} receiveShadow>
        <boxGeometry args={[1.5, 0.16, ramp.width + 0.4]} />
        <meshStandardMaterial color="#eef1f4" />
      </mesh>
    </group>
  )
}

export default memo(RampModel)
