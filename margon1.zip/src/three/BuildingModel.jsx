import { memo, useLayoutEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { Edges, Html, useTexture } from '@react-three/drei'
import { BUILDING, BUILDINGS, EXITS, FLOORS, LIFTS, RAMPS, SITE, STAIRS } from '../data/buildingData'
import { GRAPH } from '../data/routeData'
import { gradeGeometry } from './geometry'
import FloorModel from './FloorModel'
import ElevatorModel from './ElevatorModel'
import RampModel from './RampModel'
import { C } from './theme'
import bannerUrl from '../assets/glbajaj-banner.png'

const _m = new THREE.Matrix4()
const _q = new THREE.Quaternion()
const _p = new THREE.Vector3()
const _s = new THREE.Vector3()
const BANNER_ASPECT = 633 / 262

function Instanced({ items, color, opacity = 1 }) {
  const ref = useRef()
  useLayoutEffect(() => {
    if (!ref.current) return
    items.forEach((it, i) => {
      _p.set(it.x, it.y, it.z)
      _s.set(it.w, it.h, it.d)
      _m.compose(_p, _q, _s)
      ref.current.setMatrixAt(i, _m)
    })
    ref.current.instanceMatrix.needsUpdate = true
  }, [items])
  if (!items.length) return null
  return (
    <instancedMesh ref={ref} args={[null, null, items.length]} castShadow receiveShadow key={items.length}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color={color} roughness={0.8} transparent={opacity < 1} opacity={opacity} />
    </instancedMesh>
  )
}

function Banner({ width, position, rotation = [0, 0, 0] }) {
  const tex = useTexture(bannerUrl)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 8
  const h = width / BANNER_ASPECT
  return (
    <group position={position} rotation={rotation}>
      <mesh position={[0, 0, -0.08]}>
        <boxGeometry args={[width + 0.5, h + 0.5, 0.12]} />
        <meshStandardMaterial color="#5a3a2a" />
      </mesh>
      <mesh>
        <planeGeometry args={[width, h]} />
        <meshBasicMaterial map={tex} toneMapped={false} />
      </mesh>
    </group>
  )
}

// Dog-leg stairs between every pair of floors in both end cores (not step-free).
function Stairs({ bid, gap, floorModes, stairsOpen }) {
  const byStair = useMemo(() => {
    const out = {}
    const n = 9
    for (const st of STAIRS.filter((s) => s.building === bid)) {
      const arr = []
      const dir = st.lx < 0 ? 1 : -1
      const startX = st.lx < 0 ? st.box.x0 + 0.4 : st.box.x1 - 0.4
      for (let l = 0; l < 10; l++) {
        if (floorModes[l] === 'hidden') continue
        const base = l * gap
        const rise = gap / 2
        for (let k = 0; k < n; k++) {
          arr.push({ x: startX + dir * (k + 0.5) * 0.3, y: base + ((k + 1) * rise) / n - 0.06, z: -6.4, w: 0.3, h: 0.12, d: 1.8 })
          arr.push({ x: startX + dir * (n - k - 0.5) * 0.3, y: base + rise + ((k + 1) * rise) / n - 0.06, z: -4.2, w: 0.3, h: 0.12, d: 1.8 })
        }
        arr.push({ x: startX + dir * (n * 0.3 + 0.5), y: base + rise - 0.06, z: -5.3, w: 1.0, h: 0.12, d: 4.0 })
      }
      out[st.id] = arr
    }
    return out
  }, [bid, gap, floorModes])
  return STAIRS.filter((s) => s.building === bid).map((st) => (
    <Instanced key={st.id} items={byStair[st.id]} color={stairsOpen[st.id] === false ? C.red : C.amber} opacity={0.8} />
  ))
}

function Columns({ gap }) {
  const items = useMemo(() => {
    const bottom = -BUILDING.slabThickness
    const top = 10 * gap + BUILDING.wallHeight
    const h = top - bottom
    const out = []
    for (const x of [-21, -15, -5, 5, 15, 21]) for (const z of [-10, 10]) out.push({ x, y: bottom + h / 2, z, w: 0.3, h, d: 0.3 })
    return out
  }, [gap])
  return <Instanced items={items} color="#c3ccd5" opacity={0.7} />
}

function Entrance({ stepsOpen }) {
  const g = BUILDING.gradeLevel
  return (
    <group>
      <mesh position={[0, g / 2, 11.75]} castShadow receiveShadow>
        <boxGeometry args={[6.4, Math.abs(g), 3.5]} />
        <meshStandardMaterial color="#f7f9fa" />
        <Edges color={C.line} />
      </mesh>
      {[0, 1, 2].map((k) => (
        <mesh key={k} position={[0, g + (k + 0.5) * (Math.abs(g) / 3), 15.25 - k * 0.55]} receiveShadow>
          <boxGeometry args={[4, Math.abs(g) / 3, 0.55]} />
          <meshStandardMaterial color={stepsOpen ? '#eef1f4' : '#fde2e2'} />
          <Edges color={stepsOpen ? C.lineSoft : C.red} />
        </mesh>
      ))}
      <mesh position={[0, BUILDING.wallHeight + 0.4, 12]}>
        <boxGeometry args={[8, 0.12, 4.4]} />
        <meshStandardMaterial color={C.glass} transparent opacity={0.3} depthWrite={false} />
        <Edges color={C.line} />
      </mesh>
    </group>
  )
}

function Block({ b, gap, floorModes, labelModes, destId, startId, routeColor, selectedObject, facilities, onSelect, onSelectFloor, navRef, elevatorTint, rampsInRoute, reduceMotion, minimal }) {
  const roof = 10 * gap + BUILDING.realFloorHeight
  return (
    <group position={[b.ox, 0, 0]}>
      {/* Plinth */}
      <mesh position={[0, (BUILDING.gradeLevel - BUILDING.slabThickness) / 2, 0]} receiveShadow>
        <boxGeometry args={[42.6, Math.abs(BUILDING.gradeLevel) - BUILDING.slabThickness, 20.6]} />
        <meshStandardMaterial color="#e9edf1" />
        <Edges color={C.lineSoft} />
      </mesh>
      <Columns gap={gap} />
      {FLOORS.map((f) => (
        <FloorModel
          key={f.level}
          bid={b.id}
          level={f.level}
          gap={gap}
          mode={floorModes[f.level]}
          labelMode={labelModes[f.level]}
          destId={destId}
          startId={startId}
          routeColor={routeColor}
          selectedObject={selectedObject}
          blocked={facilities.blocked}
          onSelect={onSelect}
          onSelectFloor={onSelectFloor}
          reduceMotion={reduceMotion}
          showTag={b.id === 'B1'}
        />
      ))}
      <mesh position={[0, roof, 0]} visible={floorModes[10] !== 'hidden'}>
        <boxGeometry args={[42.4, 0.2, 20.4]} />
        <meshStandardMaterial color={C.slab} transparent opacity={0.5} />
        <Edges color={C.line} />
      </mesh>
      <Banner width={20} position={[0, roof + 0.2 + 20 / BANNER_ASPECT / 2 + 0.6, 9.6]} />
      <Stairs bid={b.id} gap={gap} floorModes={floorModes} stairsOpen={facilities.stairs} />
      {LIFTS.filter((l) => l.building === b.id).map((l) => (
        <ElevatorModel
          key={l.id}
          lift={l}
          gap={gap}
          working={facilities.elevators[l.id] !== false}
          routeTint={elevatorTint[l.id]}
          navRef={navRef}
          onSelect={onSelect}
          selected={selectedObject?.kind === 'elevator' && selectedObject.id === l.id}
          reduceMotion={reduceMotion}
          showChip={!minimal}
        />
      ))}
      <Entrance stepsOpen={facilities.stairs[`${b.id}-ST`] !== false} />
      {RAMPS.filter((r) => r.building === b.id).map((r) => (
        <RampModel
          key={r.id}
          ramp={r}
          open={facilities.ramps[r.id] !== false}
          onSelect={onSelect}
          inRoute={rampsInRoute.includes(r.id)}
          routeColor={routeColor}
          selected={selectedObject?.kind === 'ramp' && selectedObject.id === r.id}
        />
      ))}
      <Html position={[0, roof + 20 / BANNER_ASPECT + 2.6, 9.6]} center zIndexRange={[12, 0]} style={{ pointerEvents: 'none' }}>
        <div className="block-chip">{b.name}</div>
      </Html>
    </group>
  )
}

function Site({ minimal }) {
  const g = BUILDING.gradeLevel
  const grade = useMemo(() => gradeGeometry([]), [])
  const gridGeo = useMemo(() => {
    const pts = []
    for (let v = -92; v <= 92; v += 4) pts.push(v, 0, -58, v, 0, 66)
    for (let v = -58; v <= 66; v += 4) pts.push(-92, 0, v, 92, 0, v)
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3))
    return geo
  }, [])
  // Paved paths follow the exterior edges of the navigation graph.
  const paths = useMemo(
    () =>
      GRAPH.edges
        .filter((e) => e.type === 'path' && GRAPH.nodes[e.a].dy < 0 && GRAPH.nodes[e.b].dy < 0)
        .map((e) => {
          const A = GRAPH.nodes[e.a]
          const B = GRAPH.nodes[e.b]
          const len = Math.hypot(B.x - A.x, B.z - A.z) + 2.4
          const horiz = Math.abs(B.x - A.x) > Math.abs(B.z - A.z)
          return { x: (A.x + B.x) / 2, z: (A.z + B.z) / 2, w: horiz ? len : 2.4, d: horiz ? 2.4 : len }
        }),
    [],
  )
  const trees = minimal ? [] : [[-56, 26], [-50, -18], [56, -14], [52, 28], [-20, 30], [20, 30], [-60, 6], [60, 4]]
  return (
    <group>
      <mesh geometry={grade} position={[0, g - 0.01, 0]} receiveShadow>
        <meshStandardMaterial color={C.ground} roughness={1} />
      </mesh>
      <lineSegments geometry={gridGeo} position={[0, g + 0.005, 0]}>
        <lineBasicMaterial color={C.grid} transparent opacity={0.35} />
      </lineSegments>
      {paths.map((p, i) => (
        <mesh key={i} position={[p.x, g + 0.02, p.z]} receiveShadow>
          <boxGeometry args={[p.w, 0.04, p.d]} />
          <meshStandardMaterial color={C.path} />
        </mesh>
      ))}
      {/* Main gate with the institute banner */}
      <group position={[SITE.gate.x, g, SITE.gate.z]}>
        {[-8, 8].map((x) => (
          <mesh key={x} position={[x, 4, 0]} castShadow>
            <boxGeometry args={[1.2, 8, 1.2]} />
            <meshStandardMaterial color="#8c6a54" />
          </mesh>
        ))}
        <Banner width={15} position={[0, 8 + 15 / BANNER_ASPECT / 2, 0.2]} />
        <Banner width={15} position={[0, 8 + 15 / BANNER_ASPECT / 2, -0.2]} rotation={[0, Math.PI, 0]} />
      </group>
      {/* Help Desk kiosk */}
      <group position={[SITE.helpDesk.x + 3.2, g, SITE.helpDesk.z]}>
        <mesh position={[0, 1.5, 0]} castShadow>
          <boxGeometry args={[4, 3, 3.4]} />
          <meshStandardMaterial color="#f8fafb" />
          <Edges color={C.ink} />
        </mesh>
        <mesh position={[0, 3.15, 0]}>
          <boxGeometry args={[4.6, 0.3, 4]} />
          <meshStandardMaterial color="#0f5f5a" />
        </mesh>
      </group>
      {trees.map(([x, z], i) => (
        <group key={i} position={[x, g, z]}>
          <mesh position={[0, 1, 0]}>
            <cylinderGeometry args={[0.15, 0.22, 2, 6]} />
            <meshStandardMaterial color="#b8a993" />
          </mesh>
          <mesh position={[0, 3, 0]} castShadow>
            <icosahedronGeometry args={[1.9, 0]} />
            <meshStandardMaterial color="#b9d3b5" flatShading />
          </mesh>
        </group>
      ))}
      <Html position={[SITE.helpDesk.x + 3.2, g + 4.6, SITE.helpDesk.z]} center zIndexRange={[13, 0]} style={{ pointerEvents: 'none' }}>
        <div className="marker-chip chip-exit">
          <span className="chip-badge">i</span>Help Desk
        </div>
      </Html>
      <Html position={[SITE.gate.x, g + 1.2, SITE.gate.z + 1.5]} center zIndexRange={[13, 0]} style={{ pointerEvents: 'none' }}>
        <div className="marker-chip chip-neutral">Main Gate</div>
      </Html>
    </group>
  )
}

function ExitMarkers({ gap, onSelect, floorModes }) {
  return EXITS.filter((e) => e.kind === 'exit').map((ex) =>
    floorModes[ex.level] === 'hidden' || floorModes[ex.level] === 'dim' ? null : (
      <Html key={ex.id} position={[ex.x, ex.level * gap + 2.1, ex.z]} center zIndexRange={[13, 0]}>
        <button type="button" className="marker-chip chip-exit" onClick={() => onSelect({ kind: 'exit', id: ex.id })}>
          <span className="chip-badge">EX</span>
          {ex.name}
        </button>
      </Html>
    ),
  )
}

function Chairs({ chairs, gap, onSelect }) {
  return chairs.map((c) => {
    const y = (c.relHeight / BUILDING.realFloorHeight) * gap + 0.3
    return (
      <group key={c.id} position={[c.x, y, c.z]}>
        <mesh>
          <sphereGeometry args={[0.5, 20, 16]} />
          <meshBasicMaterial color={c.color} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.28, 0]}>
          <ringGeometry args={[0.75, 1.0, 32]} />
          <meshBasicMaterial color={c.color} transparent opacity={0.45} depthWrite={false} />
        </mesh>
        <Html position={[0, 1.3, 0]} center zIndexRange={[18, 0]}>
          <button type="button" className={`chair-chip ${c.selected ? 'is-selected' : ''}`} style={{ '--c': c.color }} onClick={() => onSelect({ kind: 'chair', id: c.id })}>
            {c.label}
          </button>
        </Html>
      </group>
    )
  })
}

function BuildingModel(props) {
  const { gap, floorModes, onSelect, minimal, chairs } = props
  return (
    <group>
      <Site minimal={minimal} />
      {BUILDINGS.map((b) => (
        <Block key={b.id} b={b} {...props} />
      ))}
      {!minimal && <ExitMarkers gap={gap} onSelect={onSelect} floorModes={floorModes} />}
      {chairs?.length > 0 && <Chairs chairs={chairs} gap={gap} onSelect={onSelect} />}
    </group>
  )
}

export default memo(BuildingModel)
