import * as THREE from 'three'
import { memo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import { GRAPH, nodeLabel, nodePosition } from '../data/routeData'
import { C } from './theme'

function Pin({ position, color, label, sub, kind }) {
  const ring = useRef()
  useFrame(({ clock }) => {
    if (!ring.current) return
    const k = (clock.elapsedTime * 0.8) % 1
    ring.current.scale.setScalar(0.6 + k * 1.6)
    ring.current.material.opacity = 0.6 * (1 - k)
  })
  return (
    <group position={position}>
      <mesh ref={ring} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]}>
        <ringGeometry args={[0.7, 0.9, 40]} />
        <meshBasicMaterial color={color} transparent opacity={0.5} toneMapped={false} depthWrite={false} />
      </mesh>
      <mesh position={[0, 1.6, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[0.35, 1.1, 16]} />
        <meshBasicMaterial color={color} toneMapped={false} />
      </mesh>
      <mesh position={[0, 2.35, 0]}>
        <sphereGeometry args={[0.42, 20, 16]} />
        <meshBasicMaterial color={color} toneMapped={false} />
      </mesh>
      <Html position={[0, 3.4, 0]} center zIndexRange={[16, 0]} style={{ pointerEvents: 'none' }}>
        <div className={`pin-label ${kind}`}>
          <span>{kind === 'dest' ? 'DESTINATION' : 'START'}</span>
          <strong>{label}</strong>
          {sub && <em>{sub}</em>}
        </div>
      </Html>
    </group>
  )
}

// Map-style navigation arrow: a chevron on a white disc that turns with the direction of travel.
const arrowShape = (() => {
  const sh = new THREE.Shape()
  sh.moveTo(0, 1.1)
  sh.lineTo(0.85, -0.75)
  sh.lineTo(0, -0.3)
  sh.lineTo(-0.85, -0.75)
  sh.lineTo(0, 1.1)
  return sh
})()

function UserMarker({ navRef, color }) {
  const g = useRef()
  const rot = useRef()
  const halo = useRef()
  useFrame(({ clock }, dt) => {
    if (!g.current) return
    g.current.position.copy(navRef.current.pos)
    const d = navRef.current.dir
    if (rot.current && d) {
      const yaw = Math.atan2(d.x, d.z)
      let cur = rot.current.rotation.y
      let diff = yaw - cur
      diff = Math.atan2(Math.sin(diff), Math.cos(diff))
      rot.current.rotation.y = cur + diff * Math.min(1, dt * 10)
    }
    if (halo.current) halo.current.scale.setScalar(1 + 0.18 * Math.sin(clock.elapsedTime * 3))
  })
  return (
    <group ref={g}>
      <mesh ref={halo} rotation={[-Math.PI / 2, 0, 0]} renderOrder={30}>
        <circleGeometry args={[2.0, 40]} />
        <meshBasicMaterial color={color} transparent opacity={0.22} depthTest={false} depthWrite={false} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]} renderOrder={31}>
        <circleGeometry args={[1.25, 40]} />
        <meshBasicMaterial color="#ffffff" depthTest={false} depthWrite={false} transparent />
      </mesh>
      <group ref={rot}>
        <mesh rotation={[-Math.PI / 2, 0, Math.PI]} position={[0, 0.05, 0]} renderOrder={32}>
          <shapeGeometry args={[arrowShape]} />
          <meshBasicMaterial color={color} depthTest={false} depthWrite={false} transparent side={THREE.DoubleSide} />
        </mesh>
      </group>
    </group>
  )
}

function NavigationMarkers({ route, gap, navRef, navStatus, stepIndex, startId, destId, showUser = true }) {
  const color = route?.kind === 'alternative' ? C.blueBright : C.green
  const startNode = GRAPH.nodes[startId]
  const destNode = GRAPH.nodes[destId]
  return (
    <group>
      {startNode && <Pin position={nodePosition(startNode, gap, 0.05)} color={C.ink} label={nodeLabel(startId)} kind="start" />}
      {destNode && route?.ok && (
        <Pin position={nodePosition(destNode, gap, 0.05)} color={color} label={nodeLabel(destId)} kind="dest" />
      )}
      {route?.ok && showUser && <UserMarker navRef={navRef} color={color} />}
      {route?.ok &&
        route.instructions.slice(0, -1).map((s, i) => {
          if (s.kind === 'door' || (i !== stepIndex && s.kind !== 'lift')) return null
          const node = GRAPH.nodes[route.nodeIds[s.i0]]
          const p = nodePosition(node, gap, s.kind === 'lift' ? 2.6 : 1.4)
          const arrow = s.kind === 'lift' ? (s.dir === 'up' ? '▲' : '▼') : s.turn === 'left' ? '←' : s.turn === 'right' ? '→' : s.kind === 'ramp' ? '◢' : '↑'
          return (
            <Html key={i} position={p} center zIndexRange={[15, 0]} style={{ pointerEvents: 'none' }}>
              <div className={`step-chip ${route.kind} ${i === stepIndex ? 'is-current' : ''} ${s.warn ? 'is-warn' : ''}`}>
                <b>{i + 1}</b>
                <span>
                  {arrow} {s.kind === 'lift' ? `Lift ${s.lift} · ${s.toLevel === 0 ? 'G' : s.toLevel}` : s.kind === 'walk' ? `${s.dist} m` : s.kind === 'ramp' ? 'Ramp' : 'Stairs'}
                </span>
              </div>
            </Html>
          )
        })}
    </group>
  )
}

export default memo(NavigationMarkers)
