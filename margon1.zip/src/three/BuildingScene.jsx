import { Suspense, memo, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { Canvas } from '@react-three/fiber'
import { AdaptiveDpr } from '@react-three/drei'
import BuildingModel from './BuildingModel'
import RoutePath from './RoutePath'
import NavigationMarkers from './NavigationMarkers'
import CameraControls, { DEFAULT_POSITION } from './CameraControls'
import { FLOORS } from '../data/buildingData'
import { withDefaults } from '../data/routeData'
import { C, routeColor } from './theme'

const noop = () => {}

function SceneContents({
  gap,
  selectedFloor = 'all',
  isolate = false,
  showLabels = true,
  facilities: facIn,
  route,
  startId,
  destId,
  navRef: navRefIn,
  navStatus = 'idle',
  setNavStatus = noop,
  progressRef: progIn,
  setStepIndex = noop,
  stepIndex = 0,
  showUser = true,
  chairs,
  selectedObject,
  onSelect = noop,
  onSelectFloor = noop,
  cameraCmd,
  viewInset,
  reduceMotion,
  autoRotate,
  minimal = true,
  follow = false,
}) {
  const facilities = useMemo(() => withDefaults(facIn), [facIn])
  const ownNav = useRef({ pos: new THREE.Vector3(), dir: new THREE.Vector3(0, 0, -1), elev: null, lastElev: null, lastY: 0, stepFrac: 0, routeFrac: 0 })
  const ownProg = useRef(0)
  const navRef = navRefIn ?? ownNav
  const progressRef = progIn ?? ownProg
  const rColor = routeColor(route?.kind)

  const floorModes = useMemo(() => {
    const m = {}
    FLOORS.forEach((f) => {
      if (selectedFloor === 'all') m[f.level] = 'normal'
      else m[f.level] = f.level === selectedFloor ? 'active' : isolate ? 'hidden' : 'dim'
    })
    return m
  }, [selectedFloor, isolate])

  const labelModes = useMemo(() => {
    const m = {}
    FLOORS.forEach((f) => (m[f.level] = floorModes[f.level] === 'active' && showLabels ? 'all' : 'none'))
    return m
  }, [floorModes, showLabels])

  const elevatorTint = useMemo(() => {
    const t = {}
    if (route?.ok) route.elevatorsUsed.forEach((id) => (t[id] = rColor))
    return t
  }, [route, rColor])

  const rampsInRoute = useMemo(
    () => (route?.ok ? [...new Set(route.edges.filter((e) => e.type === 'ramp').map((e) => e.ramp))] : []),
    [route],
  )

  return (
    <>
      <color attach="background" args={[C.bg]} />
      <fog attach="fog" args={[C.fog, 260, 620]} />
      <ambientLight intensity={1.15} />
      <hemisphereLight args={['#ffffff', '#d9e0e6', 0.7]} />
      <directionalLight
        position={[60, 140, 70]}
        intensity={1.25}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-100}
        shadow-camera-right={100}
        shadow-camera-top={100}
        shadow-camera-bottom={-100}
        shadow-camera-far={400}
        shadow-bias={-0.0004}
      />

      <BuildingModel
        gap={gap}
        floorModes={floorModes}
        labelModes={labelModes}
        destId={destId}
        startId={startId}
        routeColor={rColor}
        selectedObject={selectedObject}
        facilities={facilities}
        onSelect={onSelect}
        onSelectFloor={onSelectFloor}
        navRef={navRef}
        elevatorTint={elevatorTint}
        rampsInRoute={rampsInRoute}
        reduceMotion={reduceMotion}
        minimal={minimal}
        chairs={chairs}
      />
      {route?.ok && (
        <RoutePath
          route={route}
          gap={gap}
          navStatus={navStatus}
          setNavStatus={setNavStatus}
          progressRef={progressRef}
          navRef={navRef}
          setStepIndex={setStepIndex}
          reduceMotion={reduceMotion}
        />
      )}
      <NavigationMarkers
        route={route}
        gap={gap}
        navRef={navRef}
        navStatus={navStatus}
        stepIndex={stepIndex}
        startId={startId}
        destId={destId}
        showUser={showUser}
      />
      <CameraControls cameraCmd={cameraCmd} gap={gap} autoRotate={autoRotate} viewInset={viewInset ?? { left: 0, right: 0 }} reduceMotion={reduceMotion} follow={follow} navRef={navRef} />
      <AdaptiveDpr pixelated={false} />
    </>
  )
}

function BuildingScene({ onReady, onPointerMissed, paused = false, ...props }) {
  return (
    <Canvas
      frameloop={paused ? 'never' : 'always'}
      shadows
      dpr={[1, 2]}
      camera={{ position: DEFAULT_POSITION.toArray(), fov: 32, near: 0.5, far: 1200 }}
      gl={{ antialias: true, powerPreference: 'high-performance' }}
      onCreated={() => onReady?.()}
      onPointerMissed={onPointerMissed}
    >
      <Suspense fallback={null}>
        <SceneContents {...props} />
      </Suspense>
    </Canvas>
  )
}

export default memo(BuildingScene)
