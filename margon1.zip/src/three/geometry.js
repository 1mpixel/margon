// Procedural geometry for one GL BAJAJ block (local coordinates x -21..21, z -10..10).
import * as THREE from 'three'
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js'
import { BUILDING, CORRIDOR, LIFTS, OPERATIONAL } from '../data/buildingData'
import { roomsOn } from '../data/roomData'

const T = 0.16
const DOOR = 1.5
const wall = (x0, z0, x1, z1, h, kind = 'interior') => ({ x0, z0, x1, z1, h, kind })

function splitWithGaps(x0, x1, gaps) {
  const pieces = []
  let cur = x0
  ;[...gaps]
    .sort((a, b) => a[0] - b[0])
    .forEach(([g0, g1]) => {
      if (g0 > cur) pieces.push([cur, Math.min(g0, x1)])
      cur = Math.max(cur, g1)
    })
  if (cur < x1) pieces.push([cur, x1])
  return pieces.filter(([a, b]) => b - a > 0.05)
}

export function floorWalls(bid, level) {
  const H = BUILDING.wallHeight
  const LOW = BUILDING.facadeLowHeight
  const open = OPERATIONAL.includes(level)
  const walls = []
  const seen = new Set()
  const rooms = open ? roomsOn(bid, level) : []

  for (const r of rooms) {
    for (const x of [r.x0, r.x1]) {
      const key = `${x}|${r.side}`
      if (seen.has(key)) continue
      seen.add(key)
      walls.push(wall(x, r.z0, x, r.z1, H))
    }
    const cz = r.side === 'F' ? CORRIDOR.z1 : CORRIDOR.z0
    splitWithGaps(r.x0, r.x1, [[r.doorX - DOOR / 2, r.doorX + DOOR / 2]]).forEach(([a, b]) => walls.push(wall(a, cz, b, cz, H)))
  }

  // Façades along the room zone (front façade is low so the interior stays visible)
  const frontGaps = level === 0 ? [[-0.9, 0.9]] : []
  splitWithGaps(-15, 15, frontGaps).forEach(([a, b]) => walls.push(wall(a, 10, b, 10, LOW, 'facadeLow')))
  walls.push(wall(-15, -10, 15, -10, H, 'facade'))
  if (!open) {
    walls.push(wall(-15, 2, 15, 2, 0.6, 'facadeLow'))
    walls.push(wall(-15, -2, 15, -2, 0.6, 'facadeLow'))
  }

  // End cores: lift doors at the front, stair door at the rear
  const lifts = LIFTS.filter((l) => l.building === bid)
  for (const sx of [-1, 1]) {
    const xa = sx < 0 ? -21 : 15
    const xb = sx < 0 ? -15 : 21
    const liftGaps = open ? lifts.filter((l) => Math.sign(l.lx) === sx).map((l) => [l.lx - 0.85, l.lx + 0.85]) : []
    walls.push(...splitWithGaps(xa, xb, liftGaps).map(([a, b]) => wall(a, 2, b, 2, H)))
    walls.push(...splitWithGaps(xa, xb, open ? [[18 * sx - 0.9, 18 * sx + 0.9]] : []).map(([a, b]) => wall(a, -2, b, -2, H)))
    walls.push(wall(xa, 10, xb, 10, LOW, 'facadeLow'))
    walls.push(wall(xa, -10, xb, -10, H, 'facade'))
    walls.push(wall(sx * 15, 2, sx * 15, 10, H))
    walls.push(wall(sx * 15, -10, sx * 15, -2, H))
  }
  const endGaps = level === 0 ? [[-1, 1]] : []
  splitWithGaps(-10, 10, endGaps).forEach(([a, b]) => walls.push(wall(-21, a, -21, b, H, 'facade')))
  splitWithGaps(-10, 10, endGaps).forEach(([a, b]) => walls.push(wall(21, a, 21, b, LOW, 'facadeLow')))
  return walls
}

function wallBox(w) {
  const dx = w.x1 - w.x0
  const dz = w.z1 - w.z0
  const len = Math.hypot(dx, dz)
  const g = new THREE.BoxGeometry(Math.abs(dx) > 0.01 ? len : T, w.h, Math.abs(dz) > 0.01 ? len : T)
  g.translate((w.x0 + w.x1) / 2, w.h / 2, (w.z0 + w.z1) / 2)
  return g
}

export function mergedWallGeometry(walls) {
  if (!walls.length) return null
  const g = mergeGeometries(walls.map(wallBox), false)
  g.computeBoundingSphere()
  return g
}

export function wallOutlineGeometry(walls) {
  const pts = []
  for (const w of walls) {
    pts.push(w.x0, 0.02, w.z0, w.x1, 0.02, w.z1)
    pts.push(w.x0, w.h, w.z0, w.x1, w.h, w.z1)
    pts.push(w.x0, 0, w.z0, w.x0, w.h, w.z0)
    pts.push(w.x1, 0, w.z1, w.x1, w.h, w.z1)
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3))
  return g
}

const FURNISHED = {
  classroom: { sx: 1.5, sz: 1.4, w: 1.0, d: 0.5, h: 0.75 },
  seminar: { sx: 1.4, sz: 1.2, w: 1.0, d: 0.45, h: 0.72 },
  lab: { sx: 2.2, sz: 1.9, w: 1.6, d: 0.7, h: 0.8 },
  faculty: { sx: 2.4, sz: 2.4, w: 1.3, d: 0.65, h: 0.75 },
  hod: { table: true },
  office: { sx: 2.4, sz: 2.4, w: 1.3, d: 0.65, h: 0.75 },
  exam: { sx: 2.2, sz: 2.2, w: 1.3, d: 0.65, h: 0.75 },
  admission: { sx: 2.2, sz: 2.2, w: 1.3, d: 0.65, h: 0.75 },
  waiting: { sx: 2.4, sz: 2.0, w: 1.8, d: 0.55, h: 0.45 },
  server: { sx: 1.4, sz: 2.0, w: 0.7, d: 1.0, h: 2.0 },
}

export function furnitureFor(bid, level) {
  const items = []
  for (const r of roomsOn(bid, level)) {
    const spec = FURNISHED[r.type]
    if (!spec) continue
    const m = 1.0
    const x0 = r.x0 + m
    const x1 = r.x1 - m
    const z0 = r.z0 + m + (r.side === 'F' ? 0.7 : 0)
    const z1 = r.z1 - m - (r.side === 'R' ? 0.7 : 0)
    if (spec.table) {
      items.push({ x: (r.x0 + r.x1) / 2, y: 0.38, z: (z0 + z1) / 2, w: Math.min(2.2, x1 - x0), h: 0.75, d: 1.1 })
      continue
    }
    const nx = Math.max(1, Math.floor((x1 - x0) / spec.sx))
    const nz = Math.max(1, Math.floor((z1 - z0) / spec.sz))
    const ox = x0 + (x1 - x0 - (nx - 1) * spec.sx) / 2
    const oz = z0 + (z1 - z0 - (nz - 1) * spec.sz) / 2
    for (let i = 0; i < nx; i++)
      for (let k = 0; k < nz; k++) items.push({ x: ox + i * spec.sx, y: spec.h / 2, z: oz + k * spec.sz, w: spec.w, h: spec.h, d: spec.d })
  }
  return items
}

// Campus ground with openings for both block footprints.
export function gradeGeometry(blocks) {
  const s = new THREE.Shape()
  s.moveTo(-95, -60)
  s.lineTo(95, -60)
  s.lineTo(95, 70)
  s.lineTo(-95, 70)
  s.lineTo(-95, -60)
  for (const ox of blocks) {
    const hole = new THREE.Path()
    hole.moveTo(ox - 21.2, -10.2)
    hole.lineTo(ox - 21.2, 10.2)
    hole.lineTo(ox + 21.2, 10.2)
    hole.lineTo(ox + 21.2, -10.2)
    hole.lineTo(ox - 21.2, -10.2)
    s.holes.push(hole)
  }
  const g = new THREE.ShapeGeometry(s)
  g.rotateX(-Math.PI / 2)
  return g
}
