import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'

export default defineConfig({
  base: './', // relative paths: works from any folder or sub-path (GitHub Pages, Netlify, USB)
  plugins: [react(), tailwindcss()],
  build: { chunkSizeWarningLimit: 2000 },
  // During `npm run dev`, forward /api to the live server if it is running (npm start).
  server: { proxy: { '/api': 'http://localhost:8080' } },
})
