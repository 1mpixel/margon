// Guards drei <Html> cleanup against detaching an element that is already detached
// (occurs when a whole <Canvas> unmounts, e.g. on tab switch or sign-out).
import { readFileSync, writeFileSync, existsSync } from 'node:fs'

const files = ['node_modules/@react-three/drei/web/Html.js', 'node_modules/@react-three/drei/web/Html.cjs.js']
for (const f of files) {
  if (!existsSync(f)) continue
  const src = readFileSync(f, 'utf8')
  const out = src.replace('if (target) target.removeChild(el);', 'if (target && el.parentNode === target) target.removeChild(el);')
  if (out !== src) {
    writeFileSync(f, out)
    console.log('patched', f)
  }
}
