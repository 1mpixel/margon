// मार्गON live server.
// One Node.js process, no dependencies: serves the built website (dist/) and a small
// shared-data API so the Help Desk and every visitor phone see the same state.
//
//   GET    /api/health                  -> { ok, docs, clients }
//   GET    /api/state                   -> { facility, tokens, reports }
//   GET    /api/events                  -> Server-Sent Events: snapshot | put | del
//   PUT    /api/doc/<collection>/<id>   -> replace document          (body: JSON)
//   PATCH  /api/doc/<collection>/<id>   -> merge fields into document (body: JSON)
//   DELETE /api/doc/<collection>/<id>   -> remove document
//
// Collections: facility (id "state"), tokens, reports. Data persists in data/margon.json.
// Environment: PORT (default 8080), HOST (default 0.0.0.0), DATA_DIR (default ./data).

import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const DIST = path.join(ROOT, 'dist')
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'))
const DATA_FILE = path.join(DATA_DIR, 'margon.json')
const PORT = Number(process.env.PORT || 8080)
const HOST = process.env.HOST || '0.0.0.0'
const COLLECTIONS = new Set(['facility', 'tokens', 'reports'])
const MAX_BODY = 4 * 1024 * 1024 // photos are compressed to <= 640 px JPEG on the phone
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/

// ---------- storage ----------
let state = { facility: {}, tokens: {}, reports: {} }
try {
  const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))
  for (const c of COLLECTIONS) state[c] = raw[c] && typeof raw[c] === 'object' ? raw[c] : {}
  console.log(`Loaded ${DATA_FILE}`)
} catch {
  console.log('Starting with empty data')
}

let saveTimer = null
function scheduleSave() {
  if (saveTimer) return
  saveTimer = setTimeout(() => {
    saveTimer = null
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true })
      const tmp = DATA_FILE + '.tmp'
      fs.writeFileSync(tmp, JSON.stringify(state))
      fs.renameSync(tmp, DATA_FILE) // atomic replace: no half-written file after a crash
    } catch (e) {
      console.error('Save failed:', e.message)
    }
  }, 1000)
}

// ---------- live clients (Server-Sent Events) ----------
const clients = new Set()
function broadcast(event, payload) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`
  for (const res of clients) res.write(msg)
}
setInterval(() => {
  for (const res of clients) res.write(': ping\n\n') // keeps proxies from closing idle streams
}, 25000)

// ---------- helpers ----------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain',
}
function send(res, code, body, type = 'application/json') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' })
  res.end(typeof body === 'string' ? body : JSON.stringify(body))
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', (c) => {
      size += c.length
      if (size > MAX_BODY) {
        reject(new Error('too_large'))
        req.destroy()
      } else chunks.push(c)
    })
    req.on('end', () => {
      try {
        const v = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')
        if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('bad_json')
        resolve(v)
      } catch {
        reject(new Error('bad_json'))
      }
    })
    req.on('error', reject)
  })
}
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname)
  if (rel.endsWith('/')) rel += 'index.html'
  const file = path.normalize(path.join(DIST, rel))
  if (!file.startsWith(DIST)) return send(res, 403, { error: 'forbidden' })
  fs.stat(file, (err, st) => {
    const target = !err && st.isFile() ? file : path.join(DIST, 'index.html') // single-page app fallback
    fs.readFile(target, (e2, buf) => {
      if (e2) return send(res, 404, 'Build missing: run "npm run build" first.', 'text/plain')
      const ext = path.extname(target)
      const cache = target.includes(`${path.sep}assets${path.sep}`) ? 'public, max-age=31536000, immutable' : 'no-cache'
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': cache })
      res.end(buf)
    })
  })
}

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost')
  const p = url.pathname
  const from = String(req.headers['x-client'] || '')

  if (p === '/api/health') return send(res, 200, { ok: true, docs: Object.keys(state.tokens).length + Object.keys(state.reports).length, clients: clients.size })
  if (p === '/api/state' && req.method === 'GET') return send(res, 200, state)

  if (p === '/api/events' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' })
    res.write(`retry: 2000\nevent: snapshot\ndata: ${JSON.stringify(state)}\n\n`)
    clients.add(res)
    req.on('close', () => clients.delete(res))
    return
  }

  const m = p.match(/^\/api\/doc\/([a-z]+)\/([^/]+)$/)
  if (m) {
    const [, col, id] = m
    if (!COLLECTIONS.has(col) || !ID_RE.test(id)) return send(res, 400, { error: 'bad_path' })
    try {
      if (req.method === 'DELETE') {
        delete state[col][id]
        scheduleSave()
        broadcast('del', { col, id, from })
        return send(res, 200, { ok: true })
      }
      if (req.method === 'PUT' || req.method === 'PATCH') {
        const body = await readBody(req)
        const doc = req.method === 'PUT' ? body : { ...(state[col][id] || {}), ...body }
        state[col][id] = doc
        scheduleSave()
        broadcast('put', { col, id, data: doc, from })
        return send(res, 200, { ok: true })
      }
      return send(res, 405, { error: 'method' })
    } catch (e) {
      return send(res, e.message === 'too_large' ? 413 : 400, { error: e.message })
    }
  }

  if (p.startsWith('/api/')) return send(res, 404, { error: 'not_found' })
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'method' })
  serveStatic(req, res, p)
})

server.listen(PORT, HOST, () => {
  console.log(`मार्गON live on http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`)
})
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true })
      fs.writeFileSync(DATA_FILE, JSON.stringify(state))
    } catch {
      /* ignore */
    }
    process.exit(0)
  })
}
