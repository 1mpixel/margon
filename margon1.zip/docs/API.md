# मार्गON data interface

This document describes the data exchanged between the wheelchair strap, the visitor app and the
Help Desk. In the prototype the documents live in a shared document store (claude.ai artifact
database, or browser storage when run locally). A production deployment exposes the same documents
through the REST endpoints listed in section 5.

## 1. Documents

| Path | Written by | Purpose |
|---|---|---|
| `facility/state` | Help Desk | Open or closed state of every lift, ramp, stair and corridor; notice; routing engine |
| `tokens/<TOKEN>` | Help Desk (issue), visitor app (trip, telemetry, SOS) | One strap session |
| `reports/<ID>` | Visitor app, strap firmware | Barrier report awaiting verification |

### 1.1 `facility/state`

```json
{
  "elevators": { "B1-L1": true, "B1-L2": false },
  "ramps": { "B1-RW": true, "B1-RE": true },
  "stairs": { "B1-SW": true, "B1-ST": true },
  "blocked": ["B1-4-W"],
  "notice": "Lift L2 in the AI & ML Block is under maintenance until 4 pm.",
  "engine": "astar",
  "afterHours": false,
  "updatedAt": 1793630381000
}
```

### 1.2 `tokens/<TOKEN>`

```json
{
  "token": "MRG-4821", "strapId": "ST-01", "visitor": "Asha Verma", "phone": "98100 12345",
  "status": "active", "issuedAt": 1793630381000, "validFrom": 1793590200000, "validUntil": 1793622600000,
  "stops": ["B1-402", "B2-510"], "leg": 0, "mode": "ramp", "returnToDesk": true,
  "lastNode": "HD", "nav": "running", "step": 3,
  "telemetry": { "x": -38.6, "z": 0.0, "relHeight": 16.0, "level": 4, "pressure": 987.68, "heading": 270, "speed": 1.0, "ts": 1793630381000 },
  "telemetryRejected": { "issues": ["vertical-speed"], "ts": 1793630390000 },
  "sos": { "active": true, "type": "fall", "by": "strap", "ts": 1793630400000, "ack": false, "telemetry": { } }
}
```

### 1.3 `reports/<ID>`

```json
{
  "id": "Rm3x9k2a", "source": "strap", "category": "ramp", "target": "B1-RE",
  "confidence": 0.65, "evidence": { "kind": "steep-ramp", "meanDeg": 6.6, "limitDeg": 4.76 },
  "token": "MRG-4821", "strapId": "ST-01", "telemetry": { }, "ts": 1793630500000,
  "status": "pending", "decidedTs": null, "note": "", "photo": null
}
```

`category`: `lift` | `ramp` | `corridor` | `steps` | `stairs`.
`status`: `pending` → `verified` (the item is closed in `facility/state`) or `dismissed`.

## 2. Strap telemetry

| Field | Unit | Source |
|---|---|---|
| `x`, `z` | metres, campus frame | ESP32 Wi-Fi positioning, smoothed with MPU heading |
| `heading` | degrees, 0 = north | MPU6050 gyroscope (yaw) |
| `speed` | m/s | MPU6050 integration and position change |
| `pressure` | hPa | BMP280 / BMP388 |
| `relHeight` | metres above Ground floor | Differential barometry against the Help Desk reference |
| `level` | floor 0 to 10 | `round(relHeight / 4)` |
| `ts` | ms since epoch | ESP32 clock (NTP) |

## 3. Validation rules (applied before a reading is accepted)

| Code | Rule |
|---|---|
| `non-numeric` | `x`, `z`, `relHeight`, `pressure`, `ts` must be finite numbers |
| `pressure-range` | 900 to 1100 hPa |
| `floor-range` | floor 0 to 10 |
| `height-range` | −2 to 46 m |
| `outside-campus` | x −95 to 95 m, z −60 to 70 m |
| `time-order` | timestamp later than the previous accepted reading |
| `speed` | horizontal speed ≤ 3 m/s |
| `vertical-speed` | vertical speed ≤ 2.5 m/s (a lift moves at about 1.5 m/s) |

Floor from pressure: `height = (P_ref − P_strap) / 0.12 hPa·m⁻¹ − 0.75 m`, where `P_ref` is the
Help Desk barometer at exterior grade. Using the reference cancels weather and HVAC drift that
affects both sensors equally.

## 4. Barrier detection on the strap

| Flag | Rule | Confidence |
|---|---|---|
| Steep ramp | mean MPU pitch on a ramp > 4.76° (1:12) + 0.7° tolerance | 0.65 |
| Lift not arriving | waiting at a landing ≥ 180 s and pressure change < 0.1 hPa | 0.65 |
| Corridor blocked | the strap turns back on a segment; two different straps within 15 min | 0.45 per strap |
| Visitor report | visitor taps "Report a barrier" | 0.50 (0.60 with photo) |

Reports on the same item combine as `P = 1 − Π(1 − cᵢ)`. At `P ≥ 0.85` the Help Desk is advised
to verify. A person always confirms before an item is closed.

## 5. REST mapping for a production server

| Method | Endpoint | Body / result |
|---|---|---|
| `GET` | `/api/facility` | `facility/state` |
| `PATCH` | `/api/facility` | partial `facility/state` (Help Desk only) |
| `POST` | `/api/tokens` | `{ strapId, visitor, phone }` → token document |
| `POST` | `/api/straps/{strapId}/telemetry` | telemetry record → `202 Accepted` or `422 { issues }` |
| `POST` | `/api/tokens/{token}/sos` | `{ type }` |
| `POST` | `/api/reports` | report document |
| `PATCH` | `/api/reports/{id}` | `{ status: "verified" \| "dismissed" }` (Help Desk only) |
| `GET` | `/api/route?from=HD&to=B1-402&mode=ramp&algo=astar` | route with steps and search statistics |

## 6. Tests

`npm test` runs 27 automated tests (graph integrity, priority queue, Dijkstra and A* optimality,
accessibility rules, rerouting, multi-stop ordering, service hours, telemetry validation,
differential barometry, barrier detection). `npm run bench` writes `docs/benchmark.json`.
