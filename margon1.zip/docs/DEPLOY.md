# Deploying मार्गON on a live server

The live server (`server/server.mjs`) is one Node.js process with no extra dependencies. It serves the built
website and a small shared-data API (REST writes plus Server-Sent Events), so the Help Desk and every visitor
phone see the same facility state, straps, SOS alerts and barrier reports. Data is saved in `data/margon.json`.

Static hosting (Netlify, GitHub Pages, the offline HTML file) still works, but each browser keeps its own data.
Multi-device operation needs this server. The badge in the app header shows **Live · server** when connected.

## 1. Run locally (any laptop, Node.js 20 or newer)

```bash
npm install
npm run serve          # builds, then starts on http://localhost:8080
```

Other devices on the same Wi-Fi open `http://<laptop-IP>:8080` (find the IP with `ipconfig` on Windows
or `ip addr` on Linux). This is enough for the hackathon demo: Help Desk on the laptop, visitor on a phone.

## 2. Free cloud hosting: Render

1. Push the project folder to a GitHub repository (`node_modules`, `dist` and `data` are ignored).
2. On render.com: **New → Web Service**, connect the repository.
3. Settings: Runtime **Node**; Build command `npm install && npm run build`; Start command `npm start`;
   Instance type **Free**.
4. Deploy. The public address is `https://<name>.onrender.com`.

Limitations of the free tier: the service sleeps after about 15 minutes without visits (the first request then
takes about a minute), and its disk is reset on each restart, so issued straps and reports are cleared.
Open the link a few minutes before a demonstration. Railway and Fly.io work with the same two commands.

## 3. College or rented Linux server (permanent)

```bash
# on the server (Ubuntu), once
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs nginx
sudo npm install -g pm2

# copy the project (git clone or scp margon.zip), then
cd margon
npm install
npm run build
pm2 start server/server.mjs --name margon
pm2 save && pm2 startup        # restart automatically after a reboot
```

Nginx in front (HTTPS and a domain), file `/etc/nginx/sites-available/margon`:

```nginx
server {
    server_name margon.example.edu;
    client_max_body_size 5m;
    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header Connection '';
        proxy_buffering off;          # required for live updates (Server-Sent Events)
        proxy_read_timeout 1h;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/margon /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d margon.example.edu
```

## 4. Docker (any host)

```bash
docker build -t margon .
docker run -d --name margon -p 8080:8080 -v margon-data:/app/data --restart unless-stopped margon
```

## Configuration

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | 8080 | Listening port (Render and Railway set it automatically) |
| `HOST` | 0.0.0.0 | Listening address |
| `DATA_DIR` | `./data` | Folder for `margon.json` |

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | `{ ok, docs, clients }` |
| GET | `/api/state` | All documents |
| GET | `/api/events` | Live stream: `snapshot`, `put`, `del` |
| PUT | `/api/doc/<collection>/<id>` | Replace a document |
| PATCH | `/api/doc/<collection>/<id>` | Merge fields |
| DELETE | `/api/doc/<collection>/<id>` | Remove |

Collections: `facility` (id `state`), `tokens`, `reports`. A real ESP32 strap would send its telemetry with
`PATCH /api/doc/tokens/<token>` and body `{ "telemetry": { ... } }`, in the format given in `docs/API.md`.

## Security note

The Help Desk sign-in (`admin` / `margon123`) is checked in the browser, and the API accepts writes from anyone
who can reach it. This is adequate on a campus network or for a demonstration. Before public deployment, change
the password and add server-side authentication for facility changes.
