// Writes docs/benchmark.json: Dijkstra vs A* on random destination pairs (run with: npm run bench)
import { it } from 'vitest'
import { writeFileSync, mkdirSync } from 'node:fs'
import { GRAPH, NORMAL_FACILITIES, profileFor, search } from '../src/data/routeData'
import { DESTINATIONS } from '../src/data/roomData'
import { LIFTS } from '../src/data/buildingData'

it('benchmark', () => {
  const W = profileFor('ramp')
  let s = 42
  const r = () => ((s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296)
  const pairs = []
  while (pairs.length < 500) {
    const a = DESTINATIONS[Math.floor(r() * DESTINATIONS.length)].id
    const b = DESTINATIONS[Math.floor(r() * DESTINATIONS.length)].id
    if (a !== b) pairs.push([a, b])
  }
  const run = (fac) => {
    const agg = { dijkstra: { exp: 0, push: 0, ms: 0 }, astar: { exp: 0, push: 0, ms: 0 }, same: 0, crossBlock: 0 }
    for (let k = 0; k < 3; k++) for (const [a, b] of pairs) search(a, b, fac, W, k % 2 ? 'astar' : 'dijkstra') // warm-up
    for (const [a, b] of pairs) {
      const d = search(a, b, fac, W, 'dijkstra')
      const x = search(a, b, fac, W, 'astar')
      agg.dijkstra.exp += d.expanded
      agg.dijkstra.push += d.pushes
      agg.dijkstra.ms += d.ms
      agg.astar.exp += x.expanded
      agg.astar.push += x.pushes
      agg.astar.ms += x.ms
      if (Math.abs(d.cost - x.cost) < 1e-9) agg.same++
    }
    const n = pairs.length
    const f = (o) => ({ expanded: +(o.exp / n).toFixed(1), pushes: +(o.push / n).toFixed(1), ms: +(o.ms / n).toFixed(3) })
    return { pairs: n, dijkstra: f(agg.dijkstra), astar: f(agg.astar), identicalCost: agg.same, reduction: +(100 * (1 - agg.astar.exp / agg.dijkstra.exp)).toFixed(1) }
  }
  const normal = run(NORMAL_FACILITIES)
  const failure = run({ ...NORMAL_FACILITIES, elevators: Object.fromEntries(LIFTS.map((l) => [l.id, !['B1-L2', 'B2-L3'].includes(l.id)])) })
  const out = { nodes: Object.keys(GRAPH.nodes).length, edges: GRAPH.edges.length, normal, twoLiftsClosed: failure, generated: new Date().toISOString() }
  mkdirSync('docs', { recursive: true })
  writeFileSync('docs/benchmark.json', JSON.stringify(out, null, 2))
  console.log(JSON.stringify(out, null, 2))
})
