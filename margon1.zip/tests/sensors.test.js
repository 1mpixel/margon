import { describe, expect, it } from 'vitest'
import { RAMP_LIMIT_DEG, combinedConfidence, detectLiftStall, detectSteepRamp, detectTurnBacks, floorFromPressure, validateTelemetry } from '../src/data/sensors'
import { nearestTarget, closeInFacility, isClosed } from '../src/data/barriers'
import { NORMAL_FACILITIES } from '../src/data/routeData'

const ok = { x: -20, z: 0, relHeight: 16, level: 4, pressure: 987.68, ts: 1000 }

describe('telemetry validation', () => {
  it('accepts a normal reading', () => expect(validateTelemetry(null, ok).ok).toBe(true))
  it('rejects impossible pressure and floors', () => {
    expect(validateTelemetry(null, { ...ok, pressure: 1200 }).issues).toContain('pressure-range')
    expect(validateTelemetry(null, { ...ok, level: 14 }).issues).toContain('floor-range')
  })
  it('rejects a wheelchair moving faster than 3 m/s', () => {
    expect(validateTelemetry(ok, { ...ok, x: ok.x + 10, ts: 2000 }).issues).toContain('speed')
  })
  it('rejects a jump of three floors in one second', () => {
    expect(validateTelemetry(ok, { ...ok, relHeight: 28, ts: 2000 }).issues).toContain('vertical-speed')
  })
  it('rejects readings outside the campus', () => {
    expect(validateTelemetry(null, { ...ok, x: 400 }).issues).toContain('outside-campus')
  })
})

describe('differential barometry', () => {
  const pRef = 989.69 // Help Desk reference barometer, 0.75 m below Ground floor
  it('recovers the floor from pressure', () => {
    for (const level of [0, 2, 5, 10]) {
      const p = 989.6 - level * 4 * 0.12
      expect(floorFromPressure(p, pRef, 0.75).level).toBe(level)
    }
  })
  it('cancels a weather drift that affects both barometers equally', () => {
    const drift = -1.5 // hPa, a falling-pressure day
    const p = 989.6 - 4 * 4 * 0.12 + drift
    expect(floorFromPressure(p, pRef + drift, 0.75).level).toBe(4)
    // Without the reference the same drift would be read as about 3 floors higher:
    expect(floorFromPressure(p, pRef, 0.75).level).not.toBe(4)
  })
})

describe('barrier detection', () => {
  it('a 1:12 ramp is acceptable, a steeper one is flagged', () => {
    expect(RAMP_LIMIT_DEG).toBeCloseTo(4.76, 2)
    expect(detectSteepRamp([4.6, 4.8, 4.7]).steep).toBe(false)
    expect(detectSteepRamp([6.4, 6.8, 6.6]).steep).toBe(true)
  })
  it('a lift that does not arrive in 3 minutes is flagged', () => {
    expect(detectLiftStall(200, 0.02).stalled).toBe(true)
    expect(detectLiftStall(90, 0.02).stalled).toBe(false)
    expect(detectLiftStall(200, 0.5).stalled).toBe(false) // height changed: the visitor rode the lift
  })
  it('two different straps turning back on one segment flag it as blocked', () => {
    const now = 1e9
    const ev = [
      { segment: 'B1-4-W', strapId: 'ST-01', ts: now - 60e3 },
      { segment: 'B1-4-W', strapId: 'ST-02', ts: now - 30e3 },
      { segment: 'B1-2-E', strapId: 'ST-01', ts: now - 20e3 },
    ]
    expect(detectTurnBacks(ev, 15 * 60e3, now)).toEqual([{ segment: 'B1-4-W', straps: ['ST-01', 'ST-02'] }])
  })
  it('independent reports raise confidence', () => {
    expect(combinedConfidence([{ confidence: 0.5 }])).toBe(0.5)
    expect(combinedConfidence([{ confidence: 0.5 }, { confidence: 0.65 }])).toBeCloseTo(0.825, 1)
    expect(combinedConfidence([{ confidence: 0.6 }, { confidence: 0.65 }, { confidence: 0.65 }])).toBeGreaterThan(0.85)
  })
  it('locates the nearest facility and closes it', () => {
    const lift = nearestTarget('lift', { x: -22 - 19, z: 3, level: 4 })
    expect(lift).toBe('B1-L1')
    const f = closeInFacility(NORMAL_FACILITIES, 'lift', lift)
    expect(isClosed(f, 'lift', lift)).toBe(true)
    expect(nearestTarget('corridor', { x: 22 + 10, z: 0, level: 5 })).toBe('B2-5-E')
  })
})
