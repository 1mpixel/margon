import { describe, expect, it } from 'vitest'
import { GRAPH, MinHeap, NORMAL_FACILITIES, computeRoute, heuristic, orderStops, profileFor, search, tokenState, validityFor } from '../src/data/routeData'
import { DESTINATIONS } from '../src/data/roomData'
import { LIFTS, OPERATIONAL } from '../src/data/buildingData'

const WHEEL = profileFor('ramp')
const STEPS = profileFor('steps')
const closeLifts = (pred) => ({ ...NORMAL_FACILITIES, elevators: Object.fromEntries(LIFTS.map((l) => [l.id, !pred(l)])) })

// Deterministic pseudo-random pairs
function rng(seed) {
  let s = seed
  return () => ((s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296)
}
const pairs = (n, seed = 7) => {
  const r = rng(seed)
  return Array.from({ length: n }, () => [DESTINATIONS[Math.floor(r() * DESTINATIONS.length)].id, DESTINATIONS[Math.floor(r() * DESTINATIONS.length)].id]).filter(([a, b]) => a !== b)
}

describe('graph', () => {
  it('every edge joins two existing nodes and adjacency lists are symmetric', () => {
    for (const e of GRAPH.edges) {
      expect(GRAPH.nodes[e.a]).toBeDefined()
      expect(GRAPH.nodes[e.b]).toBeDefined()
      expect(GRAPH.adj[e.a]).toContain(e)
      expect(GRAPH.adj[e.b]).toContain(e)
    }
  })
  it('has no nodes on floors that are not in use', () => {
    for (const n of Object.values(GRAPH.nodes)) expect(OPERATIONAL).toContain(n.level)
  })
  it('every destination is reachable step-free from the Help Desk', () => {
    for (const d of DESTINATIONS) expect(computeRoute('HD', d.id, NORMAL_FACILITIES, WHEEL).ok, d.id).toBe(true)
  })
})

describe('priority queue', () => {
  it('pops keys in ascending order', () => {
    const h = new MinHeap()
    const keys = [5, 3, 9, 1, 7, 1, 8, 2]
    keys.forEach((k, i) => h.push(k, i))
    const out = []
    while (h.size) out.push(h.pop()[0])
    expect(out).toEqual([...keys].sort((a, b) => a - b))
  })
})

describe('Dijkstra and A*', () => {
  it('A* heuristic never overestimates the true cost (admissible)', () => {
    for (const [a, b] of pairs(60, 3)) {
      const r = search(a, b, NORMAL_FACILITIES, WHEEL, 'dijkstra')
      expect(heuristic(GRAPH.nodes[a], GRAPH.nodes[b])).toBeLessThanOrEqual(r.cost + 1e-9)
    }
  })
  it('A* returns the same optimal cost as Dijkstra and expands fewer nodes', () => {
    let dExp = 0
    let aExp = 0
    for (const [a, b] of pairs(150)) {
      const d = search(a, b, NORMAL_FACILITIES, WHEEL, 'dijkstra')
      const s = search(a, b, NORMAL_FACILITIES, WHEEL, 'astar')
      expect(s.cost).toBeCloseTo(d.cost, 6)
      dExp += d.expanded
      aExp += s.expanded
    }
    expect(aExp).toBeLessThan(dExp)
  })
})

describe('accessibility requirements', () => {
  it('wheelchair routes never use stairs or front steps', () => {
    for (const [a, b] of pairs(120, 11)) {
      const r = computeRoute(a, b, NORMAL_FACILITIES, WHEEL)
      expect(r.edges.some((e) => e.type === 'stairs')).toBe(false)
    }
  })
  it('Steps + Lift preference may use the front steps but still uses lifts between floors', () => {
    const r = computeRoute('HD', 'B1-402', NORMAL_FACILITIES, STEPS)
    expect(r.edges.some((e) => e.stair?.endsWith('-ST'))).toBe(true)
    expect(r.edges.some((e) => e.type === 'elevator')).toBe(true)
  })
})

describe('rerouting', () => {
  it('avoids a closed lift and reports it as the reason', () => {
    const base = computeRoute('HD', 'B1-402', NORMAL_FACILITIES, WHEEL)
    const used = base.elevatorsUsed[0]
    const r = computeRoute('HD', 'B1-402', closeLifts((l) => l.id === used), WHEEL)
    expect(r.ok).toBe(true)
    expect(r.kind).toBe('alternative')
    expect(r.elevatorsUsed).not.toContain(used)
  })
  it('avoids a blocked corridor segment by switching to the other lift core', () => {
    // Room 404's door is in the centre segment; block the side segment the base route uses.
    const base = computeRoute('HD', 'B1-404', NORMAL_FACILITIES, WHEEL)
    const seg = base.edges.find((e) => e.type === 'corridor' && e.level === 4 && e.segment !== 'B1-4-C').segment
    const r = computeRoute('HD', 'B1-404', { ...NORMAL_FACILITIES, blocked: [seg] }, WHEEL)
    expect(r.ok).toBe(true)
    expect(r.kind).toBe('alternative')
    expect(r.edges.some((e) => e.segment === seg)).toBe(false)
  })
  it('uses the other entrance ramp when one ramp is closed', () => {
    const base = computeRoute('HD', 'B1-G-ADM', NORMAL_FACILITIES, WHEEL)
    const ramp = base.edges.find((e) => e.type === 'ramp').ramp
    const r = computeRoute('HD', 'B1-G-ADM', { ...NORMAL_FACILITIES, ramps: { ...NORMAL_FACILITIES.ramps, [ramp]: false } }, WHEEL)
    expect(r.ok).toBe(true)
    expect(r.edges.find((e) => e.type === 'ramp').ramp).not.toBe(ramp)
  })
  it('reports no step-free route when every lift in a block is closed (never suggests stairs)', () => {
    const r = computeRoute('HD', 'B1-402', closeLifts((l) => l.building === 'B1'), WHEEL)
    expect(r.ok).toBe(false)
  })
})

describe('multi-stop trips', () => {
  it('shortest order is no slower than the order the visitor entered', () => {
    const stops = ['B2-10-L3', 'B1-G-ADM', 'B1-402', 'B2-510']
    const time = (order) => {
      let t = 0
      let o = 'HD'
      for (const s of [...order, 'HD']) {
        t += computeRoute(o, s, NORMAL_FACILITIES, WHEEL).timeSec
        o = s
      }
      return t
    }
    const best = orderStops('HD', stops, NORMAL_FACILITIES, WHEEL, 'HD')
    expect(best.sort()).toEqual([...stops].sort())
    expect(time(orderStops('HD', stops, NORMAL_FACILITIES, WHEEL, 'HD'))).toBeLessThanOrEqual(time(stops))
  })
})

describe('service hours', () => {
  it('tokens issued during service hours expire at 6 pm', () => {
    const v = validityFor(new Date('2026-11-04T10:00:00'))
    expect(new Date(v.validUntil).getHours()).toBe(18)
    expect(tokenState({ status: 'active', ...v }, new Date('2026-11-04T17:59:00').getTime())).toBe('ok')
    expect(tokenState({ status: 'active', ...v }, new Date('2026-11-04T18:00:00').getTime())).toBe('expired')
  })
  it('no token outside service hours unless demonstration mode is on', () => {
    expect(validityFor(new Date('2026-11-04T20:00:00'))).toBeNull()
    expect(validityFor(new Date('2026-11-04T20:00:00'), true).extended).toBe(true)
  })
})
